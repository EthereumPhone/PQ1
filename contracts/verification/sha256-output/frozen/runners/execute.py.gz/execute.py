"""Two-process bounded execution using the frozen, reviewed ownership module.

The outer observer does no bulk hashing or disk scans while a child is alive.
The worker polls disk usage asynchronously and never treats a timeout as a
negative proof. Both direct exits and complete owned cleanup are mandatory.
Semantic acceptance is a separate step; execution alone gives no proof credit.
"""
from pathlib import Path
import json
import os
import shutil
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
N = OUT.parent.parent
FROZEN = N / 'cbmc-negative-group-budget-candidate/scripts/pq1_budget'
sys.path.insert(0, str(FROZEN))
from process_ownership import OwnedTree, identity
from supervision import monitor, drain

GIB, MIB, NANO = 1024**3, 1024**2, 10**9


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def read(path):
    return json.loads(Path(path).read_text())


def disk_command(root, spec):
    return spec.get('fixture_du_command', ['/usr/bin/du', '-s', '-B1', '--', str(root)])


def measure(root, spec):
    r = subprocess.run(disk_command(root, spec), capture_output=True, timeout=15, check=True)
    if len(r.stdout) > 8192:
        raise RuntimeError('invalid allocation output')
    return int(r.stdout.split()[0])


def worker(spec_path, start, final):
    spec = read(spec_path)
    folder = Path(spec['output'])
    owner = OwnedTree()
    job = scanner = None
    stopped = None
    before = spec['allocation_before']
    maximum = before
    seen = set()
    cap = spec['aggregate_cap']
    workspace = spec['workspace']
    floor = spec['host_floor']
    reserve = spec['reserve']
    term = final - 4 * NANO
    child_exit_at = None
    try:
        with (folder / 'command.log').open('xb') as output:
            if time.monotonic_ns() >= term:
                raise RuntimeError('no live execution time')
            job = subprocess.Popen(spec['command'], cwd=spec['cwd'], env=spec['environment'],
                                   stdout=output, stderr=subprocess.STDOUT)
            owner.register(job)
            next_scan = time.monotonic_ns()
            scan_started = None
            while True:
                code = job.poll()
                now = time.monotonic_ns()
                if code is not None:
                    child_exit_at = now
                    break
                if now >= term:
                    raise RuntimeError('active execution deadline')
                for child in owner.discover():
                    seen.add((child['pid'], child['start_ticks']))
                    if child['parent'] == owner.owner['pid'] and child['pid'] not in owner.registered:
                        raise RuntimeError('unexpected adopted descendant')
                if shutil.disk_usage(spec['storage_root']).free <= floor + reserve:
                    raise RuntimeError('host free space floor')
                if scanner is None and now >= next_scan:
                    scanner = subprocess.Popen(disk_command(spec['storage_root'], spec),
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    owner.register(scanner)
                    scan_started = now
                if scanner is not None:
                    scanned = scanner.poll()
                    if scanned is not None:
                        data = scanner.stdout.read(8193)
                        scanner.stdout.close()
                        if scanned != 0 or len(data) > 8192:
                            raise RuntimeError('disk measurement failed')
                        size = int(data.split()[0])
                        if size < 0:
                            raise RuntimeError('negative disk allocation')
                        maximum = max(maximum, size)
                        if size >= min(cap - reserve, before + workspace):
                            raise RuntimeError('aggregate/workspace storage limit')
                        scanner = None
                        next_scan = now + 3 * NANO
                    elif now - scan_started >= 15 * NANO:
                        raise RuntimeError('disk measurement deadline')
                time.sleep(.05)
        # A disk measurement may still be running after an ordinary short job.
        # It is not a leaked solver; stop this identified direct child separately.
        if scanner is not None:
            owner.send_child(scanner, signal.SIGKILL)
            scanner.wait(timeout=1)
            scanner.stdout.close()
        if not owner.empty():
            raise RuntimeError('residual command descendants')
    except BaseException as error:
        stopped = repr(error)
    finally:
        clean = drain(owner, min(final - NANO, time.monotonic_ns() + 2 * NANO))
        result = {'exit': job.poll() if job is not None else None, 'stop': stopped,
            'start_ns': start, 'child_exit_ns': child_exit_at, 'finished_ns': time.monotonic_ns(),
            'zero_descendants': owner.empty(), 'cleanup_on_time': clean,
            'observed_identities': sorted(seen), 'events': owner.events,
            'peak_bytes': maximum, 'proof_accepted': False}
        write(folder / 'worker.json', result)
        owner.close()
    return 0 if stopped is None and clean and result['zero_descendants'] and result['exit'] is not None else 1


def run(spec_path):
    spec = read(spec_path)
    folder = Path(spec['output'])
    folder.mkdir()
    start = time.monotonic_ns()
    final = start + int(spec['active_seconds'] * NANO)
    command = ['/usr/bin/python3', '-B', str(Path(__file__).resolve()), '--worker',
               str(spec_path), str(start), str(final)]
    owner = OwnedTree()
    write(folder / 'process.json', {'host': identity(os.getpid()), 'start_ns': start,
        'final_ns': final, 'spec': str(spec_path), 'command': command})
    with (folder / 'supervisor.log').open('xb') as log:
        observation = monitor(owner, command, OUT, log,
            {'term': final - 2*NANO, 'kill': final - NANO, 'final': final})
    write(folder / 'observation.json', observation)
    owner.close()
    result_path = folder / 'worker.json'
    result = read(result_path) if result_path.exists() else None
    accepted = (observation['exit'] == 0 and observation['stop'] is None
        and observation['zero_descendants'] and observation['zero_descendants_ns'] < final
        and result is not None and result['exit'] is not None and result['stop'] is None
        and result['zero_descendants'] and result['cleanup_on_time']
        and start <= result['start_ns'] <= result['child_exit_ns'] <= result['finished_ns'] < final)
    write(folder / 'execution.json', {'execution_complete': accepted,
        'exit': None if result is None else result['exit'],
        'seconds': (observation['zero_descendants_ns'] - start)/NANO,
        'proof_accepted': False, 'semantic_acceptance': 'pending'})
    print(json.dumps(read(folder / 'execution.json')), flush=True)
    return 0 if accepted else 1


if __name__ == '__main__':
    if sys.argv[1] == '--worker':
        sys.exit(worker(Path(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])))
    sys.exit(run(Path(sys.argv[1])))
