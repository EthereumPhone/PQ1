"""One scoped root-cost/admissibility probe; never a complete proof verdict."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding
sys.path.insert(0, str(N / 'kani-promoted-entry-candidate/scripts'))
import pq1_partition as p


def main():
    folder = OUT / 'root-probe-unwind65'
    refinement = read(OUT / 'unwind-refinement-selection-v1.json')
    prior = read(OUT / 'root-probe/assessment.json')
    assert not prior['root_semantics_accepted'] and not prior['execution']['execution_complete']
    assert sha(OUT / 'root-probe/assessment.json') == refinement['prior_assessment_sha256']
    folder.mkdir()
    census = read(OUT / 'census/assessment.json')
    assert census['preparation_and_census_complete'] and census['strict_inherited_parser_refusal'] is None
    properties = p.census((OUT / 'census/inventory/run/command.log').read_text())
    assert properties == read(OUT / 'census/properties.json')
    assert len(properties) == 2324
    program = OUT / 'census/prepared.out'
    assert sha(program) == census['program_sha256']
    harness = read(OUT / 'selection.json')['harness']
    wanted = {
        'output is final-state big-endian byte': ('assertion', 189, 'SUCCESS'),
        'finalization preserves input block counter': ('assertion', 190, 'SUCCESS'),
        'finalization resets buffer position': ('assertion', 191, 'SUCCESS'),
        'empty buffered suffix reaches final output': ('cover', 193, 'FAILURE'),
        'last single-padding-block position reaches final output': ('cover', 194, 'FAILURE'),
        'first double-padding-block position reaches final output': ('cover', 195, 'FAILURE'),
        'last output byte and last representable length reach final output': ('cover', 196, 'FAILURE'),
    }
    groups = p.groups(properties)
    required = {}
    roots = {}
    for description, (kind, line, status) in wanted.items():
        matches = [(name, row) for name, row in properties.items()
                   if row['class'] == kind and row['sourceLocation'].get('function') == harness
                   and row['sourceLocation'].get('file') == 'src/core_api.rs'
                   and int(row['sourceLocation'].get('line', 0)) == line
                   and (row['description'] == description or row['description'].endswith('] ' + description))]
        assert len(matches) == 1, (description, matches)
        name, row = matches[0]
        required[name] = status
        group = next(g for g in groups if name in g)
        if kind == 'cover':
            assert len(group) == 2
            probe = next(n for n in group if n != name)
            assert properties[probe]['class'] == 'reachability_check'
            required[probe] = 'FAILURE'
        else:
            # In this no_std root, ordinary Rust assert! lowers to a guarded
            # panic assertion. FALSE is on the failure branch, not an assumed
            # theorem. All four required source covers are after all assertions.
            assert row['expression'] == 'FALSE' and group == [name]
        roots[description] = group
    parts = p.partition(properties, list(required))
    p.validate_partition(properties, parts, list(required))
    assert len(parts) == 19
    selection = {
        'stage': 'A bounded root feasibility only', 'case': 'root',
        'source_scope': read(OUT / 'selection.json')['universal_input_scope'],
        'program': str(program), 'program_sha256': sha(program),
        'census_sha256': sha(OUT / 'census/properties.json'), 'roots': roots,
        'required': required, 'parts': parts, 'selected_partition': 0,
        'static_property_count': len(properties), 'selected_properties': len(parts[0]),
        'unselected_partitions': list(range(1, len(parts))),
        'ordinary_assertion_lowering': 'Three Rust no_std assertions are guarded failure-path FALSE checks. Their SUCCESS must be paired with the four reached post-assertion covers; no direct KANI_CHECK_ID reachability pair is claimed for these three.',
        'loop_override': refinement,
        'limits': {'active_seconds': 180, 'cpu_soft_seconds': 170, 'cpu_hard_seconds': 175,
                   'address_space_bytes': 16 * 1024**3, 'file_bytes': 16 * 1024**2},
        'sat_solver': 'minisat2', 'whole_proof_accepted': False,
        'stop': 'Exactly one root query. Preserve failures and unresolved properties; do not infer the unselected 18 partitions or any full Digest theorem.',
        'next': 'Use actual root outcome/cost to select the full remaining guard proof or reproduce a concrete refusal. No automatic repeated query.'}
    write(folder / 'selection.json', selection)
    pins = {**read(OUT / 'codegen/pins.json'), **read(OUT / 'codegen/assessment.json')['metadata_and_lock_pins']}
    pins.update(runtime_binding.require_runtime())
    for path in [Path(__file__), Path(p.__file__), program, folder / 'selection.json',
                 OUT / 'unwind-refinement-selection-v1.json', OUT / 'root-probe/assessment.json',
                 OUT / 'census/assessment.json', OUT / 'census/properties.json', OUT / 'census/inventory/run/command.log']:
        pins[str(path)] = sha(path)
    links = read(OUT / 'codegen/links.json')
    authenticate(pins, links)
    mem_available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                             if x.startswith('MemAvailable:'))) * 1024
    assert mem_available >= 32 * 1024**3
    command = ['/usr/bin/prlimit', '--cpu=170:175', '--as=17179869184:17179869184',
               '--fsize=16777216:16777216', '--core=0:0', '--', *census['base_command'],
               '--verbosity', '8', '--unwindset', refinement['loop_id'] + ':65']
    for name in parts[0]:
        command.extend(['--property', name])
    command.append(str(program))
    spec = {**read(OUT / 'codegen/spec.json'), 'command': command, 'output': str(folder / 'run'),
            'active_seconds': 180, 'selection_sha256': sha(folder / 'selection.json')}
    spec['allocation_before'] = execute.measure(N, spec)
    assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
    assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
    write(folder / 'spec.json', spec)
    write(folder / 'pins.json', pins)
    print(json.dumps({'root_selected': True, 'properties': len(parts[0]), 'total_properties': len(properties),
                      'active_seconds': 180, 'whole_proof_accepted': False}), flush=True)
    with (folder / 'host.log').open('x') as log:
        host = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(folder / 'spec.json')],
                              stdout=log, stderr=subprocess.STDOUT)
    execution = read(folder / 'run/execution.json')
    authenticate(pins, links)
    runtime_binding.require_runtime()
    assessment = {'host_exit': host.returncode, 'execution': execution, 'inputs_and_runtime_unchanged': True,
                  'raw_log_sha256': sha(folder / 'run/command.log'), 'root_semantics_accepted': False,
                  'whole_proof_accepted': False, 'static_property_count': len(properties),
                  'selected_properties': len(parts[0]), 'unproved_partitions': list(range(1, len(parts)))}
    if host.returncode == 0 and execution['execution_complete'] and execution['exit'] in [0, 10]:
        try:
            report = p.parse_report((folder / 'run/command.log').read_text(), properties, parts[0], execution['exit'])
            write(folder / 'parsed-report.json', report)
            p.semantic_check(properties, report, required)
            assessment['root_semantics_accepted'] = True
            assessment['required_results'] = {name: report['rows'][name] for name in required}
            assessment['dynamic_properties'] = report['dynamic']
        except (ValueError, AssertionError) as error:
            assessment['semantic_or_parser_failure'] = repr(error)
    assessment['unproved_partitions'] = list(range(1 if assessment['root_semantics_accepted'] else 0, len(parts)))
    assessment['debit_seconds'] = execution['seconds'] if execution['execution_complete'] else 180
    assessment['cumulative_probe_debit_seconds'] = 180 + assessment['debit_seconds']
    write(folder / 'assessment.json', assessment)
    print(json.dumps(assessment, indent=2), flush=True)


if __name__ == '__main__':
    main()
