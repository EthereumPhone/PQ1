"""One independently bounded remaining-guard feasibility run, not adoption."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
LIB = N / 'cbmc-negative-group-budget-candidate/scripts/pq1_budget'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding
sys.path.insert(0, str(LIB))
from collect_continuation import parse_partial, compose_reports, partition


def main():
    folder = OUT / 'tail-probe-v1'
    folder.mkdir()
    prior = read(OUT / 'root-probe-unwind65/selection.json')
    accepted = read(OUT / 'root-current-parser-assessment-v1.json')
    assert accepted['root_semantics_accepted'] and not accepted['whole_proof_accepted']
    properties = partition.census((OUT / 'census/inventory/run/command.log').read_text())
    assert properties == read(OUT / 'census/properties.json')
    parts, required = prior['parts'], prior['required']
    partition.validate_partition(properties, parts, required)
    assert len(properties) == 2324 and len(parts) == 19 and len(parts[0]) == 101
    root_path = OUT / 'root-probe-unwind65/run/command.log'
    assert sha(root_path) == accepted['raw_log_sha256']
    root = partition.parse_report(root_path.read_text(), properties, parts[0], 10)
    partition.semantic_check(properties, root, required)
    assert root == accepted['reports']
    assert sha(LIB / 'pq1_partition.py') == accepted['parser_sha256']
    program = OUT / 'census/prepared.out'
    assert sha(program) == prior['program_sha256']
    groups = parts[1:]
    write(folder / 'groups.json', groups)
    selection = {
        'phase': 'A complete-guard feasibility for D3a, not publication/adoption',
        'root_assessment_sha256': sha(OUT / 'root-current-parser-assessment-v1.json'),
        'program_sha256': sha(program), 'properties_sha256': sha(OUT / 'census/properties.json'),
        'groups_sha256': sha(folder / 'groups.json'), 'group_count': 18,
        'selected_static_count': sum(map(len, groups)), 'all_static_count': 2324,
        'protocol': 'Existing scoped partial backend, one shared symbolic execution and fresh per-group SAT contexts. No group ACK selected for this independent feasibility attempt; one 900-second whole-run cap replaces no pre-existing case rule. This is not inherited C3 fixed-empty timing credit.',
        'acceptance': 'All raw groups, exact full static union with the prior root, identical successful dynamic unwind set, all ordinary and fatal checks SUCCESS, exact source/runtime identity. Covers and their reachability checks retain original semantics.',
        'limits': {'active_seconds': 900, 'cpu_soft_seconds': 890, 'cpu_hard_seconds': 895,
                   'address_space_bytes': 16*1024**3, 'file_bytes': 16*1024**2},
        'stop': 'One run; preserve any resource, diagnostic or semantic failure. No automatic retry. No complete component or unrestricted Digest claim without remaining source controls and review.'}
    write(folder / 'selection.json', selection)
    census = read(OUT / 'census/assessment.json')
    refinement = read(OUT / 'unwind-refinement-selection-v1.json')
    command = ['/usr/bin/prlimit', '--cpu=890:895', '--as=17179869184:17179869184',
               '--fsize=16777216:16777216', '--core=0:0', '--', *census['base_command'],
               '--verbosity', '8', '--unwindset', refinement['loop_id'] + ':65',
               '--flush', '--pq1-scoped-partitions', str(folder / 'groups.json'),
               '--pq1-scoped-partial', str(program)]
    pins = {**read(OUT / 'root-probe-unwind65/pins.json'), **runtime_binding.require_runtime()}
    reviewed = read(W / 'full-binding-v1/positive/selection.json')['integration_pins']
    for path in LIB.glob('*.py'):
        assert reviewed[str(path)] == sha(path), ('unreviewed protocol', path)
        pins[str(path)] = reviewed[str(path)]
    for path in [Path(__file__), folder / 'selection.json', folder / 'groups.json',
                 OUT / 'root-current-parser-assessment-v1.json', root_path,
                 OUT / 'root-probe-unwind65/assessment.json']:
        pins[str(path)] = sha(path)
    links = read(OUT / 'codegen/links.json')
    authenticate(pins, links)
    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                         if x.startswith('MemAvailable:'))) * 1024
    assert available >= 32*1024**3
    spec = {**read(OUT / 'codegen/spec.json'), 'command': command,
            'output': str(folder / 'run'), 'active_seconds': 900,
            'selection_sha256': sha(folder / 'selection.json')}
    spec['allocation_before'] = execute.measure(N, spec)
    assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
    assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
    write(folder / 'pins.json', pins)
    write(folder / 'spec.json', spec)
    print(json.dumps({'selected': True, 'groups': 18, 'properties': 2223,
                      'whole_run_seconds': 900, 'phase': 'A feasibility'}), flush=True)
    with (folder / 'host.log').open('x') as log:
        result = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(folder / 'spec.json')],
                                stdout=log, stderr=subprocess.STDOUT)
    execution = read(folder / 'run/execution.json')
    authenticate(pins, links)
    runtime_binding.require_runtime()
    assessment = {'host_exit': result.returncode, 'execution': execution,
                  'inputs_and_runtime_unchanged': True, 'raw_log_sha256': sha(folder / 'run/command.log'),
                  'complete_positive_feasibility': False, 'component_adopted': False,
                  'full_Digest_proof': False}
    if result.returncode == 0 and execution['execution_complete'] and execution['exit'] in [0, 10]:
        try:
            tails = parse_partial((folder / 'run/command.log').read_text(), properties, groups, execution['exit'])
            write(folder / 'parsed-reports.json', tails)
            proof = compose_reports(properties, parts, list(range(19)), root, tails, required)
            assessment.update(complete_positive_feasibility=True, proof=proof)
        except (ValueError, AssertionError) as error:
            assessment['semantic_or_parser_failure'] = repr(error)
    assessment['debit_seconds'] = execution['seconds'] if execution['execution_complete'] else 900
    assessment['cumulative_probe_debit_seconds'] = 304.328064977 + assessment['debit_seconds']
    write(folder / 'assessment.json', assessment)
    print(json.dumps(assessment, indent=2), flush=True)


if __name__ == '__main__':
    main()
