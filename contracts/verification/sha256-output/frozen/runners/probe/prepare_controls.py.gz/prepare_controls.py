"""Prepare isolated causal controls. No compilation or solver is launched."""
from pathlib import Path
import json
import shutil
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT))
from prepare import sha, read, write


def main():
    root = OUT / 'controls-v1'
    root.mkdir()
    pins = read(OUT / 'input-pins.json')
    assert all(sha(p) == digest for p, digest in pins.items())
    original = OUT / 'inputs/sha2-probe/src/core_api.rs'
    original_text = original.read_text()
    cases = {}
    for kind in ['little-endian', 'omitted-word', 'unreachable']:
        case = root / kind
        (case / 'inputs').mkdir(parents=True)
        for source, expected in pins.items():
            path = Path(source)
            target = case / path.relative_to(OUT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            assert sha(target) == expected
        project = case / 'inputs/sha2-probe'
        config = project / '.cargo/config.toml'
        config.write_text(config.read_text().replace(str(OUT / 'inputs/vendor'), str(case / 'inputs/vendor')))
        text = original_text
        edits = []

        def replace(old, new, count=1):
            nonlocal text
            assert text.count(old) >= count
            text = text.replace(old, new, count)
            edits.append({'before': old, 'after': new, 'count': count})

        if kind != 'unreachable':
            # A concrete member of the full positive input domain. These are
            # finite causal controls, not negative universal theorem claims.
            for old, new in [
                ('let initial_state: [u32; 8] = kani::any();', 'let initial_state: [u32; 8] = [0; 8];'),
                ('let initial_buffer: [u8; 64] = kani::any();', 'let initial_buffer: [u8; 64] = [0; 64];'),
                ('let initial_output: [u8; 32] = kani::any();', 'let initial_output: [u8; 32] = [0; 32];'),
                ('let position: usize = kani::any();', 'let position: usize = 0;'),
                ('let block_count: u64 = kani::any();', 'let block_count: u64 = 0;'),
                ('let byte_index: usize = kani::any();', 'let byte_index: usize = 31;'),
            ]:
                replace(old, new)
            if kind == 'little-endian':
                replace('chunk.copy_from_slice(&v.to_be_bytes());', 'chunk.copy_from_slice(&v.to_le_bytes());')
            else:
                replace('out.chunks_exact_mut(4)', 'out[..28].chunks_exact_mut(4)')
        else:
            replace('        core.finalize_variable_core(&mut buffer, &mut output);',
                    '        kani::assume(false); core.finalize_variable_core(&mut buffer, &mut output);')
        core = project / 'src/core_api.rs'
        core.write_text(text)
        assert text != original_text and len(text.splitlines()) == len(original_text.splitlines())
        changed = {}
        for source, expected in pins.items():
            target = case / Path(source).relative_to(OUT)
            if sha(target) != expected:
                changed[str(target.relative_to(case))] = sha(target)
        assert set(changed) == {'inputs/sha2-probe/src/core_api.rs', 'inputs/sha2-probe/.cargo/config.toml'}
        fresh_pins = {str(p): sha(p) for p in (case / 'inputs').rglob('*') if p.is_file()}
        write(case / 'input-pins.json', fresh_pins)
        write(case / 'source-control.json', {
            'kind': kind, 'positive_source_sha256': sha(original), 'source_sha256': sha(core),
            'edits': edits, 'changed_input_files': changed,
            'expected_result': ('Complete verification rows have the output-byte assertion as their only failing ordinary property; actual guards remain enabled. A crash, timeout, setup error or unrelated failure is not the intended control.'
                                if kind != 'unreachable' else
                                'All output assertions may report SUCCESS, but original required post-assertion covers are not reached and the unchanged semantic checker must refuse the result.'),
            'input_scope': ('One fixed valid input: zero state/buffer/output, position/count zero and observed byte 31. The positive arbitrary-state theorem contains this input.'
                            if kind != 'unreachable' else
                            'Original symbolic inputs with a deliberately false additional assumption before actual finalization.'),
            'positive_evidence_credit': False,
        })
        cases[kind] = {'input_pins_sha256': sha(case / 'input-pins.json'),
                       'source_control_sha256': sha(case / 'source-control.json')}
    write(root / 'preparation.json', {
        'surface': '#1097 D3a actual final-state serialization',
        'phase': 'A preparation; execute only after the complete positive feasibility result',
        'cases': cases, 'positive_input_pins_sha256': sha(OUT / 'input-pins.json'),
        'source_changes_outside_isolated_controls': 0, 'commands_launched': 0,
        'next_review_boundary': 'Combine full positive inventory, causal controls, source bindings and honest scope in one candidate review before publication.'})
    print(json.dumps({'prepared_controls': list(cases), 'compiler_or_solver_launched': False}))


if __name__ == '__main__':
    main()
