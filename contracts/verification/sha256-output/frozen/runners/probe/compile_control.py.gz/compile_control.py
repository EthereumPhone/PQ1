"""Compile one prepared causal control after complete positive feasibility."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
import census
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding


def main(kind):
    assert kind in ['little-endian', 'omitted-word', 'unreachable']
    positive = read(OUT / 'tail-probe-v1/assessment.json')
    assert positive['complete_positive_feasibility']
    assert positive['execution']['execution_complete']
    case = OUT / 'controls-v1' / kind
    assert not (case / 'codegen').exists()
    prepared = read(OUT / 'controls-v1/preparation.json')['cases'][kind]
    assert sha(case / 'source-control.json') == prepared['source_control_sha256']
    assert sha(case / 'input-pins.json') == prepared['input_pins_sha256']
    original_pins = read(OUT / 'codegen/pins.json')
    pins = {**original_pins, **read(case / 'input-pins.json'), **runtime_binding.require_runtime()}
    for path in [Path(__file__), Path(census.__file__), case / 'source-control.json',
                 case / 'input-pins.json', OUT / 'controls-v1/preparation.json',
                 OUT / 'tail-probe-v1/assessment.json']:
        pins[str(path)] = sha(path)
    links = read(OUT / 'codegen/links.json')
    authenticate(pins, links)
    selection = {'phase': 'C isolated source-control translation and static inventory',
                 'control': kind, 'harness': read(OUT / 'selection.json')['harness'],
                 'source_control_sha256': sha(case / 'source-control.json'),
                 'positive_assessment_sha256': sha(OUT / 'tail-probe-v1/assessment.json'),
                 'compiler_active_seconds': 180, 'cpu_limits': [170, 175],
                 'census': 'Reuse the byte-identical census.main function with its OUT working-directory global set to this isolated control. All other globals, tools, guards and metadata requirements remain unchanged.',
                 'census_per_command_seconds': 60, 'solver_runs_selected': 0,
                 'stop': 'One code generation plus five static preparation/census commands; stop on first failure. No negative-control credit from translation alone.'}
    write(case / 'selection.json', selection)
    pins[str(case / 'selection.json')] = sha(case / 'selection.json')
    base = read(OUT / 'codegen/spec.json')
    env = dict(base['environment'])
    for name in ['cargo-home', 'tmp']:
        (case / name).mkdir()
    env.update(CARGO_HOME=str(case / 'cargo-home'), TMPDIR=str(case / 'tmp'),
               CARGO_TARGET_DIR=str(case / 'target'))
    command = list(base['command'])
    command[1] = '--cpu=170:175'
    index = command.index('--manifest-path') + 1
    command[index] = str(case / 'inputs/sha2-probe/Cargo.toml')
    assert command[-1] == '--only-codegen'
    folder = case / 'codegen'
    folder.mkdir()
    spec = {**base, 'command': command, 'environment': env,
            'cwd': str(case / 'inputs/sha2-probe'), 'output': str(folder / 'run'),
            'active_seconds': 180, 'selection_sha256': sha(case / 'selection.json')}
    spec['allocation_before'] = execute.measure(N, spec)
    assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
    assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                         if x.startswith('MemAvailable:'))) * 1024
    assert available >= 32*1024**3
    write(folder / 'pins.json', pins)
    write(folder / 'links.json', links)
    write(folder / 'spec.json', spec)
    print(json.dumps({'control': kind, 'codegen_started': True, 'solver_selected': False}), flush=True)
    with (folder / 'host.log').open('x') as log:
        host = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(folder / 'spec.json')],
                              stdout=log, stderr=subprocess.STDOUT)
    execution = read(folder / 'run/execution.json')
    authenticate(pins, links)
    runtime_binding.require_runtime()
    metadata = list((case / 'target').rglob('*.kani-metadata.json'))
    outputs = {str(path): sha(path) for path in metadata}
    lock = case / 'inputs/sha2-probe/Cargo.lock'
    if lock.exists():
        outputs[str(lock)] = sha(lock)
    complete = host.returncode == 0 and execution['execution_complete'] and execution['exit'] == 0 and len(metadata) == 1
    assessment = {'codegen_complete': complete, 'host_exit': host.returncode,
                  'independent_execution': execution, 'inputs_and_runtime_unchanged': True,
                  'metadata_and_lock_pins': outputs, 'solver_runs': 0,
                  'negative_control_accepted': False}
    write(folder / 'assessment.json', assessment)
    print(json.dumps(assessment, indent=2), flush=True)
    assert complete, 'control code generation did not complete'
    # Directory is the only bound parameter of the existing census operation.
    # This does not modify its source file or any proof/model implementation.
    census.OUT = case
    census.main()


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
