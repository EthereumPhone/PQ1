"""Prepare and inventory the actual GOTO program; no SAT query or proof credit."""
from pathlib import Path
import collections
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding
sys.path.insert(0, str(N / 'kani-promoted-entry-candidate/scripts'))
import pq1_partition as partition


def main():
    root = OUT / 'census'
    root.mkdir()
    original = read(OUT / 'codegen/assessment.json')
    assert original['codegen_complete'] and original['solver_runs'] == 0
    pins = {**read(OUT / 'codegen/pins.json'), **original['metadata_and_lock_pins']}
    links = read(OUT / 'codegen/links.json')
    pins.update(runtime_binding.require_runtime())
    for path in [Path(__file__), OUT / 'codegen/assessment.json', Path(partition.__file__)]:
        pins[str(path)] = sha(path)
    authenticate(pins, links)
    files = list((OUT / 'target').rglob('*.kani-metadata.json'))
    assert len(files) == 1
    metadata = read(files[0])
    assert not metadata['unsupported_features'] and not metadata['test_harnesses']
    assert not metadata['contracted_functions'] and metadata['autoharness_md'] is None
    assert len(metadata['proof_harnesses']) == 1
    harness = metadata['proof_harnesses'][0]
    assert harness['pretty_name'] == read(OUT / 'selection.json')['harness']
    assert harness['original_file'] == 'src/core_api.rs'
    assert (harness['original_start_line'], harness['original_end_line']) == (166, 198)
    assert harness['attributes'] == {'kind': 'Proof', 'should_panic': False, 'solver': None,
                                     'unwind_value': 193, 'stubs': [], 'verified_stubs': []}
    assert harness['contract'] is None and not harness['has_loop_contracts']
    assert not harness['is_automatically_generated'] and not harness['is_bounded'] and not harness['is_ctor_based']
    assert not list((OUT / 'target').rglob('*restrictions*'))
    symtab = Path(harness['goto_file'])
    linked = symtab.with_name(symtab.name.removesuffix('.symtab.out') + '.out')
    assert symtab.is_relative_to(OUT / 'target') and linked.is_file()
    pins[str(symtab)] = sha(symtab)
    pins[str(linked)] = sha(linked)
    program = root / 'prepared.out'
    shutil.copy2(linked, program)
    assert sha(program) == sha(linked)
    bindings = read(W / 'consumer-selection-runtime-v3.json')['bindings']
    cc, instrument, cbmc = (bindings[key] for key in ['goto-cc', 'goto-instrument', 'cbmc'])
    phases = [
        ('entry', [cc, str(program), '--function', harness['mangled_name'], '-o', str(program)]),
        ('library', [instrument, '--add-library', '--no-malloc-may-fail', str(program), str(program)]),
        ('undefined', [instrument, '--generate-function-body-options', 'assert-false-assume-false',
                       '--generate-function-body', '.*', '--drop-unused-functions', str(program), str(program)]),
        ('backedges', [instrument, '--ensure-one-backedge-per-target', str(program), str(program)]),
    ]
    flags = list(partition.FLAGS)
    assert flags[flags.index('--sat-solver') + 1] == 'cadical'
    flags[flags.index('--sat-solver') + 1] = 'minisat2'
    base_command = [cbmc, *flags, '--unwind', '193']
    phases.append(('inventory', base_command + ['--show-properties', '--json-ui', str(program)]))
    base_spec = read(OUT / 'codegen/spec.json')
    selection = {'stage': 'GOTO preparation and static census only', 'phases': phases,
                 'per_command_active_seconds': 60, 'per_command_cpu_seconds': [50, 55],
                 'maximum_cumulative_command_seconds': 300, 'address_space_bytes': 16 * 1024**3,
                 'file_bytes': 128 * 1024**2, 'workspace_bytes': base_spec['workspace'],
                 'aggregate_bytes': base_spec['aggregate_cap'], 'host_floor_bytes': base_spec['host_floor'],
                 'reserve_bytes': base_spec['reserve'], 'harness': harness, 'pins': pins,
                 'solver_queries_selected': 0, 'proof_accepted': False,
                 'stop': 'Stop at first command/identity/resource failure; preserve all outputs and never interpret static census as a proof.'}
    write(root / 'selection.json', selection)
    receipts = []
    total = 0.0
    for name, inner in phases:
        authenticate(pins, links)
        phase = root / name
        phase.mkdir()
        before = sha(program)
        command = ['/usr/bin/prlimit', '--cpu=50:55', '--as=17179869184:17179869184',
                   '--fsize=134217728:134217728', '--core=0:0', '--', *inner]
        spec = {**base_spec, 'command': command, 'output': str(phase / 'run'), 'active_seconds': 60,
                'selection_sha256': sha(root / 'selection.json')}
        spec['allocation_before'] = execute.measure(N, spec)
        assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
        assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
        write(phase / 'spec.json', spec)
        with (phase / 'host.log').open('x') as log:
            host = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(phase / 'spec.json')],
                                  stdout=log, stderr=subprocess.STDOUT)
        result = read(phase / 'run/execution.json')
        total += result['seconds']
        receipt = {'phase': name, 'host_exit': host.returncode, 'execution': result,
                   'before_sha256': before, 'after_sha256': sha(program),
                   'raw_log_sha256': sha(phase / 'run/command.log')}
        write(phase / 'receipt.json', receipt)
        receipts.append(receipt)
        assert host.returncode == 0 and result['execution_complete'] and result['exit'] == 0, receipt
        assert total < 300
        assert execute.measure(N, spec) < min(spec['aggregate_cap'] - spec['reserve'], spec['allocation_before'] + spec['workspace'])
        print(name, round(result['seconds'], 3), flush=True)
    authenticate(pins, links)
    runtime_binding.require_runtime()
    text = (root / 'inventory/run/command.log').read_text()
    rows = partition.loads(text)
    inventory = [entry['properties'] for entry in rows if 'properties' in entry]
    assert len(inventory) == 1
    properties = {entry['name']: entry for entry in inventory[0]}
    assert len(properties) == len(inventory[0]) and properties
    parser_refusal = None
    try:
        assert partition.census(text) == properties
        groups = partition.groups(properties)
    except (ValueError, AssertionError) as error:
        parser_refusal = repr(error)
        groups = None
    roots = {name: entry for name, entry in properties.items()
             if entry.get('sourceLocation', {}).get('function') == harness['pretty_name']}
    write(root / 'properties.json', properties)
    write(root / 'root-properties.json', roots)
    report = {'preparation_and_census_complete': True, 'program_sha256': sha(program),
              'property_count': len(properties), 'classes': dict(collections.Counter(x['class'] for x in properties.values())),
              'root_property_count': len(roots), 'strict_inherited_parser_refusal': parser_refusal,
              'reachability_groups': None if groups is None else len(groups), 'commands_seconds': total,
              'source_and_runtime_unchanged': True, 'base_command': base_command,
              'solver_queries': 0, 'proof_accepted': False,
              'next': 'Inspect exact root semantics, safety/refusal guards and any census limitations before a bounded solver selection.'}
    write(root / 'assessment.json', report)
    print(report, flush=True)


if __name__ == '__main__':
    main()
