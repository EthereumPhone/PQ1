"""One full-census causal query for a prepared, compiled source control."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
LIB = N / 'cbmc-negative-group-budget-candidate/scripts/pq1_budget'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding
sys.path.insert(0, str(LIB))
import pq1_promoted_census as partition


def main(kind):
    assert kind in ['little-endian', 'omitted-word', 'unreachable']
    case = OUT / 'controls-v1' / kind
    assert read(OUT / 'tail-probe-v1/assessment.json')['complete_positive_feasibility']
    census = read(case / 'census/assessment.json')
    assert census['preparation_and_census_complete'] and census['strict_inherited_parser_refusal'] is None
    properties = partition.census((case / 'census/inventory/run/command.log').read_text())
    assert properties == read(case / 'census/properties.json')
    program = case / 'census/prepared.out'
    assert sha(program) == census['program_sha256']
    wanted = 'output is final-state big-endian byte'
    matches = [n for n, p in properties.items() if p['class'] == 'assertion'
               and p['description'] == wanted and p['sourceLocation']['file'] == 'src/core_api.rs'
               and p['sourceLocation']['line'] == '189'
               and p['sourceLocation']['function'] == read(case / 'selection.json')['harness']]
    assert len(matches) == 1
    intended = matches[0]
    folder = case / 'verification'
    folder.mkdir()
    selection = {'control': kind, 'stage': 'C source-control query, not a positive proof',
                 'program_sha256': sha(program), 'census_sha256': sha(case / 'census/properties.json'),
                 'source_control_sha256': sha(case / 'source-control.json'),
                 'selected_properties': len(properties), 'selection': 'complete static census; no property filtering',
                 'expected_ordinary_failure': None if kind == 'unreachable' else intended,
                 'limits': {'active_seconds': 180, 'cpu_soft_seconds': 170, 'cpu_hard_seconds': 175,
                            'address_space_bytes': 16*1024**3, 'file_bytes': 16*1024**2},
                 'unwind': '65 for these concrete finite controls; every dynamic unwinding assertion must succeed. No loop is assumed complete.',
                 'stop': 'One query; a timeout, missing row, unrelated failure or failed guard is never a valid control. Preserve the result with no automatic retry.'}
    write(folder / 'selection.json', selection)
    base = list(census['base_command'])
    assert base[base.index('--unwind') + 1] == '193'
    base[base.index('--unwind') + 1] = '65'
    command = ['/usr/bin/prlimit', '--cpu=170:175', '--as=17179869184:17179869184',
               '--fsize=16777216:16777216', '--core=0:0', '--', *base,
               '--verbosity', '8', str(program)]
    pins = {**read(case / 'census/selection.json')['pins'], **runtime_binding.require_runtime()}
    reviewed = read(W / 'full-binding-v1/positive/selection.json')['integration_pins']
    for path in [LIB / 'pq1_partition.py', LIB / 'pq1_promoted_census.py']:
        assert sha(path) == reviewed[str(path)]
        pins[str(path)] = reviewed[str(path)]
    for path in [Path(__file__), program, folder / 'selection.json', case / 'census/assessment.json',
                 case / 'census/properties.json', case / 'source-control.json']:
        pins[str(path)] = sha(path)
    links = read(case / 'codegen/links.json')
    authenticate(pins, links)
    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                         if x.startswith('MemAvailable:'))) * 1024
    assert available >= 32*1024**3
    spec = {**read(case / 'codegen/spec.json'), 'command': command, 'output': str(folder / 'run'),
            'active_seconds': 180, 'selection_sha256': sha(folder / 'selection.json')}
    spec['allocation_before'] = execute.measure(N, spec)
    assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
    assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
    write(folder / 'pins.json', pins)
    write(folder / 'spec.json', spec)
    print(json.dumps({'control': kind, 'full_census_properties': len(properties), 'query_started': True}), flush=True)
    with (folder / 'host.log').open('x') as log:
        host = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(folder / 'spec.json')],
                              stdout=log, stderr=subprocess.STDOUT)
    execution = read(folder / 'run/execution.json')
    authenticate(pins, links)
    runtime_binding.require_runtime()
    result = {'control': kind, 'host_exit': host.returncode, 'execution': execution,
              'inputs_and_runtime_unchanged': True, 'raw_log_sha256': sha(folder / 'run/command.log'),
              'negative_control_accepted': False, 'positive_proof_credit': False}
    if host.returncode == 0 and execution['execution_complete'] and execution['exit'] in [0, 10]:
        try:
            report = partition.parse_report((folder / 'run/command.log').read_text(), properties,
                                            list(properties), execution['exit'])
            write(folder / 'parsed-report.json', report)
            assert all(report['rows'][n] == 'SUCCESS' for n, row in properties.items()
                       if row['sourceLocation'].get('propertyFatal'))
            if kind == 'unreachable':
                partition.semantic_check(properties, report, {})
                positive_required = read(OUT / 'root-probe-unwind65/selection.json')['required']
                assert set(positive_required) <= set(properties)
                assert all(report['rows'][n] == 'SUCCESS' for n in positive_required)
                try:
                    partition.semantic_check(properties, report, positive_required)
                except ValueError as error:
                    assert str(error) == 'required root unreachable or wrong'
                    result['expected_refusal'] = str(error)
                else:
                    raise ValueError('unreachable control incorrectly passed positive semantics')
            else:
                partition.semantic_check(properties, report, {}, expected_failure=intended)
                assert report['rows'][intended] == 'FAILURE'
                result['intended_failure'] = intended
            result.update(negative_control_accepted=True, static_properties=len(properties),
                          dynamic_properties=len(report['dynamic']))
        except (ValueError, AssertionError) as error:
            result['unexpected_result'] = repr(error)
    result['debit_seconds'] = execution['seconds'] if execution['execution_complete'] else 180
    write(folder / 'assessment.json', result)
    print(json.dumps(result, indent=2), flush=True)
    assert result['negative_control_accepted'], 'source control did not satisfy its causal oracle'


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
