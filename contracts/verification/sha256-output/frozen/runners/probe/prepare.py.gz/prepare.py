"""Prepare a source-preserving finalization observer, without a solver run."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import sys

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
BASE = P / 'promoted-full-digest-v1/positive/inputs'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert not (OUT / 'selection.json').exists()
    adoption = read(P / 'combined-digest-private-adoption-v1.json')
    assert adoption['closure_checklist_complete'] and not adoption['mandatory_gaps']
    assert sha(P / 'combined-digest-private-adoption-v1.json') == 'bf447c5dddf0fd6847127ff9631452857a61aa7cead9411e09c5eb01c3a943f3'
    inputs = OUT / 'inputs'
    inputs.mkdir()
    original = {}
    for manifest, expected in read(W / 'full-binding-v1/input-pins.json').items():
        assert sha(manifest) == expected
        original.update(read(manifest))
    copied = {}

    def copy_tree(src, dst):
        for path in sorted(src.rglob('*')):
            assert not path.is_symlink(), ('unexpected input symlink', path)
            if not path.is_file():
                continue
            digest = sha(path)
            assert original.get(str(path)) == digest, ('source outside accepted preparation', path)
            target = dst / path.relative_to(src)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            assert sha(target) == digest
            copied[str(target)] = {'original': str(path), 'sha256': digest}

    copy_tree(BASE / 'vendor', inputs / 'vendor')
    copy_tree(BASE / 'generic-array-corrected', inputs / 'generic-array-corrected')
    project = inputs / 'sha2-probe'
    copy_tree(BASE / 'vendor/sha2-0.10.9/src', project / 'src')
    for name in ['LICENSE-MIT', 'LICENSE-APACHE']:
        source = BASE / 'vendor/sha2-0.10.9' / name
        assert original[str(source)] == sha(source)
        shutil.copy2(source, project / name)
        copied[str(project / name)] = {'original': str(source), 'sha256': sha(source)}

    # Isolated proof package root: only the selected portable/no-std configuration.
    # Upstream executable Rust is copied unchanged; only a cfg(kani) observer is appended.
    manifest = '''[package]
name = "sha2"
version = "0.10.9"
edition = "2018"
build = false
autotests = false
autobenches = false
autoexamples = false
[workspace]
[lib]
path = "src/lib.rs"
[dependencies]
cfg-if = "=1.0.4"
digest = "=0.10.7"
cpufeatures = "=0.2.17"
[features]
default = []
force-soft = []
[profile.dev]
opt-level = 0
debug = false
incremental = false
overflow-checks = true
[patch.crates-io]
generic-array = { path = "../generic-array-corrected" }
'''
    (project / 'Cargo.toml').write_text(manifest)
    (project / '.cargo').mkdir()
    (project / '.cargo/config.toml').write_text(
        '[source.crates-io]\nreplace-with = "prepared-vendor"\n'
        '[source.prepared-vendor]\ndirectory = ' + json.dumps(str(inputs / 'vendor')) + '\n')
    core = project / 'src/core_api.rs'
    before = core.read_bytes()
    suffix = (OUT / 'harness.rs.in').read_bytes()
    core.write_bytes(before + suffix)
    assert core.read_bytes()[:len(before)] == before
    body_binding = {'path': str(core), 'upstream': str(BASE / 'vendor/sha2-0.10.9/src/core_api.rs'),
                    'upstream_bytes': len(before), 'upstream_sha256': hashlib.sha256(before).hexdigest(),
                    'appended_harness_sha256': sha(OUT / 'harness.rs.in'), 'combined_sha256': sha(core)}
    pins = {str(path): sha(path) for path in inputs.rglob('*') if path.is_file()}
    write(OUT / 'input-pins.json', pins)
    write(OUT / 'source-copy-map.json', copied)
    write(OUT / 'source-body-binding.json', body_binding)
    for name in ['bin', 'tmp', 'cargo-home']:
        (OUT / name).mkdir()
    selection = {
        'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'surface': '#1097 actual SHA-256 final-state serialization',
        'phase': 'A source-preserving code-generation probe',
        'slice': 'D3a actual Sha256VarCore::finalize_variable_core, arbitrary valid state and buffer',
        'selected_method_body_changed': False, 'proof_root_manifest': str(project / 'Cargo.toml'),
        'root_manifest_boundary': 'Generated minimal root selects original sha2 Rust modules with force-soft/no-std. This is not an assertion that the complete upstream package manifest was built.',
        'source_body_binding': body_binding, 'input_pins_sha256': sha(OUT / 'input-pins.json'),
        'source_copy_map_sha256': sha(OUT / 'source-copy-map.json'),
        'harness': 'core_api::output_assembly_probe::arbitrary_final_state_serialization',
        'universal_input_scope': 'All 8-word initial states, 64 buffer bytes, 32 prior output bytes, positions 0..63, block counts below 2^55, and byte indices 0..31. These count/position bounds are exactly the representable SHA-256 bit-length range for this state shape.',
        'observed_result': 'Output equals big-endian serialization of the actual post-compression state; counter is preserved and buffer reset. Does not assume or assert the desired SHA compression value.',
        'actual_compression': True, 'stubs': [],
        'features': ['force-soft'], 'guards': ['default', 'uninit-checks', 'valid-value-checks', 'unwinding-assertions'],
        'adoption_sha256': sha(P / 'combined-digest-private-adoption-v1.json'),
        'limits': {'active_seconds': 300, 'cpu_soft_seconds': 290, 'cpu_hard_seconds': 295,
                   'address_space_bytes': 16 * 1024**3, 'file_bytes': 128 * 1024**2,
                   'workspace_bytes': 4 * 1024**3, 'aggregate_bytes': 106 * 1024**3,
                   'host_free_floor_bytes': 10 * 1024**3, 'reserve_bytes': 32 * 1024**2,
                   'startup_MemAvailable_bytes': 32 * 1024**3, 'cargo_jobs': 2, 'chains': 1},
        'authorized_command': 'One --only-codegen invocation. No solver selection; census follows only after actual compilation and guard/inventory inspection.',
        'stop': 'Keep every failure. No automatic retry, source weakening, compiler/model extension or full C3 replay.',
        'next_review_boundary': 'A successful probe informs a concrete implementation/proof batch; combined mandatory gates and Astra/Opus review precede any new published proof claim.',
        'proof_accepted': False,
    }
    write(OUT / 'selection.json', selection)
    print(json.dumps({'prepared_files': len(pins), 'unchanged_source_body_bytes': len(before),
                      'selection': str(OUT / 'selection.json'), 'solver_selected': False}), flush=True)


if __name__ == '__main__':
    main()
