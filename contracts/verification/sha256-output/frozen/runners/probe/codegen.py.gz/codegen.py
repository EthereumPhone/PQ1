"""One bounded compilation probe; execution success is never proof acceptance."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding


def authenticate(pins, links):
    for path, expected in pins.items():
        assert sha(path) == expected, ('changed input', path)
    for path, target in links.items():
        assert os.readlink(path) == target, ('changed symlink', path)


def main():
    started = time.monotonic()
    assert not (OUT / 'codegen').exists()
    selection = read(OUT / 'selection.json')
    limits = selection['limits']
    assert sha(OUT / 'input-pins.json') == selection['input_pins_sha256']
    assert sha(P / 'combined-digest-private-adoption-v1.json') == selection['adoption_sha256']
    body = selection['source_body_binding']
    assert sha(body['path']) == body['combined_sha256']
    assert Path(body['path']).read_bytes() == Path(body['upstream']).read_bytes() + (OUT / 'harness.rs.in').read_bytes()
    recovery_pins = runtime_binding.require_runtime()
    runtime = read(P / 'promoted-full-runtime-v2.json')
    consumer = read(W / 'consumer-selection-runtime-v3.json')
    setup = read(W / 'setup-corrected.json')
    pins = {**runtime['files'], **consumer['pins'], **recovery_pins, **read(OUT / 'input-pins.json')}
    for path in [OUT / 'prepare.py', Path(__file__), OUT / 'selection.json', OUT / 'input-pins.json',
                 OUT / 'source-copy-map.json', OUT / 'source-body-binding.json',
                 P / 'combined-digest-private-adoption-v1.json', W / 'execute.py']:
        pins[str(path)] = sha(path)
    # The runtime manifest calls these hard-linked source/target byte copies
    # "links". Authenticate both contents; they are not symbolic links.
    links = {}
    for row in runtime['links']:
        pins[row['source']] = row['sha256']
        pins[row['target']] = row['sha256']
    for name, target in consumer['bindings'].items():
        link = OUT / 'bin' / name
        link.symlink_to(target)
        links[str(link)] = target
        pins[target] = sha(target)
    authenticate(pins, links)
    project = OUT / 'inputs/sha2-probe'
    for ancestor in project.parents:
        for name in ['.cargo/config', '.cargo/config.toml']:
            assert not (ancestor / name).exists(), ('unselected ancestor Cargo config', ancestor / name)
    env = {key: setup['environment'][key] for key in ['HOME', 'USER', 'LANG', 'LC_ALL']}
    env.update(PATH=str(OUT / 'bin') + ':/usr/bin:/bin',
               RUSTUP_HOME=consumer['rustup_home'], RUSTUP_TOOLCHAIN=consumer['toolchain'], RUSTUP_AUTO_INSTALL='0',
               CARGO_HOME=str(OUT / 'cargo-home'), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(OUT / 'target'),
               RUSTFLAGS='--emit=mir', LD_LIBRARY_PATH=setup['environment']['LD_LIBRARY_PATH'],
               TMPDIR=str(OUT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
    resolutions = {name: str(Path(shutil.which(name, path=env['PATH'])).resolve()) for name in consumer['bindings']}
    assert all(resolutions[name] == str(Path(target).resolve()) for name, target in consumer['bindings'].items())
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:'))) * 1024
    assert available >= limits['startup_MemAvailable_bytes']
    folder = OUT / 'codegen'
    folder.mkdir()
    command = ['/usr/bin/prlimit', f"--cpu={limits['cpu_soft_seconds']}:{limits['cpu_hard_seconds']}",
               f"--as={limits['address_space_bytes']}:{limits['address_space_bytes']}",
               f"--fsize={limits['file_bytes']}:{limits['file_bytes']}", '--core=0:0', '--',
               consumer['driver'], 'kani', '--manifest-path', str(project / 'Cargo.toml'), '--lib',
               '--no-default-features', '--features', 'force-soft', '--harness', selection['harness'],
               '-Z', 'uninit-checks', '-Z', 'valid-value-checks', '--solver', 'minisat',
               '--keep-temps', '--only-codegen']
    assert command[-1] == '--only-codegen'
    spec = {'command': command, 'cwd': str(project), 'environment': env, 'output': str(folder / 'run'),
            'active_seconds': limits['active_seconds'], 'aggregate_cap': limits['aggregate_bytes'],
            'workspace': limits['workspace_bytes'], 'host_floor': limits['host_free_floor_bytes'],
            'reserve': limits['reserve_bytes'], 'storage_root': str(N), 'selection_sha256': sha(OUT / 'selection.json')}
    spec['allocation_before'] = execute.measure(N, spec)
    assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
    assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
    write(folder / 'pins.json', pins)
    write(folder / 'links.json', links)
    write(folder / 'spec.json', spec)
    write(folder / 'preflight.json', {'accepted': True, 'pins': len(pins), 'tool_resolutions': resolutions,
                                     'mem_available': available, 'seconds': time.monotonic() - started})
    print(json.dumps({'codegen_selected': True, 'command_seconds': limits['active_seconds'],
                      'solver_selected': False, 'folder': str(folder)}), flush=True)
    with (folder / 'host.log').open('x') as log:
        result = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(folder / 'spec.json')],
                                stdout=log, stderr=subprocess.STDOUT)
    execution = read(folder / 'run/execution.json')
    authenticate(pins, links)
    runtime_binding.require_runtime()
    allocation = execute.measure(N, spec)
    assert allocation < min(spec['aggregate_cap'] - spec['reserve'], spec['allocation_before'] + spec['workspace'])
    metadata = sorted((OUT / 'target').rglob('*.kani-metadata.json'))
    outputs = {str(f): sha(f) for f in metadata}
    if (project / 'Cargo.lock').exists():
        outputs[str(project / 'Cargo.lock')] = sha(project / 'Cargo.lock')
    accepted = result.returncode == 0 and execution['execution_complete'] and execution['exit'] == 0 and bool(metadata)
    assessment = {'codegen_complete': accepted, 'independent_execution': execution, 'host_exit': result.returncode,
                  'inputs_and_runtime_unchanged': True, 'post_allocation_bytes': allocation,
                  'metadata_and_lock_pins': outputs, 'whole_probe_seconds': time.monotonic() - started,
                  'proof_accepted': False, 'solver_runs': 0,
                  'scope': 'Translation feasibility only. Inspect exact harness/guard inventory before any selected census or solver.'}
    write(folder / 'assessment.json', assessment)
    print(json.dumps(assessment, indent=2), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
