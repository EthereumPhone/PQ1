"""Full-census causal control using the previously validated partition protocol."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
P, N = OUT.parent, OUT.parent.parent
W = P / 'circular-backend-cadical-v1'
LIB = N / 'cbmc-negative-group-budget-candidate/scripts/pq1_budget'
sys.path.insert(0, str(OUT))
from prepare import sha, read, write
from codegen import authenticate
sys.path.insert(0, str(W))
import execute
sys.path.insert(0, str(W / 'runtime-recovery-v1'))
import runtime_binding
sys.path.insert(0, str(LIB))
from collect_continuation import parse_partial, compose_reports, partition


def main(kind):
    assert kind in ['little-endian', 'omitted-word']
    case = OUT / 'controls-v1' / kind
    assert read(OUT / 'tail-probe-v1/assessment.json')['complete_positive_feasibility']
    census = read(case / 'census/assessment.json')
    assert census['preparation_and_census_complete'] and census['strict_inherited_parser_refusal'] is None
    properties = partition.census((case / 'census/inventory/run/command.log').read_text())
    assert properties == read(case / 'census/properties.json')
    program = case / 'census/prepared.out'
    assert sha(program) == census['program_sha256']
    positive_properties = read(OUT / 'census/properties.json')
    positive_required = read(OUT / 'root-probe-unwind65/selection.json')['required']
    required = {}
    groups = partition.groups(properties)
    def description(row):
        value = row['description']
        return value.split('] ', 1)[1] if value.startswith('[KANI_CHECK_ID_') else value
    for name in positive_required:
        original = positive_properties[name]
        if original['class'] == 'reachability_check':
            continue  # Derive the exact paired marker from its selected cover.
        matches = [key for key, row in properties.items()
                   if row['class'] == original['class']
                   and row['sourceLocation'].get('file') == original['sourceLocation'].get('file')
                   and row['sourceLocation'].get('function') == original['sourceLocation'].get('function')
                   and row['sourceLocation'].get('line') == original['sourceLocation'].get('line')
                   and description(row) == description(original)]
        assert len(matches) == 1
        selected = matches[0]
        required[selected] = 'SUCCESS'
        if original['class'] == 'cover':
            group = next(g for g in groups if selected in g)
            assert len(group) == 2
            probe = next(n for n in group if n != selected)
            assert properties[probe]['class'] == 'reachability_check'
            required[probe] = 'SUCCESS'
    assert len(required) == len(positive_required) == 11
    intended = [name for name in required if properties[name]['description'] == 'output is final-state big-endian byte']
    assert len(intended) == 1
    intended = intended[0]
    required[intended] = 'FAILURE'
    parts = partition.partition(properties, list(required))
    partition.validate_partition(properties, parts, list(required))
    assert len(parts) == 19 and len(properties) == 2324
    folder = case / 'partitioned-v1'
    folder.mkdir()
    write(folder / 'groups.json', parts[1:])
    preceding = case / 'verification/assessment.json'
    inherited = read(preceding)['debit_seconds'] if preceding.exists() else 0
    if preceding.exists():
        assert not read(preceding)['negative_control_accepted']
    selection = {'stage': 'C same full-census causal check using bounded partitioning',
                 'control': kind, 'program_sha256': sha(program),
                 'census_sha256': sha(case / 'census/properties.json'),
                 'source_control_sha256': sha(case / 'source-control.json'),
                 'parts': parts, 'required': required, 'expected_failure': intended,
                 'reason': 'The complete positive run established the partitioned route. The first all-at-once control exhausted its bound in propositional conversion; use the unchanged program/census with separately bounded root and shared-Symex tail. No compiler rerun or guard removal.',
                 'prior_control_debit_seconds': inherited,
                 'root_active_seconds': 180, 'tail_active_seconds': 900,
                 'maximum_new_solver_seconds': 1080, 'address_space_bytes': 16*1024**3,
                 'file_bytes': 16*1024**2, 'group_ack': False,
                 'stop': 'One root and, only after its intended semantic result, one remaining-group query. Keep all failures. No automatic retry or live-limit extension.'}
    write(folder / 'selection.json', selection)
    pins = {**read(case / 'census/selection.json')['pins'], **runtime_binding.require_runtime()}
    reviewed = read(W / 'full-binding-v1/positive/selection.json')['integration_pins']
    for path in LIB.glob('*.py'):
        assert sha(path) == reviewed[str(path)]
        pins[str(path)] = reviewed[str(path)]
    for path in [Path(__file__), program, folder / 'selection.json', folder / 'groups.json',
                 case / 'census/assessment.json', case / 'census/properties.json', case / 'source-control.json']:
        pins[str(path)] = sha(path)
    if preceding.exists():
        pins[str(preceding)] = sha(preceding)
    links = read(case / 'codegen/links.json')
    authenticate(pins, links)
    write(folder / 'pins.json', pins)
    base = list(census['base_command'])
    assert base[base.index('--unwind') + 1] == '193'
    base[base.index('--unwind') + 1] = '65'
    root_args = [arg for name in parts[0] for arg in ['--property', name]]
    commands = {'root': base + ['--verbosity', '8'] + root_args + [str(program)],
                'tail': base + ['--verbosity', '8', '--flush', '--pq1-scoped-partitions',
                                str(folder / 'groups.json'), '--pq1-scoped-partial', str(program)]}
    result = {'control': kind, 'negative_control_accepted': False, 'positive_proof_credit': False,
              'prior_control_debit_seconds': inherited, 'phases': {}}
    reports = {}
    for role, seconds in [('root', 180), ('tail', 900)]:
        phase = folder / role
        phase.mkdir()
        authenticate(pins, links)
        runtime_binding.require_runtime()
        available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                             if x.startswith('MemAvailable:'))) * 1024
        assert available >= 32*1024**3
        command = ['/usr/bin/prlimit', f'--cpu={seconds-10}:{seconds-5}',
                   '--as=17179869184:17179869184', '--fsize=16777216:16777216',
                   '--core=0:0', '--', *commands[role]]
        spec = {**read(case / 'codegen/spec.json'), 'command': command,
                'output': str(phase / 'run'), 'active_seconds': seconds,
                'selection_sha256': sha(folder / 'selection.json')}
        spec['allocation_before'] = execute.measure(N, spec)
        assert spec['allocation_before'] + spec['workspace'] + spec['reserve'] < spec['aggregate_cap']
        assert shutil.disk_usage(N).free > spec['host_floor'] + spec['workspace'] + spec['reserve']
        write(phase / 'spec.json', spec)
        print(json.dumps({'control': kind, 'phase': role, 'active_seconds': seconds}), flush=True)
        with (phase / 'host.log').open('x') as log:
            host = subprocess.run(['/usr/bin/python3', '-B', str(W / 'execute.py'), str(phase / 'spec.json')],
                                  stdout=log, stderr=subprocess.STDOUT)
        execution = read(phase / 'run/execution.json')
        authenticate(pins, links)
        runtime_binding.require_runtime()
        record = {'host_exit': host.returncode, 'execution': execution,
                  'inputs_and_runtime_unchanged': True, 'raw_log_sha256': sha(phase / 'run/command.log'),
                  'semantic_accepted': False,
                  'debit_seconds': execution['seconds'] if execution['execution_complete'] else seconds}
        try:
            assert host.returncode == 0 and execution['execution_complete'] and execution['exit'] in [0, 10]
            raw = (phase / 'run/command.log').read_text()
            if role == 'root':
                report = partition.parse_report(raw, properties, parts[0], execution['exit'])
                partition.semantic_check(properties, report, required, intended)
                assert all(report['rows'][n] == 'SUCCESS' for n in parts[0]
                           if properties[n]['sourceLocation'].get('propertyFatal'))
                reports['root'] = report
            else:
                reports['tail'] = parse_partial(raw, properties, parts[1:], execution['exit'])
                result['proof'] = compose_reports(properties, parts, list(range(19)), reports['root'],
                                                  reports['tail'], required, intended)
            record['semantic_accepted'] = True
        except (ValueError, AssertionError) as error:
            record['refusal'] = repr(error)
        write(phase / 'assessment.json', record)
        result['phases'][role] = record
        print(json.dumps({'control': kind, 'phase': role, 'assessment': record}, indent=2), flush=True)
        if not record['semantic_accepted']:
            break
        write(phase / 'parsed-report.json', reports[role])
    result['negative_control_accepted'] = len(result['phases']) == 2 and all(x['semantic_accepted'] for x in result['phases'].values())
    result['cumulative_control_debit_seconds'] = inherited + sum(x['debit_seconds'] for x in result['phases'].values())
    write(folder / 'assessment.json', result)
    print(json.dumps(result, indent=2), flush=True)
    assert result['negative_control_accepted'], 'control remains incomplete'


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
