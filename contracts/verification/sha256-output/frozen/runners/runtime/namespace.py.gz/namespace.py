"""Run one command with the exact original pinned host dependencies."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time

R = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def authenticate():
    start = time.monotonic()
    manifest = json.loads((R/'snapshot.json').read_text())
    assert manifest['accepted'] and len(manifest['files']) == manifest['canonical_files']
    assert sha(R/'bindings.args') == manifest['bindings_sha256']
    assert sha(R/'host-input-audit.json') == manifest['audit_sha256']
    for name, row in manifest['files'].items():
        assert time.monotonic()-start < 180, 'snapshot authentication deadline'
        assert sha(row['path']) == row['sha256'], ('snapshot changed',name)
        assert Path(name).resolve(strict=True) == Path(name), ('host path changed',name)
        for alias in row['aliases']:
            assert Path(alias).resolve(strict=True) == Path(name), ('host alias changed',alias)
    return manifest


if __name__ == '__main__':
    assert len(sys.argv) > 1 and sys.argv[1].startswith('/'), 'absolute command required'
    authenticate()
    fd = os.open(R/'bindings.args',os.O_RDONLY)
    os.set_inheritable(fd,True)
    os.execv('/usr/bin/bwrap',['/usr/bin/bwrap','--args',str(fd),'--',*sys.argv[1:]])
