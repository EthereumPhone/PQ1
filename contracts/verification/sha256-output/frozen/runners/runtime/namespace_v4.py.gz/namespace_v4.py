"""One mount namespace, exact pinned files and complete grouped directory views."""
from pathlib import Path
import json
import os
import sys
import time

R = Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import namespace


def authenticate():
    start = time.monotonic()
    original = namespace.authenticate()
    groups = json.loads((R/'directory-groups.json').read_text())
    assert groups['accepted'] and groups['original_snapshot_sha256'] == namespace.sha(R/'snapshot.json')
    assert namespace.sha(R/'bindings-v3.args') == groups['bindings_sha256']
    for path,digest in groups['pins'].items():
        assert time.monotonic()-start < 180
        assert namespace.sha(path) == digest, ('directory view changed',path)
    for path,target in groups['links'].items():
        assert os.readlink(path) == target, ('directory view link changed',path)
    return original,groups


if __name__ == '__main__':
    assert len(sys.argv)>1 and sys.argv[1].startswith('/'), 'absolute command required'
    authenticate()
    fd = os.open(R/'bindings-v3.args',os.O_RDONLY)
    os.set_inheritable(fd,True)
    os.execv('/usr/bin/bwrap',['/usr/bin/bwrap','--args',str(fd),'--dev','/dev','--',*sys.argv[1:]])
