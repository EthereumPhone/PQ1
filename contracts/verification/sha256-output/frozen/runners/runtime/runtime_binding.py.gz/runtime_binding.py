"""Authenticate the recovery and mounted runtime at original-query boundaries."""
from pathlib import Path
import json
import sys
import time

R = Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import namespace
import namespace_v4


def require_runtime():
    started = time.monotonic()
    receipt = json.loads((R/'validation-v3/assessment.json').read_text())
    assert receipt['accepted'] and receipt['pinned_host_files'] == 13015
    assert receipt['prepared_input_pins'] == 77504 and receipt['prior_accepted_consumers'] == 5
    assert len(receipt['ownership_controls']) == 4 and receipt['original_solver_queries'] == 0
    for path,digest in receipt['pins'].items():
        assert namespace.sha(path) == digest, ('runtime validation changed',path)
    manifest, groups = namespace_v4.authenticate()
    mounts = {line.split()[4]:line.split()[5].split(',')
              for line in Path('/proc/self/mountinfo').read_text().splitlines()}
    for path,row in manifest['files'].items():
        assert time.monotonic()-started < 180, 'runtime binding deadline'
        mount = next((g for g in groups['groups'] if path.startswith(g+'/')),path)
        assert 'ro' in mounts.get(mount,[]), ('missing read-only runtime mount',path)
        assert namespace.sha(path) == row['sha256'], ('runtime bytes changed',path)
    for path in (R/'snapshot',R/'directory-views'):
        assert 'ro' in mounts.get(str(path),[]), ('writable runtime backing files',path)
    paths = [Path(__file__),R/'namespace.py',R/'namespace_v4.py',R/'snapshot.json',
             R/'directory-groups.json',R/'bindings-v3.args',R/'validation-v3/assessment.json']
    return {str(p):namespace.sha(p) for p in paths}
