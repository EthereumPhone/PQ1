"""Finite metadata controls; the positive census is a fixture, not negative evidence."""
import copy
from pathlib import Path
import unittest

import negative_profile as negative
import pq1_partition as p


class NegativeProfileControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = Path(__file__).resolve().parents[3] / (
            'corrected-digest/promoted-full-digest-v1/positive/partitions.json')
        assert p.sha(path) == 'fc6ec8b733886588ad6a3993714b65782ad07bfeb90603128847f2feca92fda1'
        cls.fixture = p.read(path)

    def test_tail_first_and_only_reachable_expected_root(self):
        value = negative.census_contract(self.fixture['properties'], self.fixture)
        self.assertEqual(value['parts'], self.fixture['parts'])
        self.assertEqual(value['composition_order'], self.fixture['execution_order'])
        self.assertEqual(value['solver_order'], self.fixture['execution_order'][1:] + [0])
        self.assertEqual(value['required'], {
            'diagnostic::actual_empty_digest.assertion.3': 'FAILURE',
            'diagnostic::actual_empty_digest.reachability_check.3': 'FAILURE'})
        self.assertFalse(value['full_census_audit_complete'])
        self.assertFalse(value['proof_credit'])

    def test_incomplete_or_changed_obligations_are_refused(self):
        for mode in ['missing_guard', 'changed_fatal', 'changed_class', 'wrong_root_line',
                     'wrong_root_file', 'wrong_root_description', 'wrong_probe',
                     'split_pair', 'incomplete_parts', 'changed_order', 'positive_failure']:
            properties = copy.deepcopy(self.fixture['properties'])
            positive = copy.deepcopy(self.fixture)
            root = properties[negative.EXPECTED_FAILURE]
            if mode == 'missing_guard':
                del properties[next(n for n, v in properties.items()
                                    if v['class'] == 'unsupported_construct')]
            elif mode == 'changed_fatal':
                next(v for v in properties.values() if v['sourceLocation'].get(
                    'propertyFatal'))['sourceLocation']['propertyFatal'] = False
            elif mode == 'changed_class':
                root['class'] = 'cover'
            elif mode == 'wrong_root_line':
                root['sourceLocation']['line'] = '15'
            elif mode == 'wrong_root_file':
                root['sourceLocation']['file'] = 'other.rs'
            elif mode == 'wrong_root_description':
                root['description'] += ' altered'
            elif mode == 'wrong_probe':
                properties[negative.ROOTS[0][1]]['expression'] = 'TRUE'
            elif mode == 'split_pair':
                positive['parts'][0].remove(negative.ROOTS[0][1])
                positive['parts'][1].append(negative.ROOTS[0][1])
            elif mode == 'incomplete_parts':
                positive['parts'].pop()
            elif mode == 'changed_order':
                positive['execution_order'] = negative.ORDER[1:] + [0]
            else:
                positive['expected_failure'] = negative.EXPECTED_FAILURE
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                negative.census_contract(properties, positive)


if __name__ == '__main__':
    unittest.main(verbosity=2)
