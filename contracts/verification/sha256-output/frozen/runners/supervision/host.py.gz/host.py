"""Pinned host launcher records startup and the observer's actual Popen exit.

The external execution tool still must observe this launcher's actual exit0.
Host/observer failure never grants proof credit or permission to reuse a slot.
"""
import math
from pathlib import Path
import resource
import subprocess
import time

import authority
import budget
import common
import context
from budget import NANO, require
from observer import failure_record
from process_ownership import identity


def validate_completion(folder, start_ns, observed_exit, finished_ns, deadline_ns):
    require(observed_exit == 0 and type(observed_exit) is int, 'observer did not actually exit0')
    terminal_path, completion_path = folder / 'observer-terminal.json', folder / 'observer-completion.json'
    terminal = common.read(terminal_path, deadline_ns)
    completion = common.read(completion_path, deadline_ns)
    require(completion['complete'] is True
            and completion['terminal_sha256'] == common.sha(terminal_path, deadline_ns)
            and terminal['context'] == completion['context']
            and terminal['stop'] is None and terminal['zero_descendants'] is True,
            'observer completion absent/changed/failed')
    runtime = context.load(terminal['context'], deadline_ns)
    accounting = terminal['accounting']
    require(runtime['start_ns'] == start_ns and accounting['proof_credit'] is True
            and accounting['terminal_accounting_complete'] is True
            and accounting['complete_observation'] is True
            and accounting['uncertain_final_elapsed'] is False
            and start_ns <= terminal['observed_ns'] <= completion['finished_ns'] <= finished_ns,
            'inconsistent observer final accounting')
    require(finished_ns < runtime['deadlines']['final']
            and (finished_ns - start_ns) / NANO <= accounting['debit_seconds']
            <= runtime['reservation_seconds'], 'host completion exceeded actual attempt debit')
    return terminal, {'path': str(terminal_path), 'sha256': common.sha(terminal_path, deadline_ns)}


def main(args, entry_ns):
    require(len(args) == 4, 'host requires exact launch and execution-selection bindings')
    launch_ref, selection_ref = ({'path': args[i], 'sha256': args[i + 1]} for i in [0, 2])
    resource.setrlimit(resource.RLIMIT_AS, (16 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_FSIZE, (common.FILE_BYTES,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (4380,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    start_path = common.CAMPAIGN / 'host-start.json'
    # No bulk case authentication precedes the observer's exclusive reservation.
    # This small startup record is dynamic observation, not static selection.
    me = identity(__import__('os').getpid())
    start = {'start_ns': entry_ns, 'boot_id': context.boot_id(),
             'host': {k: me[k] for k in ['pid', 'start_ticks']},
             'launch_spec': launch_ref, 'selection': selection_ref}
    deadline = budget.deadlines(entry_ns)['final']
    common.write(start_path, start, deadline)
    host_ref = {'path': str(start_path), 'sha256': common.sha(start_path, deadline)}
    command = common.helper_command('observer', *args, host_ref['path'], host_ref['sha256'])
    process = subprocess.Popen(command, cwd=common.SOURCE, env=common.HELPER_ENV)
    observed = identity(process.pid)
    code, stop, terminal, terminal_ref = None, None, None, None
    try:
        # The4380s host observation ceiling exceeds the complete4320s attempt,
        # including its independent cleanup/finalization margin. It cannot
        # authorize solver work after the context's earlier deadlines.
        code = process.wait(timeout=max(.001, 4380 - (time.monotonic_ns() - entry_ns) / NANO))
        finished = time.monotonic_ns()
        terminal, terminal_ref = validate_completion(authority.SLOT, entry_ns, code, finished, deadline)
        require(terminal['observer'] == {k: observed[k] for k in ['pid', 'start_ticks']}
                and terminal['host_start'] == host_ref, 'observer identity/startup mismatch')
    except BaseException as error:
        stop = repr(error)
    finished = time.monotonic_ns()
    complete = code is not None
    debit = max(0 if terminal is None else terminal['accounting']['debit_seconds'],
                math.ceil((finished - entry_ns) / NANO) + 2)
    if stop is not None:
        debit = max(budget.reservation(), debit)
    receipt = {'host_start': host_ref, 'observer': {k: observed[k] for k in ['pid', 'start_ticks']},
               'command': command, 'observer_exit': code, 'finished_ns': finished, 'stop': stop,
               'observer_terminal': terminal_ref, 'complete_observation': complete,
               'uncertain_final_elapsed': not complete, 'conservative_debit_seconds': debit,
               'total_case_seconds': budget.INHERITED + debit,
               'cumulative_ceiling_exceeded': budget.INHERITED + debit > budget.TOTAL,
               'requires_external_host_exit_zero': True, 'proof_credit': False}
    path = common.CAMPAIGN / 'host-completion.json'
    if stop is None:
        common.write(path, receipt, deadline)
        require(time.monotonic_ns() < deadline
                and (time.monotonic_ns() - entry_ns) / NANO <= debit
                and debit <= budget.reservation(), 'host finalization exceeded allowance')
        return 0
    failure_record(path, receipt)
    return 1
