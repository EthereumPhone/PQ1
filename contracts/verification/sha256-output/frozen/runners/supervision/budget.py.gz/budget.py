"""Pure time/allocation and accounting predicates for one selected attempt."""
import math

NANO = 1_000_000_000
INHERITED = 4320
TOTAL = 8621
ATTEMPT = 4301
GROUPS = 22
FIRST_GROUP_SECONDS = 180
GROUP_SECONDS = 600
TAIL_MAX = 3960
OFFSETS = {'solver': 192, 'work': 12, 'term': 10, 'kill': 5, 'final': 0}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value):
    return type(value) is int and value >= 0


def reservation(inherited=INHERITED, total=TOTAL, attempt=ATTEMPT):
    require(type(inherited) in (int, float) and math.isfinite(inherited)
            and 0 <= inherited < total, 'invalid inherited debit')
    require(type(total) is int and total > 0 and type(attempt) is int
            and 0 < attempt <= total, 'invalid selected time ceiling')
    return min(attempt, total - inherited)


def deadlines(start_ns, inherited=INHERITED, total=TOTAL, attempt=ATTEMPT):
    require(integer(start_ns), 'invalid monotonic origin')
    end = start_ns + math.floor(reservation(inherited, total, attempt) * NANO)
    return {name: end - offset * NANO for name, offset in OFFSETS.items()}


def group_limit(index):
    require(type(index) is int and 0 <= index < GROUPS, 'invalid group index')
    return FIRST_GROUP_SECONDS if index == 0 else GROUP_SECONDS


def group_deadline(start_ns, index, tail_stop_ns):
    require(integer(start_ns) and integer(tail_stop_ns), 'invalid group clock')
    return min(tail_stop_ns, start_ns + group_limit(index) * NANO)


def tail_cap(deadline_ns, now_ns):
    require(integer(deadline_ns) and integer(now_ns), 'invalid tail clock')
    return min(TAIL_MAX, max(0, (deadline_ns - now_ns) // NANO))


def root_cap(deadline_ns, now_ns):
    require(integer(deadline_ns) and integer(now_ns), 'invalid root clock')
    return min(600, max(0, (deadline_ns - now_ns) // NANO))


def effective_tail_deadline(deadline_ns, runner_start_ns, seconds):
    require(integer(deadline_ns) and integer(runner_start_ns)
            and type(seconds) is int and 0 < seconds <= TAIL_MAX,
            'invalid tail allocation')
    end = min(deadline_ns, runner_start_ns + seconds * NANO)
    require(end > runner_start_ns, 'tail budget exhausted')
    return end


def screen(first_elapsed, symex_seconds, deadline_ns, now_ns):
    require(all(type(x) in (int, float) and math.isfinite(x) and x >= 0
                for x in (first_elapsed, symex_seconds)), 'invalid screen timing')
    require(symex_seconds <= first_elapsed < FIRST_GROUP_SECONDS,
            'inconsistent first-group timing')
    require(integer(deadline_ns) and integer(now_ns), 'invalid screen clock')
    rounded = math.ceil(first_elapsed - symex_seconds)
    required = 21 * (2 * rounded + 20)
    remaining = max(0, (deadline_ns - now_ns) // NANO)
    return {'first_group_elapsed': first_elapsed, 'symex_seconds': symex_seconds,
            'remainder_seconds': first_elapsed - symex_seconds,
            'rounded_remainder_seconds': rounded, 'required_later_seconds': required,
            'remaining_seconds': remaining, 'remaining_groups': 21,
            'effective_tail_deadline_ns': deadline_ns, 'observed_ns': now_ns,
            'passes': required <= remaining}


def account(elapsed_ns, declared, reserved, inherited=INHERITED, total=TOTAL,
            complete=False, finalized=False, accepted=False):
    require(integer(elapsed_ns) and type(declared) in (int, float)
            and math.isfinite(declared) and declared >= 0,
            'invalid elapsed/declaration')
    require(type(reserved) in (int, float) and math.isfinite(reserved)
            and reserved > 0, 'invalid reservation')
    require(all(type(x) is bool for x in (complete, finalized, accepted)),
            'invalid completion flags')
    reservation(inherited, total)  # Validate ledger inputs, not a new allowance.
    conservative = (elapsed_ns + NANO - 1) // NANO + 2
    debit = max(declared, conservative)
    within = debit <= reserved
    require(not accepted or (complete and finalized and within),
            'cannot accept incomplete/late attempt')
    if not complete or not finalized or not within:
        debit = max(reserved, debit)
    return {'debit_seconds': debit, 'total_case_seconds': inherited + debit,
            'observed_elapsed_ns': elapsed_ns, 'reserved_seconds': reserved,
            'complete_observation': complete, 'uncertain_final_elapsed': not complete,
            'terminal_accounting_complete': finalized,
            'debit_is_lower_bound': not complete,
            'attempt_limit_exceeded': elapsed_ns > reserved * NANO,
            'cumulative_ceiling_exceeded': inherited + debit > total,
            'proof_credit': accepted and complete and finalized and within}
