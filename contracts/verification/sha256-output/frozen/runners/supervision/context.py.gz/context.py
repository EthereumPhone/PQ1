"""Immutable, boot-bound runtime context shared by all supervision layers."""
import os
from pathlib import Path
import time

import budget
from budget import NANO, require
from common import bound_json
from process_ownership import identity, snapshot, descends_from

KIND = 'original-negative-oracle-byte-v2'
CONTEXT_KEYS = {'kind', 'boot_id', 'start_ns', 'inherited_seconds',
                'cumulative_total', 'attempt_limit', 'reservation_seconds',
                'deadlines', 'slot', 'case_sha256', 'selection_sha256',
                'launch_spec_sha256', 'observer'}
OBSERVER_KEYS = {'pid', 'start_ticks'}


def boot_id():
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def validate(value, *, live=False, synthetic=False, now_ns=None):
    """Pure receipt checks by default; live admission also checks the owner tree."""
    keys = CONTEXT_KEYS | ({'synthetic_test_only', 'test_offsets'} if synthetic else set())
    require(set(value) == keys and value['kind'] == KIND, 'wrong runtime context schema')
    require(value['inherited_seconds'] == budget.INHERITED
            and value['cumulative_total'] == budget.TOTAL
            and value['attempt_limit'] == budget.ATTEMPT
            and value['reservation_seconds'] == budget.reservation(),
            'changed runtime accounting policy')
    require(budget.integer(value['start_ns']) and value['start_ns'] > 0,
            'invalid runtime origin')
    expected = budget.deadlines(value['start_ns'])
    if synthetic:
        require(value['synthetic_test_only'] is True, 'unmarked synthetic context')
        offsets = value['test_offsets']
        require(set(offsets) == set(expected)
                and all(budget.integer(n) and n > 0 for n in offsets.values()),
                'invalid synthetic deadline offsets')
        expected = {name: value['start_ns'] + n for name, n in offsets.items()}
    require(value['deadlines'] == expected, 'changed absolute deadlines')
    ds = value['deadlines']
    require(value['start_ns'] < ds['solver'] < ds['work'] < ds['term']
            < ds['kill'] < ds['final'], 'unordered context deadlines')
    require(isinstance(value['slot'], str) and Path(value['slot']).is_absolute(),
            'invalid one-use slot')
    for key in ['case_sha256', 'selection_sha256', 'launch_spec_sha256']:
        digest = value[key]
        require(isinstance(digest, str) and len(digest) == 64
                and all(c in '0123456789abcdef' for c in digest), 'invalid context binding')
    owner = value['observer']
    require(set(owner) == OBSERVER_KEYS and all(budget.integer(n) and n > 0
                                              for n in owner.values()), 'invalid observer identity')
    require(isinstance(value['boot_id'], str) and len(value['boot_id']) == 36,
            'missing boot identity')
    if live:
        now_ns = time.monotonic_ns() if now_ns is None else now_ns
        require(value['boot_id'] == boot_id(), 'runtime context belongs to another boot')
        require(value['start_ns'] <= now_ns < ds['final'], 'expired/future runtime context')
        observed = identity(owner['pid'])
        require(observed['start_ticks'] == owner['start_ticks']
                and observed['state'] not in {'Z', 'X'}
                and descends_from(os.getpid(), owner['pid'], snapshot()),
                'changed observer identity or outside owner subtree')
    return value


def load(binding, deadline_ns, *, live=False, synthetic=False):
    require(set(binding) == {'path', 'sha256'}, 'invalid runtime-context reference')
    value = bound_json(binding['path'], binding['sha256'], deadline_ns)
    require(Path(binding['path']) == Path(value['slot']) / 'runtime-context.json',
            'context outside reserved slot')
    return validate(value, live=live, synthetic=synthetic)


def runner_bounds(context, start_ns, seconds, tail, root=False):
    """One origin; census and fresh root caps include their full post-validation."""
    require(budget.integer(start_ns) and context['start_ns'] <= start_ns,
            'runner predates observer')
    require(type(tail) is bool and type(root) is bool and not (tail and root), 'ambiguous runner role')
    if tail:
        solver = budget.effective_tail_deadline(context['deadlines']['solver'],
                                               start_ns, seconds)
        post = context['deadlines']['work']
    else:
        require(type(seconds) is int and ((root and 0 < seconds <= 600)
                or (not root and seconds == 180)), 'changed census/root bound')
        solver = min(context['deadlines']['solver'], start_ns + seconds * NANO)
        post = min(context['deadlines']['work'], start_ns + seconds * NANO)
    require(start_ns + 2 * NANO < solver, 'no local cleanup lead remains')
    return {'effective_solver_deadline_ns': solver, 'post_deadline_ns': post,
            'poll_deadline_ns': solver - 2 * NANO}
