"""Identity-bound descendant cleanup, with one wait owner per Popen child.

This module grants no execution authority. Callers must bound every operation,
enable subreaping before launch, and reject incomplete cleanup as proof evidence.
"""
import ctypes
import os
from pathlib import Path
import signal
import time


def identity(pid):
    """Read PID identity, parent and state without trusting comm contents."""
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': int(pid), 'start_ticks': int(fields[19]),
            'parent': int(fields[1]), 'state': fields[0]}


def enable_subreaper():
    if not hasattr(os, 'pidfd_open') or not hasattr(signal, 'pidfd_send_signal'):
        raise RuntimeError('pidfd APIs required; no numeric signalling fallback')
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'cannot enable child subreaper')
    enabled = ctypes.c_int()
    if libc.prctl(37, ctypes.byref(enabled), 0, 0, 0) != 0 or enabled.value != 1:
        raise RuntimeError('child subreaper readback failed')


def snapshot():
    result = {}
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                record = identity(int(path.name))
                result[record['pid']] = record
            except (FileNotFoundError, ProcessLookupError):
                pass
    return result


def descends_from(pid, owner, records):
    seen = set()
    while pid != owner:
        if pid in seen or pid not in records or pid <= 1:
            return False
        seen.add(pid)
        pid = records[pid]['parent']
    return True


class OwnedTree:
    """One process's descendant scope; registered children retain Popen status."""

    def __init__(self, subreaper=True):
        if subreaper:
            enable_subreaper()
        self.owner = identity(os.getpid())
        self.handles = {}  # (PID,start_ticks) -> held pidfd
        self.registered = {}  # PID -> Popen, whose poll/wait owns its status
        self.events = []

    def _acquire(self, observed):
        """Validate after pidfd_open, so numeric PID reuse cannot redirect signals."""
        pid = observed['pid']
        if pid == self.owner['pid']:
            raise RuntimeError('refuse to acquire owner as its own descendant')
        fd = os.pidfd_open(pid, 0)
        try:
            current = identity(pid)
            records = snapshot()
            root = records.get(self.owner['pid'])
            again = identity(pid)
            if (root is None or root['start_ticks'] != self.owner['start_ticks']
                    or current['start_ticks'] != observed['start_ticks']
                    or again['start_ticks'] != observed['start_ticks']
                    or not descends_from(pid, self.owner['pid'], records)
                    or again['parent'] != records.get(pid, {}).get('parent')):
                raise RuntimeError('PID identity or owned ancestry changed after open')
            key = (pid, current['start_ticks'])
            if key in self.handles:
                os.close(fd)
            else:
                self.handles[key] = fd
            return key
        except BaseException:
            os.close(fd)
            raise

    def register(self, process):
        """Call immediately after Popen, before polling/reaping its direct child."""
        if process.pid in self.registered:
            raise RuntimeError('Popen child already has a wait owner')
        observed = identity(process.pid)
        if observed['parent'] != self.owner['pid']:
            raise RuntimeError('registered Popen is not a direct child')
        self._acquire(observed)
        self.registered[process.pid] = process
        self.events.append({'event': 'registered', **observed})

    def poll_registered(self):
        for process in self.registered.values():
            process.poll()  # The same Popen object retains its exact exit status.

    def discover(self):
        records = snapshot()
        found = []
        for pid, observed in records.items():
            if pid == self.owner['pid'] or not descends_from(pid, self.owner['pid'], records):
                continue
            key = (pid, observed['start_ticks'])
            try:
                if key not in self.handles:
                    self._acquire(observed)
                found.append(observed)
            except (FileNotFoundError, ProcessLookupError):
                pass
        return found

    def reap_adopted(self):
        self.poll_registered()
        for observed in self.discover():
            pid = observed['pid']
            if observed['parent'] != self.owner['pid'] or pid in self.registered:
                continue
            try:
                waited, status = os.waitpid(pid, os.WNOHANG)
                if waited:
                    self.events.append({'event': 'adopted_reaped', **observed,
                                        'exit': os.waitstatus_to_exitcode(status)})
            except ChildProcessError:
                pass
        records = snapshot()
        for key, fd in list(self.handles.items()):
            pid, ticks = key
            if pid not in records or records[pid]['start_ticks'] != ticks:
                os.close(fd)
                del self.handles[key]

    def send(self, sig):
        """Signal current owned descendants through authenticated held pidfds only."""
        for observed in self.discover():
            if observed['state'] in {'Z', 'X'}:
                continue
            key = (observed['pid'], observed['start_ticks'])
            # An existing pidfd cannot retarget a reused PID. Recheck ancestry
            # before each signal as well, since discovery and dispatch differ.
            try:
                now = identity(observed['pid'])
                records = snapshot()
                if (now['start_ticks'] != observed['start_ticks']
                        or not descends_from(observed['pid'], self.owner['pid'], records)):
                    raise RuntimeError('refuse signal after ownership change')
                signal.pidfd_send_signal(self.handles[key], sig, None, 0)
                self.events.append({'event': 'signal', 'signal': sig, **observed})
            except (FileNotFoundError, ProcessLookupError):
                pass

    def send_child(self, process, sig):
        """Timer's direct-child stop; outer controller owns orphan cleanup.

        Popen poll/wait remains the only consumer of this child's exit status.
        The held descriptor is acquired and ancestry-checked after Popen.
        """
        if self.registered.get(process.pid) is not process:
            raise RuntimeError('unregistered direct child')
        if process.poll() is not None:
            return
        try:
            observed = identity(process.pid)
            key = (process.pid, observed['start_ticks'])
            if (observed['parent'] != self.owner['pid'] or key not in self.handles
                    or not descends_from(process.pid, self.owner['pid'], snapshot())):
                raise RuntimeError('changed direct-child ownership')
            signal.pidfd_send_signal(self.handles[key], sig, None, 0)
            self.events.append({'event': 'direct_signal', 'signal': sig, **observed})
        except (FileNotFoundError, ProcessLookupError):
            pass

    def empty(self):
        self.reap_adopted()
        if self.discover():
            return False
        try:
            # WNOWAIT observes whether any child remains; it consumes no status.
            os.waitid(os.P_ALL, 0, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            return False
        except ChildProcessError:
            return True

    def cleanup(self, deadline, grace=1.0):
        """Bounded TERM/KILL/reap. A false result must never reach validation."""
        if self.empty():
            return True
        self.send(signal.SIGTERM)
        kill_at = min(time.monotonic() + grace, deadline - 0.1)
        killed = False
        while not self.empty():
            now = time.monotonic()
            if now >= kill_at:
                self.send(signal.SIGKILL)
                killed = True
            if now >= deadline:
                return False
            time.sleep(min(0.01, max(0, deadline - now)))
        self.events.append({'event': 'cleanup_complete', 'used_kill': killed})
        return True

    def close(self):
        for fd in self.handles.values():
            os.close(fd)
        self.handles.clear()
