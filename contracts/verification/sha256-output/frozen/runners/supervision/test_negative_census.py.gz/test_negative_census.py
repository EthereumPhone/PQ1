"""Source-backed census controls; mutations are in-memory fixtures only."""
import copy
from pathlib import Path
import time
import unittest

import negative_census as audit
import pq1_partition as p
import pq1_promoted_census as parser


class NegativeCensusControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parents[3]
        cls.old = cls.root / 'corrected-digest/promoted-full-digest-v1/positive'
        cls.new = cls.root / 'corrected-digest/full-negative-implementation-v1/prepared-negative-v2'
        assert p.sha(cls.old / 'partitions.json') == (
            'fc6ec8b733886588ad6a3993714b65782ad07bfeb90603128847f2feca92fda1')
        assert p.sha(cls.new / 'census/stdout.txt') == (
            'a2bffbd0bac3591087b6e4745e3e0d2cf762d98361afbbcb091421cf2a7c814f')
        cls.positive = p.read(cls.old / 'partitions.json')
        cls.fresh = parser.census((cls.new / 'census/stdout.txt').read_text())
        cls.old_types = p.read(next((cls.old / 'target').rglob('*.type_map.json')))
        cls.new_types = p.read(next((cls.new / 'target').rglob('*.type_map.json')))
        cls.deadline = time.monotonic_ns() + 60 * 10**9

    def compare(self, properties, types):
        return audit.compare(self.positive, properties, self.old_types, types,
                             self.old / 'inputs', self.new / 'inputs',
                             self.root / 'kani-promoted-entry-candidate', self.deadline)

    def test_complete_literal_comparison(self):
        result = self.compare(self.fresh, self.new_types)
        self.assertEqual(result['static_count'], 2840)
        self.assertEqual(len(result['marker_bijection']), 315)
        self.assertEqual(len(result['type_bijection']), 8)
        self.assertTrue(all(v['old'] != v['fresh'] for v in result['type_bijection']))
        self.assertEqual(result['added'], [])
        self.assertEqual(result['removed'], [])
        self.assertTrue(result['full_census_audit_complete'])
        self.assertFalse(result['proof_credit'])

    def test_unselected_literal_changes_refused(self):
        guard = next(n for n, row in self.fresh.items() if row['class'] == 'unsupported_construct')
        marker = 'diagnostic::actual_empty_digest.assertion.3'
        expression = next(n for n, row in self.fresh.items()
                          if audit.TAG.search(row['expression']) and 'R_OK(' in row['expression'])
        renamed = next(n for n, row in self.fresh.items()
                       if audit.TAG.findall(row['expression']) != audit.TAG.findall(
                           self.positive['properties'][n]['expression']))
        for mode in ['guard_predicate', 'guard_class', 'guard_fatal', 'marker_comment',
                     'pragma_order', 'pragma_member', 'predicate', 'debug_number',
                     'source_line', 'source_column', 'source_file', 'working_directory',
                     'extra_field', 'underlying_type', 'nonbijective_marker']:
            fresh, types = copy.deepcopy(self.fresh), dict(self.new_types)
            if mode == 'guard_predicate':
                fresh[guard]['expression'] = 'TRUE'
            elif mode == 'guard_class':
                fresh[guard]['class'] = 'assertion'
            elif mode == 'guard_fatal':
                fresh[guard]['sourceLocation']['propertyFatal'] = True
            elif mode == 'marker_comment':
                fresh[marker]['sourceLocation']['comment'] += ' altered'
            elif mode in {'pragma_order', 'pragma_member'}:
                values = fresh[marker]['sourceLocation']['pragma']
                if mode == 'pragma_order':
                    values.reverse()
                else:
                    values.append('checked:invented')
            elif mode == 'predicate':
                fresh[expression]['expression'] = fresh[expression]['expression'].replace('R_OK(', 'W_OK(')
            elif mode == 'debug_number':
                fresh[audit.SANITY]['description'] = fresh[audit.SANITY]['description'].replace(
                    'DefId { id: 1319,', 'DefId { id: 1320,')
            elif mode == 'source_line':
                fresh[expression]['sourceLocation']['line'] = '1'
            elif mode == 'source_column':
                fresh[expression]['sourceLocation']['column'] = '999'
            elif mode == 'source_file':
                fresh[expression]['sourceLocation']['file'] = '/tmp/unselected.rs'
            elif mode == 'working_directory':
                next(row for row in fresh.values() if 'workingDirectory' in row['sourceLocation'])[
                    'sourceLocation']['workingDirectory'] = '/tmp'
            elif mode == 'extra_field':
                fresh[expression]['unchecked'] = True
            elif mode == 'underlying_type':
                tag = audit.TAG.search(fresh[renamed]['expression'])[2]
                types['tag-' + tag] = 'different Rust type'
            else:
                other = fresh['diagnostic::actual_empty_digest.reachability_check.6']['description']
                original = p.MARKER.search(fresh[marker]['description'])[0]
                for name in [marker, 'diagnostic::actual_empty_digest.reachability_check.3']:
                    fresh[name]['description'] = fresh[name]['description'].replace(original, other)
            with self.subTest(mode=mode), self.assertRaises((ValueError, KeyError)):
                self.compare(fresh, types)


if __name__ == '__main__':
    unittest.main(verbosity=2)
