"""Synthetic validator controls, including deliberate deadline-crossing inputs.

No original program, solver or execution slot is used. Fabricated timestamps
are clearly marked; passing them is validator evidence, never measured timing.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import budget
import collector
import common
import context
from group_gate import GroupGate
from process_ownership import identity, OwnedTree
import timer

N = budget.NANO
ROOT = Path(sys.argv[1])
DEADLINE = time.monotonic_ns() + 8 * N
controls = []


def refuses(fn):
    try:
        fn()
    except (ValueError, RuntimeError):
        return
    raise AssertionError('negative control accepted')


def dump(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')
    return str(path)


def pin(path):
    return common.sha(path, DEADLINE)


def changed(obj, **fields):
    result = copy.deepcopy(obj)
    result.update(fields)
    return result


runtime = {'kind': context.KIND, 'boot_id': context.boot_id(), 'start_ns': 1000 * N,
           'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
           'attempt_limit': budget.ATTEMPT, 'reservation_seconds': budget.reservation(),
           'deadlines': budget.deadlines(1000 * N), 'slot': str(ROOT / 'slot'),
           'case_sha256': 'a' * 64, 'selection_sha256': 'b' * 64,
           'launch_spec_sha256': 'c' * 64,
           'observer': {k: v for k, v in identity(os.getpid()).items()
                        if k in {'pid', 'start_ticks'}}}
assert context.validate(runtime) == runtime
for updates in [{'inherited_seconds': 1702.8956619648961}, {'inherited_seconds': 0},
                {'inherited_seconds': 1853.8956619648961}, {'cumulative_total': 7200},
                {'kind': 'original-positive-budget-continuation-v1'},
                {'cumulative_total': 10800}, {'reservation_seconds': 4321},
                {'boot_id': ''}, {'observer': {}},
                {'deadlines': dict(runtime['deadlines'], solver=5110 * N)},
                {'synthetic_test_only': True}]:
    refuses(lambda updates=updates: context.validate(changed(runtime, **updates)))
controls.append('stale/reset accounting, reservation, boot/owner and deadline policy refuse')

# Exercise the actual timer admission, including clamped and unclamped cases.
def timing_spec(start, seconds):
    return {'schema': 'bounded-phased-v1', 'side': 'candidate', 'group_count': 22,
            'group_seconds': budget.GROUP_SECONDS, 'first_group_seconds': budget.FIRST_GROUP_SECONDS,
            'commands': [['synthetic-no-execution']],
            'whole_seconds': seconds, 'runner_start_ns': start * N,
            'outer_monotonic_start': start,
            'bounds': context.runner_bounds(runtime, start * N, seconds, True)}


for start, cap, effective in [(1010, 3960, 4970), (1013, 3960, 4973),
                               (2000, 3109, 5109), (2003, 3106, 5109),
                               (3835, 1274, 5109)]:
    spec = timing_spec(start, cap)
    assert timer.admit(spec, runtime, start * N)['effective_solver_deadline_ns'] == effective * N
refuses(lambda: timer.admit(changed(timing_spec(1010, 3960), whole_seconds=4128),
                            runtime, 1010 * N))
controls.append('real timer admits clamped3960 and after old balance; rejects4128')
for fields in [{'first_group_seconds': 600}, {'group_seconds': 180}, {'group_seconds': 601}]:
    refuses(lambda fields=fields: timer.admit(changed(timing_spec(1010, 3960), **fields),
                                              runtime, 1010 * N))
assert budget.group_deadline(1000 * N, 0, 5000 * N) == 1180 * N
assert budget.group_deadline(1000 * N, 1, 5000 * N) == 1600 * N
assert budget.group_deadline(1000 * N, 21, 1400 * N) == 1400 * N
for index in [-1, 22, True]:
    refuses(lambda index=index: budget.group_limit(index))
for fields in [{'kind': 'original-negative-oracle-byte-v1'}, {'inherited_seconds': 19},
               {'cumulative_total': 4320}, {'attempt_limit': 4320}]:
    refuses(lambda fields=fields: context.validate(changed(runtime, **fields)))
controls.append('first180/later600 clipped to global stop; old timing/context/debit rejected')


# A bytecode injection must be rejected before importing any helper module.
copied = ROOT / 'injected-sources'
copied.mkdir()
for path in common.SOURCE.iterdir():
    shutil.copyfile(path, copied / path.name)
(copied / 'common.pyc').write_bytes(b'not a source dependency')
injection = subprocess.run(['/usr/bin/python3', '-E', '-S', '-B', str(copied / 'entry.py'),
                            'timer'], env=common.HELPER_ENV, capture_output=True, timeout=2)
assert injection.returncode != 0 and b'non-source helper closure member: common.pyc' in injection.stderr
controls.append('stale local bytecode rejected before helper imports')

# Deadline-aware authentication and actual du (no success mocks).
input_path = ROOT / 'input'
input_path.write_bytes(b'bound input')
expected = {str(input_path): pin(input_path)}
common.authenticate(expected, DEADLINE)
input_path.write_bytes(b'changed input')
refuses(lambda: common.authenticate(expected, DEADLINE))
refuses(lambda: common.authenticate(expected, time.monotonic_ns() - 1))
owner = OwnedTree()
assert common.allocated(ROOT, DEADLINE, owner) > 0 and owner.empty()
owner.close()
controls.append('real hashes reject changed/expired input; actual bounded du reaped')

# Full synthetic 2840-property,23-partition transcript,22 freshly acknowledged
# groups. This is generated data, not a transcript from the original program.
properties = {}
for i in range(2840):
    name, description = f'synthetic.assertion.{i}', f'synthetic assertion {i}'
    klass = 'unsupported_construct' if i in range(0, 19 * 140, 140) else 'assertion'
    properties[name] = {'name': name, 'class': klass, 'description': description,
                        'expression': 'TRUE', 'sourceLocation': {
                            'propertyId': name, 'propertyClass': klass,
                            'comment': description, 'file': 'synthetic.rs',
                            'function': 'synthetic', 'propertyFatal': klass == 'unsupported_construct'}}
names = list(properties)
parts = [names[i:i + 128] for i in range(0, len(names), 128)]
assert len(parts) == 23
groups = parts[1:]
contract_gate = {'properties': properties, 'groups': groups, 'required': {}, 'prior_dynamic': {}}
gate_path = dump('gate.json', contract_gate)
runtime.update(synthetic_test_only=True, test_offsets={k: v - 1000 * N
                                                      for k, v in runtime['deadlines'].items()})
context_path = dump('slot/runtime-context.json', runtime)
binding = {'path': context_path, 'sha256': pin(context_path)}
spec = timing_spec(3835, 1274)
spec.update(context=binding, gate_contract=gate_path, gate_contract_sha256=pin(gate_path),
            solver_cwd=str(ROOT), solver_environment=common.HELPER_ENV, synthetic_test_only=True)
timing_path = dump('timing-spec.json', spec)
gate = GroupGate(contract_gate)
lines = ['Runtime Symex: 6s\n', f'PQ1-SCOPED-PARTIAL-SELECTED {sum(map(len,groups))} 2840\n']
for i, group in enumerate(groups):
    lines.append(f'PQ1-SCOPED-GROUP-BEGIN {i}\n')
    lines.append('** Results:\n')
    lines.extend(f'[{name}] {properties[name]["description"]}: SUCCESS\n' for name in group)
    lines.extend([f'\n** 0 of {len(group)} failed\n', 'VERIFICATION SUCCESSFUL\n',
                  f'PQ1-SCOPED-GROUP-END {i} 0\n'])
lines.append('PQ1-SCOPED-PARTIAL-COMPLETE 22 0\n')
raw = ''.join(lines)
acks, lower_bounds = [], []
last_sent = 3835 * N
for line in raw.splitlines(keepends=True):
    boundary = gate.line(line)
    if boundary is None:
        continue
    i = boundary['group']
    sent = (3845 + i * 60 - (1 if i == 21 else 0)) * N
    lower_bounds.append(last_sent)
    acks.append(dict(boundary, ack=f'PQ1-SCOPED-ACK {i}\n', validated_at=sent / N,
                     sent_at=sent / N, validated_ns=sent, sent_ns=sent, stdin_closed=i == 21))
    gate.acknowledge(i)
    last_sent = sent
gate.finish(0)
record = {'complete': True, 'exit': 0, 'command': spec['commands'][0],
          'group_seconds': [10] + [60] * 21, 'seconds': 1270, 'finished_ns': 5105 * N,
          'acknowledgements': acks, 'deadline_start_lower_bounds_ns': lower_bounds,
          'deadline_start_lower_bounds': [n / N for n in lower_bounds],
          'screen': budget.screen(10, 6, 5109 * N, 3845 * N)}
timing = {'schema': 'bounded-phased-v1', 'side': 'candidate', 'context': binding,
          'bounds': spec['bounds'], 'runner_start_ns': 3835 * N,
          'outer_monotonic_start': 3835, 'commands': spec['commands'], 'group_count': 22,
          'per_group_limit': budget.GROUP_SECONDS, 'first_group_limit': budget.FIRST_GROUP_SECONDS,
          'whole_limit': 1274, 'setup_included': True,
          'stop': None, 'exit': 0, 'seconds': 1271, 'timer_end_ns': 5106 * N,
          'kernel_cpu_limit': [1274] * 2, 'kernel_address_space_limit': [8 * 1024**3] * 2,
          'records': [record], 'group_seconds': record['group_seconds']}
timing_receipt = dump('timing.json', timing)
inputs = {context_path: pin(context_path), timing_path: pin(timing_path), gate_path: pin(gate_path)}
runner_spec = {'seconds': 1274, 'address_space': 8 * 1024**3,
               'context': binding, 'runner_start_ns': 3835 * N, 'bounds': spec['bounds'],
               'command': ['synthetic-timer-no-execution'], 'pins': inputs}
spec_path = dump('spec.json', runner_spec)
log_path = ROOT / 'command.log'
log_path.write_text(raw)
policy = {'root': str(ROOT), 'campaign_roots': [str(ROOT / 'slot')],
          'limits': common.LIMITS, 'synthetic_test_only': True}
effective = {'spec_sha256': pin(spec_path), 'pins': inputs,
             'command': runner_spec['command'], 'context': binding,
             'bounds': spec['bounds'], 'runner_start_ns': 3835 * N,
             'storage_policy': policy, 'execution_environment': common.HELPER_ENV,
             'initial_storage': [4096, 4096, 100 * 1024**3]}
effective_path = dump('effective.json', effective)
result = {'exit': 0, 'stop': None, 'seconds': 1276, 'solver_seconds': 1272,
          'runner_start_ns': 3835 * N, 'solver_phase_end_ns': 5107 * N,
          'post_solver_end_ns': 5111 * N, 'monotonic_start': 3835,
          'context': binding, 'bounds': spec['bounds'], 'pins_unchanged': True,
          'local_cleanup_complete': True, 'live_members_after_cleanup': [],
          'terminal_storage': [8192, 8192, 100 * 1024**3],
          'spec_sha256': pin(spec_path), 'log_sha256': pin(log_path)}
result_path = dump('result.json', result)
descriptor = {'schema': 'bounded-phased-v1', 'spec': spec_path, 'expected_spec': runner_spec,
              'result': result_path, 'log': str(log_path), 'effective': effective_path,
              'expected_effective_command': runner_spec['command'], 'resources': common.LIMITS,
              'context': binding, 'expected_storage_policy': policy,
              'expected_execution_environment': common.HELPER_ENV, 'synthetic_test_only': True}
pins = {**inputs, **{p: pin(p) for p in [spec_path, result_path, str(log_path),
                                       effective_path, timing_receipt]}}
contract = {'timing_spec': timing_path, 'timing_receipt': timing_receipt,
            'per_group_seconds': budget.GROUP_SECONDS, 'first_group_seconds': budget.FIRST_GROUP_SECONDS,
            'continuation_schema': 'bounded-phased-v1',
            'receipts': {'tail': descriptor}, 'context': binding,
            'synthetic_test_only': True, 'gate_contract': gate_path,
            'case_sha256': runtime['case_sha256'], 'profile': {'properties': properties, 'required': {}}}
common.authenticate(pins, DEADLINE)
collector.read_receipt(descriptor, pins, DEADLINE)
collector.check_timing(contract, pins, groups, runner_spec, result, inputs, DEADLINE)
collector.check_acknowledgements(contract, pins, groups, {'dynamic': {}}, raw,
                                 result, inputs, DEADLINE)
assert result['seconds'] >= runner_spec['seconds'] and result['post_solver_end_ns'] > 5109 * N
controls.append('fabricated full2840/22-group receipt crosses solver deadline; strict collectors pass')

for updates in [{'post_solver_end_ns': 5290 * N, 'seconds': 1455},
                {'solver_phase_end_ns': 5112 * N}, {'solver_seconds': 1},
                {'context': changed(binding, sha256='0' * 64)}]:
    dump('result.json', changed(result, **updates))
    mutated_pins = dict(pins, **{result_path: pin(result_path)})
    refuses(lambda: collector.read_receipt(descriptor, mutated_pins, DEADLINE))
dump('result.json', result)
refuses(lambda: collector.check_timing(contract, pins, groups, runner_spec,
                                      changed(result, seconds=1441), inputs, DEADLINE))
altered = copy.deepcopy(timing)
altered['records'][0]['screen']['remaining_seconds'] += 1
dump('timing.json', altered)
refuses(lambda: collector.check_acknowledgements(contract, pins, groups, {'dynamic': {}},
                                                raw, result, inputs, DEADLINE))
dump('timing.json', timing)
controls.append('late/reversed/changed phases, group0 total overhead and forged screen refuse')

# A second coherent fabricated receipt exercises the clamped3960 path through
# all actual validators, not just the arithmetic helper.
clamped_spec = changed(spec, whole_seconds=3960, runner_start_ns=1010 * N,
                       outer_monotonic_start=1010,
                       bounds=context.runner_bounds(runtime, 1010 * N, 3960, True))
dump('timing-spec.json', clamped_spec)
clamped_raw = raw.replace('Runtime Symex: 6s\n', 'Runtime Symex: 65s\n')
clamped_gate = GroupGate(contract_gate)
clamped_record = copy.deepcopy(record)
clamped_record.update(group_seconds=[130] + [60] * 21, seconds=1390,
                       finished_ns=2400 * N,
                       screen=budget.screen(130, 65, 4970 * N, 1140 * N))
clamped_record['deadline_start_lower_bounds_ns'] = [1010 * N] + [n - 2705 * N for n in lower_bounds[1:]]
clamped_record['deadline_start_lower_bounds'] = [n / N for n in clamped_record['deadline_start_lower_bounds_ns']]
for line in clamped_raw.splitlines(keepends=True):
    boundary = clamped_gate.line(line)
    if boundary is None:
        continue
    index = boundary['group']
    ack = clamped_record['acknowledgements'][index]
    ack.update(boundary)
    for key in ['validated_ns', 'sent_ns']:
        ack[key] -= 2705 * N
    ack['validated_at'], ack['sent_at'] = ack['validated_ns'] / N, ack['sent_ns'] / N
    clamped_gate.acknowledge(index)
clamped_timing = changed(timing, bounds=clamped_spec['bounds'], runner_start_ns=1010 * N,
                         outer_monotonic_start=1010, whole_limit=3960, seconds=1391,
                         timer_end_ns=2401 * N, kernel_cpu_limit=[3960] * 2,
                         records=[clamped_record], group_seconds=clamped_record['group_seconds'])
dump('timing.json', clamped_timing)
clamped_inputs = dict(inputs, **{timing_path: pin(timing_path)})
clamped_runner = changed(runner_spec, seconds=3960, runner_start_ns=1010 * N,
                         bounds=clamped_spec['bounds'], pins=clamped_inputs)
dump('spec.json', clamped_runner)
log_path.write_text(clamped_raw)
clamped_effective = changed(effective, spec_sha256=pin(spec_path), pins=clamped_inputs,
                            runner_start_ns=1010 * N, bounds=clamped_spec['bounds'])
dump('effective.json', clamped_effective)
clamped_result = changed(result, seconds=1396, solver_seconds=1392, runner_start_ns=1010 * N,
                         solver_phase_end_ns=2402 * N, post_solver_end_ns=2406 * N,
                         monotonic_start=1010, bounds=clamped_spec['bounds'],
                         spec_sha256=pin(spec_path), log_sha256=pin(log_path))
dump('result.json', clamped_result)
clamped_descriptor = changed(descriptor, expected_spec=clamped_runner)
clamped_pins = {p: pin(p) for p in pins}
collector.read_receipt(clamped_descriptor, clamped_pins, DEADLINE)
collector.check_timing(contract, clamped_pins, groups, clamped_runner, clamped_result, clamped_inputs, DEADLINE)
collector.check_acknowledgements(contract, clamped_pins, groups, {'dynamic': {}}, clamped_raw,
                                 clamped_result, clamped_inputs, DEADLINE)

# The validation-time screen just passes; one nanosecond before actual ACK
# delivery consumes the whole-second floor. All group/timestamp checks remain
# coherent, so rejection must specifically come from the send-time screen.
tight_spec = changed(clamped_spec, whole_seconds=3280,
                     bounds=context.runner_bounds(runtime, 1010 * N, 3280, True))
dump('timing-spec.json', tight_spec)
tight_timing = changed(clamped_timing, bounds=tight_spec['bounds'], whole_limit=3280,
                       kernel_cpu_limit=[3280] * 2)
tight_record = tight_timing['records'][0]
tight_record['screen'] = budget.screen(130, 65, 4290 * N, 1140 * N)
assert tight_record['screen']['passes']
tight_record['acknowledgements'][0]['sent_ns'] += 1
tight_record['acknowledgements'][0]['sent_at'] = tight_record['acknowledgements'][0]['sent_ns'] / N
tight_record['group_seconds'][0] += 1 / N
tight_record['group_seconds'][1] -= 1 / N
dump('timing.json', tight_timing)
tight_result = changed(clamped_result, bounds=tight_spec['bounds'])
try:
    collector.check_acknowledgements(contract, clamped_pins, groups, {'dynamic': {}}, clamped_raw,
                                     tight_result, clamped_inputs, DEADLINE)
except ValueError as error:
    assert 'first-group screen' in str(error), str(error)
else:
    raise AssertionError('send-time screen crossing accepted')
controls.append('full clamped3960 receipt validates; send-time-only screen crossing refuses')

# Coherently retime one later group; all validators see the same fabricated
# transcript and clocks. Long later groups must pass; exact600 must refuse,
# including a final group's teardown. No real sleep or original solver occurs.
dump('timing-spec.json', clamped_spec)

def retimed_group(index, seconds):
    delta = seconds - clamped_record['group_seconds'][index]
    record = copy.deepcopy(clamped_record)
    record['group_seconds'][index] = seconds
    record['seconds'] += delta
    record['finished_ns'] += int(delta * N)
    for i, ack in enumerate(record['acknowledgements']):
        if i >= index:
            ack['validated_ns'] += int(delta * N)
            ack['sent_ns'] += int(delta * N)
            ack['validated_at'] = ack['validated_ns'] / N
            ack['sent_at'] = ack['sent_ns'] / N
        if i > index:
            record['deadline_start_lower_bounds_ns'][i] += int(delta * N)
    record['deadline_start_lower_bounds'] = [n / N for n in record['deadline_start_lower_bounds_ns']]
    measured = changed(clamped_timing, records=[record], group_seconds=record['group_seconds'],
                       seconds=clamped_timing['seconds'] + delta,
                       timer_end_ns=clamped_timing['timer_end_ns'] + int(delta * N))
    outer = changed(clamped_result, seconds=clamped_result['seconds'] + delta,
                    solver_seconds=clamped_result['solver_seconds'] + delta,
                    solver_phase_end_ns=clamped_result['solver_phase_end_ns'] + int(delta * N),
                    post_solver_end_ns=clamped_result['post_solver_end_ns'] + int(delta * N))
    dump('timing.json', measured)
    return measured, outer

for index in [1, 18, 21]:
    measured, outer = retimed_group(index, 590)
    collector.check_timing(contract, clamped_pins, groups, clamped_runner, outer, clamped_inputs, DEADLINE)
    collector.check_acknowledgements(contract, clamped_pins, groups, {'dynamic': {}}, clamped_raw,
                                     outer, clamped_inputs, DEADLINE)
    measured, outer = retimed_group(index, 600)
    refuses(lambda: collector.check_timing(contract, clamped_pins, groups, clamped_runner,
                                           outer, clamped_inputs, DEADLINE))
    refuses(lambda: collector.check_acknowledgements(contract, clamped_pins, groups, {'dynamic': {}},
                                                    clamped_raw, outer, clamped_inputs, DEADLINE))
controls.append('coherent590s later/final groups pass; exact600s ACK/teardown refuses')

print(json.dumps({'synthetic_test_only': True, 'fabricated_receipts': True,
                  'status': 'PASS', 'controls': controls, 'original_queries': 0,
                  'full_R2_gate_complete': False}), flush=True)
