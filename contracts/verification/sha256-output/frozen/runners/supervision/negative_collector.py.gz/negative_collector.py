"""Fresh-only negative evidence; tail ACKs never supply a whole-case verdict."""
from pathlib import Path
import time

import budget
import collector as c
import common
import context
from budget import NANO, require

ROLES = {'fresh_census': 'bounded', 'tail': 'bounded-phased-v1',
         'root': 'bounded-root-v1'}


def inputs(contract, pins, deadline_ns):
    profile = contract['profile']
    require(profile['kind'] == context.KIND
            and contract['continuation_schema'] == 'bounded-phased-v1'
            and contract['per_group_seconds'] == budget.GROUP_SECONDS
            and contract['first_group_seconds'] == budget.FIRST_GROUP_SECONDS,
            'wrong negative collection profile')
    binding = contract['context']
    require(pins.get(binding['path']) == binding['sha256'], 'unbound negative context')
    synthetic = contract.get('synthetic_test_only') is True
    runtime = context.load(binding, deadline_ns, synthetic=synthetic)
    require(runtime['case_sha256'] == contract['case_sha256'], 'wrong negative case')
    slot = Path(runtime['slot'])
    for key, suffix in [('gate_contract', 'gate-contract.json'),
                        ('timing_spec', 'tail/timing-spec.json'),
                        ('timing_receipt', 'tail/timing.json')]:
        require(contract[key] == str(slot / suffix), 'substituted negative evidence path')
    require(len(profile['properties']) == 2840 and len(profile['parts']) == 23
            and profile['order'] == profile['composition_order']
            and profile['solver_order'] == profile['order'][1:] + [0],
            'changed full negative census or scheduling')
    required = profile['required']
    failure = profile['expected_failure']
    require(len(required) == 2 and set(required.values()) == {'FAILURE'}
            and failure in required and set(required) <= set(profile['parts'][0])
            and profile['properties'][failure]['class'] == 'assertion'
            and {profile['properties'][n]['class'] for n in required}
            == {'assertion', 'reachability_check'}, 'wrong negative root failure contract')
    for path in [profile['candidate'], profile['manifest'], profile['program']]:
        require(path in pins, 'unbound negative input: ' + path)
    require(pins[profile['program']] == profile['program_sha256'], 'changed negative program')
    for filename in ['pq1_promoted_census.py', 'pq1_partition.py', 'pq1_partition_anonymous.json']:
        require(str(common.SOURCE / filename) in pins, 'unbound negative parser')
    c.expected_commands(profile)
    groups = c.validate_selection(profile, c.read(profile['manifest'], deadline_ns))
    common.storage_policy(contract['storage_policy'], synthetic)
    return runtime, groups


def receipt(contract, pins, runtime, role, deadline_ns):
    descriptor = contract['receipts'][role]
    slot, binding = Path(runtime['slot']), contract['context']
    require(descriptor['schema'] == ROLES[role] and descriptor['context'] == binding,
            'negative receipt cannot use historical or unbound evidence')
    for key, name in [('spec', 'spec.json'), ('result', 'result.json'),
                      ('log', 'command.log'), ('effective', 'effective.json')]:
        require(descriptor[key] == str(slot / role / name), 'negative receipt outside fresh slot')
    synthetic = contract.get('synthetic_test_only') is True
    require((descriptor.get('synthetic_test_only') is True) is synthetic,
            'mixed synthetic/production negative receipts')
    spec, result, raw, actual_inputs = c.read_receipt(descriptor, pins, deadline_ns)
    profile = contract['profile']
    for path in [profile['program'], profile['candidate'], profile['manifest']]:
        require(actual_inputs.get(path) == pins[path], 'negative invocation omitted input')
    require(spec['cwd'] == contract['execution']['cwd']
            and spec['environment'] == contract['execution']['environment']
            and spec['output'] == str(slot / role)
            and spec['address_space'] == (8 if synthetic else 16) * 1024**3
            and spec['file_bytes'] == common.FILE_BYTES
            and descriptor['expected_storage_policy'] == contract['storage_policy'],
            'changed negative environment, output or resources')
    kernel = ['/usr/bin/prlimit', f'--cpu={spec["seconds"]}:{spec["seconds"]}',
              f'--as={spec["address_space"]}:{spec["address_space"]}',
              f'--fsize={common.FILE_BYTES}:{common.FILE_BYTES}', '--core=0:0',
              '--', *spec['command']]
    require(descriptor['expected_effective_command'] == kernel, 'changed negative kernel wrapper')
    allocation_path = str(slot / (role + '-allocation.json'))
    require(allocation_path in pins and actual_inputs.get(allocation_path) == pins[allocation_path],
            'allocation missing from actual invocation inputs')
    allocation = common.bound_json(allocation_path, pins[allocation_path], deadline_ns)
    started = spec['runner_start_ns']
    cap = (180 if role == 'fresh_census' else
           budget.tail_cap(runtime['deadlines']['solver'], started) if role == 'tail' else
           budget.root_cap(runtime['deadlines']['solver'], started))
    if synthetic and role == 'tail':
        cap = min(cap, 600)
    expected = {'role': role, 'allocated_ns': started, 'seconds': cap, 'context': binding}
    if synthetic:
        expected['synthetic_test_only'] = True
    require(allocation == expected and spec['seconds'] == cap, 'changed negative allocation')
    if role == 'tail':
        timing_path = contract['timing_spec']
        require(timing_path in pins, 'unbound negative timer command')
        timing = common.bound_json(timing_path, pins[timing_path], deadline_ns)
        require(timing['commands'] == [c.expected_commands(profile)['tail']]
                and timing['solver_cwd'] == spec['cwd']
                and timing['solver_environment'] == spec['environment']
                and spec['command'] == common.helper_command(
                    'timer', timing_path, pins[timing_path], contract['timing_receipt']),
                'changed negative tail controller or solver invocation')
    else:
        c.validate_command(profile, role, spec['command'])
    return spec, result, raw, actual_inputs


def tail_evidence(contract, pins, deadline_ns):
    """Complete tail validation is required before allocating the fresh root."""
    c.authenticate(pins, deadline_ns)
    runtime, groups = inputs(contract, pins, deadline_ns)
    spec, result, raw, actual_inputs = receipt(contract, pins, runtime, 'tail', deadline_ns)
    c.check_timing(contract, pins, groups, spec, result, actual_inputs, deadline_ns)
    capture = c.check_new_acknowledgements(contract, pins, groups, None, raw,
                                           result, actual_inputs, deadline_ns)
    reports = c.parse_partial(raw, contract['profile']['properties'], groups, result['exit'])
    for report in reports:
        # There is deliberately no expected semantic failure in a tail group.
        c.partition.semantic_check(contract['profile']['properties'], report, {})
        require(report['dynamic'] == capture['dynamic'], 'negative tail dynamic drift')
    common.check(deadline_ns)
    return reports, capture, (spec, result, raw, actual_inputs)


def preceding_validation(contract, pins, runtime, role, result, next_inputs, next_start, deadline_ns):
    path = str(Path(runtime['slot']) / (role + '-validation.json'))
    require(path in pins and next_inputs.get(path) == pins[path],
            'next phase omitted preceding validation')
    record = common.bound_json(path, pins[path], deadline_ns)
    require(set(record) == {'role', 'context', 'result_sha256', 'finished_ns', 'proof_credit'}
            and record['role'] == role and record['context'] == contract['context']
            and record['result_sha256'] == pins[contract['receipts'][role]['result']]
            and record['proof_credit'] is False
            and budget.integer(record['finished_ns'])
            and result['post_solver_end_ns'] <= record['finished_ns'] <= next_start
            and record['finished_ns'] < result['bounds']['post_deadline_ns'],
            'late, reordered or changed negative phase validation')


def compose_negative(profile, tail, capture, raw_root, root_exit):
    """Semantic closure only; fresh receipt authentication is owned by collect_negative."""
    report = c.partition.parse_report(raw_root, profile['properties'], profile['parts'][0], root_exit)
    c.partition.semantic_check(profile['properties'], report, profile['required'], profile['expected_failure'])
    require(report['dynamic'] == capture['dynamic'], 'fresh root dynamic set differs from first tail')
    return c.compose_reports(profile['properties'], profile['parts'], profile['order'], report,
                             tail, profile['required'], profile['expected_failure'])


def collect_negative(contract, pins, deadline_ns):
    require(set(contract['receipts']) == set(ROLES), 'all three fresh negative receipts required')
    tail, capture, tail_record = tail_evidence(contract, pins, deadline_ns)
    runtime, _ = inputs(contract, pins, deadline_ns)
    census = receipt(contract, pins, runtime, 'fresh_census', deadline_ns)
    root = receipt(contract, pins, runtime, 'root', deadline_ns)
    profile = contract['profile']
    require(census[1]['exit'] == 0 and c.partition.census(census[2]) == profile['properties'],
            'fresh negative census differs from complete frozen census')
    preceding_validation(contract, pins, runtime, 'fresh_census', census[1], tail_record[3],
                         tail_record[0]['runner_start_ns'], deadline_ns)
    preceding_validation(contract, pins, runtime, 'tail', tail_record[1], root[3],
                         root[0]['runner_start_ns'], deadline_ns)
    capture_path = str(Path(runtime['slot']) / 'tail/first-tail-dynamic.json')
    for path in [capture_path, contract['timing_receipt'], contract['receipts']['tail']['result'],
                 contract['receipts']['tail']['log']]:
        require(root[3].get(path) == pins[path], 'fresh root omitted completed tail binding')
    result = compose_negative(profile, tail, capture, root[2], root[1]['exit'])
    # Collection, including full composition, is part of the root allocation.
    # A later independent replay may use these source functions for semantics,
    # but cannot turn an expired original clock into a new execution verdict.
    stop_at = min(deadline_ns, root[1]['bounds']['post_deadline_ns'])
    common.check(stop_at)
    result.update(kind=context.KIND, fresh_root=True, dynamic_origin='first-fresh-tail-group',
                  dynamic_capture_sha256=pins[capture_path], validated_at_ns=time.monotonic_ns(),
                  collection_deadline_ns=stop_at)
    common.check(stop_at)
    return result
