"""Static production admission; no slot reservation or solver invocation here.

Positive and N1 evidence are prerequisites only. Their approvals never select
the new execution. A distinct implementation closure and one-use selection are
mandatory, in addition to the independently fixed original proof inputs.
"""
import os
from pathlib import Path
import subprocess
import time

import budget
import collector
import common
import context
from budget import NANO, require

BASE = common.RESEARCH / 'corrected-digest/circular-watch-implementation-v1'
POSITIVE = common.RESEARCH / 'corrected-digest/result-file-continuation-implementation-v1'
PREVIOUS = common.RESEARCH / 'corrected-digest/full-negative-implementation-v1'
N1 = PREVIOUS / 'prepared-negative-v2'
CBMC_SHA = '5b26cd0862504f5cbce06b89a19e9195c82b1d8730931c6882e4109ac212feff'
GOTO_SHA = '293a8551970612b1a3c6b5504fd8124f8ffe638d37b4c72ac8f455b911f04d79'
SLOT = common.CAMPAIGN / context.KIND
GROUPS = common.CAMPAIGN / 'n2-tail-groups-v1.json'
ORDER = [0, 2, 1, 5, 12, 13, 3, 9, 8, 10, 11, 4, 16, 6, 7, 14, 15, 17, 18, 21, 19, 22, 20]
MARKERS = {'synthetic_test_only', 'not_execution_authority', 'not_actual_review_evidence'}


def ref(path, digest):
    return {'path': str(path), 'sha256': digest}


POSITIVE_ACCEPTANCE = ref(POSITIVE / 'positive-acceptance-v1.json',
    '0cf0a8f2f7c2d345424eee6e2204ca884a2ae81eb0ce8d149945610a62a6c3f4')
POSITIVE_PINS = ref(POSITIVE / 'accepted-positive-pins-v1.json',
    '2006f97adfece06540975a228ee6617395f1fec793e4c2acc0f13bdb24ea54b0')
N1_COMPLETE = ref(PREVIOUS / 'n1-completion-v2.json',
    '5fc8825d2d716f7e028a2371559307c0438e4b06256de260e117500e5be8d3c5')
N1_PINS = ref(PREVIOUS / 'n1-accepted-artifact-pins-v2.json',
    '50770472b06e614434509d32272b5ebfdc2a1f31af20460e56976daf712a13b5')
PROFILE = ref(PREVIOUS / 'negative-census-profile-v2.json',
    'acd68db23926dca6ec71242f776dd792d4f11c2a3b8638e9de6e47d9f698bd42')
NATIVE = ref(PREVIOUS / 'n1-helper-runtime-v4.json',
    'c1d86fcc95e5c5d2e2001aec9ba35ffdba503117a9e434659af2f75ce07f8a04')


FAILED = ref(PREVIOUS / 'n2-stopping-decision-v1.json',
    '711a2747202c1307447f60f8a73ef66d66f671bae82a35370281000ff055cc0a')
FAILED_PINS = ref(PREVIOUS / 'n2-stopped-artifact-pins-v1.json',
    'a38cf0039a8de16948aa4aab8d2e238a177f521d0891560c58012836fd02646c')
ALLOCATION = ref(common.CAMPAIGN / 'correction-allocation-v1.json',
    '3646503f2bd8c254d5b994bb3af01ef1d1e8862d13ef8a9cd9849cb2b0be8038')


def production(value):
    if isinstance(value, dict):
        require(MARKERS.isdisjoint(value), 'synthetic data cannot authorize production')
        for child in value.values():
            production(child)
    elif isinstance(value, list):
        for child in value:
            production(child)


def bound(reference, deadline_ns):
    require(set(reference) == {'path', 'sha256'}, 'invalid static input reference')
    require(Path(reference['path']).is_absolute(), 'relative static input path')
    return common.bound_json(reference['path'], reference['sha256'], deadline_ns)


def merge(pins, additions):
    for path, digest in additions.items():
        require(path not in pins or pins[path] == digest, 'conflicting input pin: ' + path)
        pins[path] = digest


def retained_inputs(deadline_ns):
    """Keep full positive evidence and the successful N1 closure as prerequisites."""
    positive = bound(POSITIVE_ACCEPTANCE, deadline_ns)
    require(positive['status'] == 'PASS' and positive['complete'] is True
            and positive['host_exit'] == 0 and positive['all_local_children_reaped'] is True
            and positive['input_pins_unchanged'] is True
            and positive['accounting']['total_case_seconds'] == 7149.895661964896
            and positive['evidence_manifest'] == POSITIVE_PINS,
            'changed positive prerequisite or retained debit')
    retained = dict(bound(POSITIVE_PINS, deadline_ns))
    require(len(retained) == 72096, 'incomplete positive prerequisite manifest')
    completed = bound(N1_COMPLETE, deadline_ns)
    require(completed['N1_complete'] is True and completed['artifact_manifest'] == N1_PINS
            and completed['profile'] == PROFILE and completed['preparation_debit_seconds'] == 481
            and completed['negative_inherited_seconds'] == 19
            and completed['negative_backend_total_seconds'] == 4320
            and completed['negative_backend_remaining_seconds'] == 4301
            and completed['negative_solver_selected'] is False
            and completed['negative_complete'] is False,
            'changed N1 completion, preparation debit or negative budget')
    artifacts = bound(N1_PINS, deadline_ns)
    require(set(artifacts) == {'files', 'symlink_texts'} and len(artifacts['files']) == 918,
            'incomplete N1 artifact closure')
    merge(retained, artifacts['files'])
    for path, target in artifacts['symlink_texts'].items():
        common.check(deadline_ns)
        require(os.readlink(path) == target, 'changed N1 tool symlink')
    for reference in [POSITIVE_ACCEPTANCE, POSITIVE_PINS, N1_COMPLETE, N1_PINS, PROFILE, NATIVE]:
        merge(retained, {reference['path']: reference['sha256']})
    for key in ['preparation_terminal', 'census_terminal', 'full_census_audit', 'controls']:
        reference = completed[key]
        # The audit binds the artifact manifest, so its own digest lives in
        # the separately pinned completion record rather than that manifest.
        merge(retained, {reference['path']: reference['sha256']})
        bound(reference, deadline_ns)
    failure = bound(FAILED, deadline_ns)
    require(failure['status'] == 'STOPPED_UNACCEPTED' and failure['proof_credit'] is False
            and failure['negative_complete'] is False and failure['artifacts'] == FAILED_PINS
            and failure['accounting']['negative_total_seconds'] == budget.INHERITED
            and failure['accounting']['attempt_debit_seconds'] == 4301
            and failure['accounting']['prior_negative_seconds'] == 19
            and failure['surviving_recorded_identities'] == [], 'changed failed negative ledger')
    failed_pins = bound(FAILED_PINS, deadline_ns)
    require(len(failed_pins) == 73079, 'incomplete failed negative evidence')
    merge(retained, failed_pins)
    allocation = bound(ALLOCATION, deadline_ns)
    require(allocation['failed_attempt'] == FAILED and allocation['failed_artifacts'] == FAILED_PINS
            and allocation['negative_inherited_seconds'] == budget.INHERITED
            and allocation['negative_cumulative_ceiling_seconds'] == budget.TOTAL
            and allocation['new_attempt_limit_seconds'] == budget.ATTEMPT
            and allocation['first_group_seconds'] == budget.FIRST_GROUP_SECONDS
            and allocation['later_group_seconds'] == budget.GROUP_SECONDS
            and allocation['tail_max_seconds'] == budget.TAIL_MAX
            and allocation['kind'] == context.KIND, 'changed bounded correction allocation')
    for reference in [FAILED, FAILED_PINS, ALLOCATION, allocation['trigger']]:
        merge(retained, {reference['path']: reference['sha256']})
        bound(reference, deadline_ns)
    return retained, completed


def launch(reference, deadline_ns):
    spec = bound(reference, deadline_ns)
    production(spec)
    require(set(spec) == {'kind', 'slot', 'case', 'selection_path', 'helper_environment',
                          'host_active_limit_seconds', 'host_address_space', 'host_file_bytes'}
            and spec['kind'] == context.KIND and spec['slot'] == str(SLOT),
            'unselected launch profile or slot')
    require(spec['helper_environment'] == common.HELPER_ENV
            and spec['host_active_limit_seconds'] == 4380
            and spec['host_address_space'] == 16 * 1024**3
            and spec['host_file_bytes'] == common.FILE_BYTES,
            'changed launcher environment/resources or insufficient exit margin')
    require(Path(spec['selection_path']).is_absolute(), 'invalid selection location')
    return spec


def load_case(reference, deadline_ns):
    case = bound(reference, deadline_ns)
    production(case)
    require(set(case) == {'kind', 'inherited_seconds', 'cumulative_total', 'attempt_limit',
                          'pins_manifest', 'helper_sources', 'helper_runtime', 'storage_policy'}
            and case['kind'] == context.KIND
            and case['inherited_seconds'] == budget.INHERITED
            and case['cumulative_total'] == budget.TOTAL
            and case['attempt_limit'] == budget.ATTEMPT
            and case['helper_runtime'] == NATIVE, 'wrong negative case/policy/runtime')
    common.storage_policy(case['storage_policy'])
    pins = bound(case['pins_manifest'], deadline_ns)
    common.authenticate(pins, deadline_ns)
    retained, completed = retained_inputs(deadline_ns)
    require(all(pins.get(path) == digest for path, digest in retained.items()),
            'negative case omitted retained positive or N1 dependency/evidence')
    common.source_closure(case['helper_sources'], deadline_ns)
    require(all(pins.get(path) == digest for path, digest in case['helper_sources'].items()),
            'case omitted current helper source binding')
    native = bound(NATIVE, deadline_ns)
    require(native['helper_environment'] == common.HELPER_ENV
            and native['helper_flags'] == ['-E', '-S', '-B']
            and '/usr/bin/git' in native['file_pins']
            and all(pins.get(path) == digest for path, digest in native['file_pins'].items()),
            'changed or missing native helper runtime')
    for path, target in native['symlink_texts'].items():
        common.check(deadline_ns)
        require(os.readlink(path) == target, 'changed helper runtime symlink')
    for path in native['absent_files']:
        require(not os.path.lexists(path), 'unselected native preload/configuration')
    profile = bound(PROFILE, deadline_ns)
    require(profile['kind'] == 'original-negative-oracle-byte-v1' and profile['full_census_audit_complete'] is True
            and profile['artifact_manifest'] == N1_PINS
            and profile['preparation_terminal'] == completed['preparation_terminal']
            and profile['census_terminal'] == completed['census_terminal']
            and profile['composition_order'] == ORDER
            and profile['solver_order'] == ORDER[1:] + [0]
            and len(profile['parts']) == 23 and len(profile['properties']) == 2840
            and len(profile['unsupported_guards']) == 19
            and len(profile['fatal_obligations']) == 1125
            and profile['program'] == str(N1 / 'prepared.out')
            and profile['program_sha256'] == GOTO_SHA
            and pins.get(profile['program']) == GOTO_SHA
            and profile['base_command'][0] == str(BASE / 'build/bin/cbmc')
            and pins.get(profile['base_command'][0]) == CBMC_SHA,
            'changed prepared negative or complete census contract')
    profile = dict(profile, kind=context.KIND, order=ORDER, candidate=str(BASE / 'build/bin/cbmc'),
                   prior_backend='minisat2', manifest=str(GROUPS))
    require(pins.get(str(GROUPS)) == common.sha(GROUPS, deadline_ns), 'unbound tail selection')
    collector.validate_selection(profile, common.read(GROUPS, deadline_ns))
    census_spec_path = str(N1 / 'census/spec.json')
    require(census_spec_path in retained, 'missing N1 census invocation')
    census_spec = common.bound_json(census_spec_path, retained[census_spec_path], deadline_ns)
    collector.validate_command(profile, 'fresh_census', census_spec['command'])
    execution = {'cwd': census_spec['cwd'], 'environment': census_spec['environment']}
    require(execution['cwd'] == str(N1 / 'inputs/project'), 'changed negative working directory')
    merge(pins, {reference['path']: reference['sha256'],
                 case['pins_manifest']['path']: case['pins_manifest']['sha256']})
    common.check(deadline_ns)
    return case, execution, profile, None, pins


def selected(reference, launch_reference, launch_spec, case, pins, owner, deadline_ns):
    selection = bound(reference, deadline_ns)
    production(selection)
    require(reference['path'] == launch_spec['selection_path']
            and selection['kind'] == context.KIND and selection['selected'] is True
            and selection['case'] == launch_spec['case']
            and selection['launch_spec'] == launch_reference
            and selection['slot'] == str(SLOT)
            and selection['no_resume_or_retry'] is True,
            'missing exact one-use execution selection')
    closure = bound(selection['review_closure'], deadline_ns)
    production(closure)
    require(closure['stage'] == 'full-negative-group-budget-implementation'
            and closure['decision'] == 'GO' and closure['mandatory_gaps'] == []
            and closure['reviewers'] == ['astra-ultra', 'opus-5.5-xhigh']
            and closure['case'] == launch_spec['case']
            and closure['launch_spec'] == launch_reference
            and closure['implementation_pins'] == case['helper_sources']
            and closure['mandatory_controls_complete'] is True,
            'missing full implementation/control review closure')
    observed = []
    git = ['/usr/bin/git', '-c', 'core.fsmonitor=false', '-c', 'core.untrackedCache=false']
    for command in [git + ['rev-parse', 'HEAD'], git + ['rev-parse', 'HEAD^{tree}'],
                    git + ['status', '--porcelain', '--untracked-files=all']]:
        common.check(deadline_ns)
        process = subprocess.Popen(command, cwd=common.SOURCE.parents[1], env=common.HELPER_ENV,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        owner.register(process)
        data, _ = process.communicate(timeout=min(15, (deadline_ns - time.monotonic_ns()) / NANO))
        common.check(deadline_ns)
        require(process.returncode == 0, 'cannot authenticate reviewed Git identity')
        observed.append(data.decode().strip())
    require(observed == [closure['head'], closure['tree'], ''], 'reviewed implementation drift')
    merge(pins, {reference['path']: reference['sha256'],
                 launch_reference['path']: launch_reference['sha256'],
                 selection['review_closure']['path']: selection['review_closure']['sha256']})
    return selection
