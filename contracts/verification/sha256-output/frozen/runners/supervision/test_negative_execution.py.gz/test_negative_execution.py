"""Finite negative-route controls; fabricated properties, never an original query."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

import authority
import budget
import collector
import common
import context
import negative_collector as nc
from group_gate import GroupGate, negative_contract

ROOT = Path(sys.argv[1])
ROOT.mkdir()
END = time.monotonic_ns() + 8 * budget.NANO
checks = []
refusals = 0


def refuses(action):
    global refusals
    try:
        action()
    except (ValueError, RuntimeError):
        refusals += 1
        return
    raise AssertionError('invalid negative evidence accepted')


def reference(name, value):
    path = ROOT / name
    common.write(path, value, END)
    return {'path': str(path), 'sha256': common.sha(path, END)}


def prop(name, klass='assertion', description=None, expression='TRUE', fatal=False):
    description = description or name
    return {'name': name, 'class': klass, 'description': description, 'expression': expression,
            'sourceLocation': {'propertyId': name, 'propertyClass': klass, 'comment': description,
                               'file': 'synthetic.rs', 'function': 'synthetic', 'propertyFatal': fatal}}


properties = {'root.assertion.0': prop('root.assertion.0', fatal=True),
              'root.assertion.1': prop('root.assertion.1', description='[KANI_CHECK_ID_root] oracle'),
              'root.reachability_check.1': prop('root.reachability_check.1', 'reachability_check',
                                               'KANI_CHECK_ID_root', 'FALSE'),
              'root.assertion.2': prop('root.assertion.2')}
root_ids = list(properties)
groups = []
for i in range(22):
    name = f'tail.assertion.{i}'
    properties[name] = prop(name, fatal=i == 0)
    groups.append([name])
required = {'root.assertion.1': 'FAILURE', 'root.reachability_check.1': 'FAILURE'}
profile = {'kind': context.KIND, 'properties': properties, 'parts': [root_ids] + groups,
           'required': required, 'expected_failure': 'root.assertion.1', 'order': list(range(23))}
contract = negative_contract(profile, groups)


def body(names, failures=(), dynamic=True, dynamic_failure=False, loop=0):
    rows = ''.join(f'[{n}] {properties[n]["description"]}: '
                   + ('FAILURE' if n in failures else 'SUCCESS') + '\n' for n in names)
    if dynamic:
        rows += f'[synthetic.unwind.{loop}] line 9 unwinding assertion loop {loop}: '
        rows += 'FAILURE\n' if dynamic_failure else 'SUCCESS\n'
    failed = sum(n in failures for n in names) + int(dynamic and dynamic_failure)
    return ('** Results:\n' + rows + f'\n** {failed} of {len(names) + int(dynamic)} failed\n'
            + ('VERIFICATION FAILED\n' if failed else 'VERIFICATION SUCCESSFUL\n'))


def feed_group(gate, i, text, code=0):
    if i == 0:
        gate.line('Runtime Symex: 0s\n')
        gate.line(f'PQ1-SCOPED-PARTIAL-SELECTED 22 {len(properties)}\n')
    gate.line(f'PQ1-SCOPED-GROUP-BEGIN {i}\n')
    for line in text.splitlines(keepends=True):
        gate.line(line)
    return gate.line(f'PQ1-SCOPED-GROUP-END {i} {code}\n')


gate = GroupGate(contract)
for i, group in enumerate(groups):
    boundary = feed_group(gate, i, body(group))
    assert boundary['dynamic_count'] == 1
    assert boundary['dynamic_capture_sha256'] == gate.dynamic_capture_sha256
    if i == 0:
        assert gate.dynamic_capture['statuses'] == {'synthetic.unwind.0': 'SUCCESS'}
        assert gate.dynamic_capture['body_sha256'] == hashlib.sha256(
            ('Runtime Symex: 0s\n' + body(group)).encode()).hexdigest()
        capture = copy.deepcopy(gate.dynamic_capture)
        digest = hashlib.sha256((json.dumps(capture, indent=2) + '\n').encode()).hexdigest()
        assert digest == gate.dynamic_capture_sha256
    gate.acknowledge(i)
gate.line('PQ1-SCOPED-PARTIAL-COMPLETE 22 0\n')
tail = gate.finish(0)
assert gate.dynamic_capture == capture
checks.append('first successful tail captures nonempty exact metadata/status/body; all22 groups match')

for failures, dynamic_failure in [(['tail.assertion.0'], False), ([], True)]:
    refused_gate = GroupGate(contract)
    refuses(lambda: feed_group(refused_gate, 0, body(groups[0], failures, dynamic_failure=dynamic_failure), 10))
    assert refused_gate.dynamic_capture is None
for mutation in [dict(dynamic=False), dict(loop=1), dict(dynamic_failure=True)]:
    drift = GroupGate(contract)
    feed_group(drift, 0, body(groups[0]))
    drift.acknowledge(0)
    refuses(lambda: feed_group(drift, 1, body(groups[1], **mutation),
                               10 if mutation.get('dynamic_failure') else 0))
refuses(lambda: GroupGate(dict(contract, prior_dynamic={})))
refuses(lambda: GroupGate(dict(contract, dynamic_origin='historical-positive')))
bad_groups = copy.deepcopy(groups)
bad_groups[0] = ['root.assertion.1', 'root.reachability_check.1']
refuses(lambda: GroupGate(dict(contract, groups=bad_groups)))
checks.append('failed first dynamic/fatal, later missing/changed/failed dynamic and imported history refuse')

good_root = body(root_ids, required)
result = nc.compose_negative(profile, tail, capture, good_root, 10)
assert result == {'static_count': len(properties), 'dynamic_count': 1, 'partition_count': 23,
                  'complete': True, 'expected_failure': 'root.assertion.1', 'private_adoption': False}
for failures, options in [([], {}), (['root.assertion.1'], {}),
                          (list(required) + ['root.assertion.0'], {}),
                          (list(required) + ['root.assertion.2'], {}),
                          (list(required), {'dynamic': False}),
                          (list(required), {'loop': 1}),
                          (list(required), {'dynamic_failure': True})]:
    text = body(root_ids, failures, **options)
    code = 10 if failures or options.get('dynamic_failure') else 0
    refuses(lambda: nc.compose_negative(profile, tail, capture, text, code))
refuses(lambda: nc.compose_negative(profile, tail[:-1], capture, good_root, 10))
refuses(lambda: nc.compose_negative(profile, tail, capture, good_root, 0))
altered_tail = copy.deepcopy(tail)
altered_tail[0]['rows']['tail.assertion.0'] = 'FAILURE'
refuses(lambda: nc.compose_negative(profile, altered_tail, capture, good_root, 10))
refuses(lambda: nc.collect_negative({'receipts': {'prior': {}, 'fresh_census': {}, 'tail': {}}}, {}, END))
checks.append('fresh-root semantics require intended reachable failure, all fatal/dynamic successes and23-part union')

launch = {'kind': context.KIND, 'slot': str(authority.SLOT), 'case': {'path': '/unused', 'sha256': 'a'*64},
          'selection_path': str(ROOT / 'selection.json'), 'helper_environment': common.HELPER_ENV,
          'host_active_limit_seconds': 4380, 'host_address_space': 16 * 1024**3,
          'host_file_bytes': common.FILE_BYTES}
assert authority.launch(reference('launch-good.json', launch), END) == launch
for i, change in enumerate([{'kind': 'original-negative-oracle-byte-v1'}, {'slot': str(ROOT / 'old')},
                             {'host_active_limit_seconds': 5000}, {'host_file_bytes': 2**30},
                             {'helper_environment': {}}, {'synthetic_test_only': True}]):
    value = dict(launch, **change)
    bound = reference(f'launch-bad-{i}.json', value)
    refuses(lambda: authority.launch(bound, END))
case = {'kind': context.KIND, 'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
        'attempt_limit': budget.ATTEMPT,
        'pins_manifest': {}, 'helper_sources': {}, 'helper_runtime': authority.NATIVE,
        'storage_policy': common.PRODUCTION_STORAGE}
for i, change in enumerate([{'inherited_seconds': 0}, {'inherited_seconds': 19},
                           {'cumulative_total': 10800}, {'attempt_limit': 4321},
                           {'helper_runtime': {}}, {'kind': 'original-full-prefix'}]):
    bound = reference(f'case-bad-{i}.json', dict(case, **change))
    refuses(lambda: authority.load_case(bound, END))
closure = {'stage': 'full-negative-implementation', 'decision': 'GO', 'mandatory_gaps': [],
           'reviewers': ['astra-ultra', 'opus-5.5-xhigh'], 'case': launch['case'],
           'launch_spec': {}, 'implementation_pins': {}, 'mandatory_controls_complete': True}
selection = {'kind': context.KIND, 'selected': True, 'case': launch['case'], 'launch_spec': {},
             'slot': str(authority.SLOT), 'no_resume_or_retry': True,
             'review_closure': reference('old-closure.json', closure)}
bound = reference('selection.json', selection)
refuses(lambda: authority.selected(bound, {}, launch, case, {}, None, END))
checks.append('old kind/slot/ledger/caps/native binding and prior implementation closure refuse before execution')

start = 1000 * budget.NANO
runtime = {'start_ns': start, 'deadlines': budget.deadlines(start)}
assert budget.reservation() == 4301
assert budget.root_cap(runtime['deadlines']['solver'], 5000 * budget.NANO) == 109
root_bounds = context.runner_bounds(runtime, 5000 * budget.NANO, 109, False, root=True)
assert root_bounds['post_deadline_ns'] == root_bounds['effective_solver_deadline_ns'] == 5109 * budget.NANO
assert context.runner_bounds(runtime, start, 180, False)['post_deadline_ns'] == 1180 * budget.NANO
for cap in [0, 601, True]:
    refuses(lambda: context.runner_bounds(runtime, start, cap, False, root=True))
refuses(lambda: context.runner_bounds(runtime, start, 180, True, root=True))
checks.append('negative reservation4301; root/census full caps and conflicting roles checked')
common.check(END)
print(json.dumps({'status': 'PASS', 'synthetic_test_only': True, 'fabricated_properties': True,
                  'checks': checks, 'refused_mutations': refusals, 'original_queries': 0}), flush=True)
