"""Fresh negative census, acknowledged tail, then root and complete composition."""
import math
from pathlib import Path
import time

import authority
import budget
import collector
import common
import context
import negative_collector
from budget import NANO, require
from group_gate import negative_contract
from process_ownership import OwnedTree
from runner import execute
from watchdog import parent_is


def run_case(case, legacy, profile, prior, pins, runtime, binding, owner, synthetic=False):
    slot = Path(runtime['slot'])
    deadline = runtime['deadlines']['work']
    require(prior is None and set(legacy) == {'cwd', 'environment'},
            'negative execution cannot import a historical root or census')
    receipts = {}
    gate_path = slot / 'gate-contract.json'
    groups = collector.validate_selection(profile, common.read(profile['manifest'], deadline))
    common.write(gate_path, negative_contract(profile, groups), deadline)
    authority.merge(pins, {str(gate_path): common.sha(gate_path, deadline),
                           binding['path']: binding['sha256']})
    commands = collector.expected_commands(profile)
    contract = {'profile': profile, 'receipts': receipts,
                'timing_spec': str(slot / 'tail/timing-spec.json'),
                'timing_receipt': str(slot / 'tail/timing.json'),
                'per_group_seconds': budget.GROUP_SECONDS, 'first_group_seconds': budget.FIRST_GROUP_SECONDS,
                'continuation_schema': 'bounded-phased-v1',
                'context': binding, 'case_sha256': runtime['case_sha256'],
                'gate_contract': str(gate_path), 'execution': legacy,
                'storage_policy': case['storage_policy']}
    if synthetic:
        contract['synthetic_test_only'] = True
    attempts, proof = [], None
    for role in ['fresh_census', 'tail', 'root']:
        common.check(runtime['deadlines']['solver'])
        allocated_ns = time.monotonic_ns()
        cap = (180 if role == 'fresh_census' else
               budget.tail_cap(runtime['deadlines']['solver'], allocated_ns) if role == 'tail' else
               budget.root_cap(runtime['deadlines']['solver'], allocated_ns))
        require(cap > 0, 'negative allocation exhausted')
        if synthetic and role == 'tail':
            cap = min(cap, 600)  # Explicitly test-only further clipping.
        spec = {'command': commands[role], 'cwd': legacy['cwd'],
                'environment': legacy['environment'], 'output': str(slot / role),
                'seconds': cap, 'address_space': (8 if synthetic else 16) * 1024**3,
                'file_bytes': common.FILE_BYTES}
        allocation = {'role': role, 'allocated_ns': allocated_ns, 'seconds': cap, 'context': binding}
        if synthetic:
            allocation['synthetic_test_only'] = True
        allocation_path = slot / (role + '-allocation.json')
        common.write(allocation_path, allocation, deadline)
        authority.merge(pins, {str(allocation_path): common.sha(allocation_path, deadline)})
        timing = {'gate_contract': str(gate_path), 'gate_contract_sha256': pins[str(gate_path)],
                  'dynamic_capture': str(slot / 'tail/first-tail-dynamic.json')} if role == 'tail' else None
        descriptor, result, new_pins = execute(spec, pins, binding, owner,
                                              case['storage_policy'], case['helper_sources'],
                                              timing=timing, synthetic=synthetic, role=role,
                                              allocation_start_ns=allocated_ns)
        authority.merge(pins, new_pins)
        receipts[role] = descriptor
        # Keep a small pointer record: embedding both full 70k-pin descriptors
        # would exceed the unchanged16MiB file limit. Their exact expectations
        # remain independently constructed in memory and all raw files persist.
        attempts.append({'role': role, 'result': descriptor['result'], 'seconds': result['seconds'],
                         'reserved_seconds': cap, 'exit': result['exit'], 'stop': result['stop']})
        validation_deadline = min(deadline, result['bounds']['post_deadline_ns'])
        common.authenticate(pins, validation_deadline)
        actual_spec, result, log, inputs = negative_collector.receipt(
            contract, pins, runtime, role, validation_deadline)
        if role == 'fresh_census':
            require(result['exit'] == 0 and collector.partition.census(log) == profile['properties'],
                    'fresh full census differs')
        elif role == 'tail':
            negative_collector.tail_evidence(contract, pins, validation_deadline)
        else:
            proof = collector.collect(contract, pins, validation_deadline)
        validation_path = slot / (role + '-validation.json')
        common.write(validation_path, {'role': role, 'context': binding,
                     'result_sha256': pins[descriptor['result']], 'finished_ns': time.monotonic_ns(),
                     'proof_credit': False}, validation_deadline)
        authority.merge(pins, {str(validation_path): common.sha(validation_path, validation_deadline)})
        common.check(validation_deadline)
    require(owner.empty(), 'controller child remains after collection')
    common.source_closure(case['helper_sources'], deadline)
    common.check(deadline)
    return proof, attempts, pins


def execute_loaded(case, legacy, profile, prior, pins, runtime, binding, owner, synthetic=False):
    slot = Path(runtime['slot'])
    deadline = runtime['deadlines']['work']
    proof, attempts, stop = None, [], None
    controller_id = {k: owner.owner[k] for k in ['pid', 'start_ticks']}
    common.write(slot / 'controller-ready.json', {'controller': controller_id, 'context': binding}, deadline)
    try:
        proof, attempts, pins = run_case(case, legacy, profile, prior, pins, runtime,
                                         binding, owner, synthetic=synthetic)
    except BaseException as error:
        stop = repr(error)
        proof = None
    # Even entry/preflight exceptions may leave a registered du/git subprocess.
    # No terminal is permitted until local ownership is exhausted.
    cleaned = owner.cleanup(deadline / NANO, grace=.25)
    require(cleaned and owner.empty(), 'controller cleanup incomplete; outer takeover required')
    finished = time.monotonic_ns()
    require(finished < deadline, 'controller work deadline exceeded')
    pins_path = slot / 'validated-pins.json'
    common.write(pins_path, pins, deadline)
    pins_binding = {'path': str(pins_path), 'sha256': common.sha(pins_path, deadline)}
    finished = time.monotonic_ns()
    terminal = {'context': binding, 'controller': controller_id, 'stop': stop,
                'proof': proof, 'attempts': attempts, 'zero_descendants': True,
                'finished_ns': finished,
                'validated_pins': pins_binding,
                'declared_seconds': math.ceil((finished - runtime['start_ns']) / NANO) + 2,
                'ownership_events': owner.events, 'proof_credit': False}
    terminal_path = slot / 'controller-terminal.json'
    common.write(terminal_path, terminal, deadline)
    common.write(slot / 'controller-completion.json',
                 {'context': binding, 'terminal_sha256': common.sha(terminal_path, deadline),
                  'finished_ns': time.monotonic_ns(), 'complete': True, 'proof_credit': False}, deadline)
    common.check(deadline)
    return 0 if proof is not None and stop is None else 1


def main(args, entry_ns):
    if args and args[0] == 'synthetic':
        from synthetic_support import controller_main
        return controller_main(args[1:], entry_ns)
    require(len(args) == 6, 'controller requires context, launch and selection bindings')
    binding, launch_ref, selection_ref = ({'path': args[i], 'sha256': args[i + 1]}
                                         for i in [0, 2, 4])
    runtime = context.load(binding, entry_ns + 180 * NANO, live=True)
    deadline = runtime['deadlines']['work']
    ready = common.read(Path(runtime['slot']) / 'watchdog-ready.json', deadline)
    require(ready['context'] == binding, 'changed watchdog context')
    parent_is(ready['watchdog'])
    owner = OwnedTree()
    try:
        launch_spec = authority.launch(launch_ref, deadline)
        require(runtime['launch_spec_sha256'] == launch_ref['sha256']
                and runtime['selection_sha256'] == selection_ref['sha256']
                and runtime['case_sha256'] == launch_spec['case']['sha256'],
                'changed controller static bindings')
        case, legacy, profile, prior, pins = authority.load_case(launch_spec['case'], deadline)
        authority.selected(selection_ref, launch_ref, launch_spec, case, pins, owner, deadline)
        result = execute_loaded(case, legacy, profile, prior, pins, runtime, binding, owner)
        return result
    finally:
        # If authentication failed before execute_loaded, cleanup still runs.
        # Watchdog takes over if this process dies or cannot finish it on time.
        owner.cleanup(deadline / NANO, grace=.25)
        owner.close()
