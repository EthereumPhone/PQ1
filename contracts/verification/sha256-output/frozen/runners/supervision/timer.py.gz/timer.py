"""Bounded ACK timer with a first-fresh-tail dynamic capture for the negative.

The enclosing subreaper runner owns all command descendants, including adopted
grandchildren when this timer exits. Its cleanup must precede post-validation.
"""
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time

import budget
import context
from budget import NANO, require
from common import bound_json, check, sha, write
from group_gate import GroupGate
from process_ownership import OwnedTree


def emit(data):
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def admit(spec, runtime, now_ns):
    """Pure admission used by both actual entry and deterministic clock controls."""
    require(spec['schema'] == 'bounded-phased-v1' and spec['side'] == 'candidate'
            and spec['group_count'] == 22 and spec['group_seconds'] == budget.GROUP_SECONDS
            and spec['first_group_seconds'] == budget.FIRST_GROUP_SECONDS
            and len(spec['commands']) == 1, 'changed original timing profile')
    whole, started = spec['whole_seconds'], spec['runner_start_ns']
    require(type(whole) is int and 0 < whole <= budget.TAIL_MAX,
            'unsupported continuation allocation')
    require(budget.integer(started) and runtime['start_ns'] <= started <= now_ns,
            'invalid shared timer origin')
    bounds = context.runner_bounds(runtime, started, whole, True)
    require(spec['bounds'] == bounds and now_ns < bounds['poll_deadline_ns'],
            'changed or exhausted effective tail deadline')
    require(spec['outer_monotonic_start'] == started / NANO,
            'inconsistent shared timer clock')
    return bounds


def child(command, spec, records, gate):
    started = spec['runner_start_ns']
    deadline = spec['bounds']['effective_solver_deadline_ns']
    # Timer starts local refusal early enough for its direct-child stop. The
    # controller still enforces the earlier polling stop and cleans descendants.
    stop_at = spec['bounds']['poll_deadline_ns']
    owner = OwnedTree(subreaper=False)
    record = {'command': command, 'complete': False, 'group_seconds': [],
              'acknowledgements': []}
    records.append(record)
    proc, selector = None, None
    durations, deadline_bounds = [], [started]
    previous = group_lower = last_empty = started
    pending, stop = b'', None

    def limits(now):
        require(now < stop_at, 'effective tail stop lead reached')
        require(now < budget.group_deadline(group_lower, min(len(durations), 21), stop_at),
                'per-group active time cap')

    try:
        limits(time.monotonic_ns())
        proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, cwd=spec['solver_cwd'],
                                env=spec['solver_environment'])
        owner.register(proc)
        selector = selectors.DefaultSelector()
        selector.register(proc.stdout, selectors.EVENT_READ)
        os.set_blocking(proc.stdout.fileno(), False)
        os.set_blocking(proc.stdin.fileno(), False)
        eof, total_bytes = False, 0
        while not eof:
            limits(time.monotonic_ns())
            for _, _mask in selector.select(timeout=0.01):
                while True:
                    before_read = time.monotonic_ns()
                    limits(before_read)
                    try:
                        data = os.read(proc.stdout.fileno(), 65536)
                    except BlockingIOError:
                        last_empty = before_read
                        break
                    if not data:
                        eof = True
                        break
                    total_bytes += len(data)
                    require(total_bytes <= 16 * 1024**2, 'raw gate output bound')
                    emit(data)
                    pending += data
                    while b'\n' in pending:
                        line, pending = pending.split(b'\n', 1)
                        boundary = gate.line((line + b'\n').decode('utf-8'))
                        if boundary is None:
                            continue
                        require(not pending, 'buffered output before acknowledgement')
                        try:
                            premature = os.read(proc.stdout.fileno(), 65536)
                        except BlockingIOError:
                            premature = None
                        if premature:
                            emit(premature)
                        require(premature is None, 'backend advanced/exited before ACK')
                        if not durations and gate.capture_dynamic:
                            # Freeze the successful first group's exact set,
                            # metadata and statuses before granting another ACK.
                            path = Path(spec['dynamic_capture'])
                            require(gate.dynamic_capture is not None,
                                    'first group lacks dynamic capture')
                            write(path, gate.dynamic_capture, stop_at)
                            digest = sha(path, stop_at)
                            require(digest == gate.dynamic_capture_sha256,
                                    'dynamic capture bytes differ from the validated group')
                            record['dynamic_capture'] = {'path': str(path), 'sha256': digest}
                            record['dynamic_capture_written_ns'] = time.monotonic_ns()
                        validated = time.monotonic_ns()
                        limits(validated)
                        if not durations:
                            record['screen'] = budget.screen(
                                (validated - started) / NANO, gate.symex_seconds,
                                deadline, validated)
                            require(record['screen']['passes'], 'first-group cost screen refused')
                        before_send = time.monotonic_ns()
                        limits(before_send)
                        if not durations:
                            require(record['screen']['required_later_seconds'] <=
                                    (deadline - before_send) // NANO,
                                    'first-group screen consumed before ACK')
                        ack = f'PQ1-SCOPED-ACK {boundary["group"]}\n'
                        require(os.write(proc.stdin.fileno(), ack.encode('ascii')) == len(ack),
                                'incomplete acknowledgement write')
                        final = boundary['group'] + 1 == 22
                        if final:
                            proc.stdin.close()
                        sent = time.monotonic_ns()
                        record['acknowledgements'].append(dict(
                            boundary, ack=ack, validated_at=validated / NANO,
                            sent_at=sent / NANO, validated_ns=validated,
                            sent_ns=sent, stdin_closed=final))
                        limits(sent)
                        if not durations:
                            require(record['screen']['required_later_seconds'] <=
                                    (deadline - sent) // NANO,
                                    'first-group screen consumed during ACK')
                        durations.append((sent - previous) / NANO)
                        previous = sent
                        gate.acknowledge(boundary['group'])
                        if not final:
                            group_lower = last_empty
                            deadline_bounds.append(group_lower)
        require(not pending, 'unterminated final output')
        now = time.monotonic_ns()
        limits(now)
        remaining = (budget.group_deadline(group_lower, 21, stop_at) - now) / NANO
        code = proc.wait(timeout=remaining)
        finished = time.monotonic_ns()
        limits(finished)
        gate.finish(code)
        require(len(durations) == 22, 'missing group timing boundary')
        durations[-1] += (finished - previous) / NANO
        require(all(duration < budget.group_limit(i) for i, duration in enumerate(durations)), 'late group teardown')
        record.update({'exit': code, 'group_seconds': durations,
                       'seconds': (finished - started) / NANO, 'complete': True,
                       'finished_ns': finished,
                       'deadline_start_lower_bounds': [n / NANO for n in deadline_bounds],
                       'deadline_start_lower_bounds_ns': deadline_bounds})
        return record
    except BaseException as error:
        stop = repr(error)
        raise
    finally:
        if selector is not None:
            selector.close()
        if proc is not None:
            if not proc.stdin.closed:
                proc.stdin.close()
            if proc.poll() is None:
                owner.send_child(proc, signal.SIGTERM)
                term_end = min(time.monotonic_ns() + NANO // 2, deadline - NANO // 2)
                while proc.poll() is None and time.monotonic_ns() < term_end:
                    time.sleep(.005)
                if proc.poll() is None:
                    owner.send_child(proc, signal.SIGKILL)
                while proc.poll() is None and time.monotonic_ns() < deadline:
                    time.sleep(.005)
            proc.stdout.close()
        if stop:
            record.update({'exit': None if proc is None else proc.returncode, 'stop': stop,
                           'group_seconds': durations, 'seconds': (time.monotonic_ns() - started) / NANO,
                           'deadline_start_lower_bounds': [n / NANO for n in deadline_bounds],
                           'deadline_start_lower_bounds_ns': deadline_bounds})
            emit(('PQ1-TIMING-REFUSED: ' + stop + '\n').encode())
        owner.close()


def main(args, entry_ns):
    require(len(args) == 3, 'timer requires spec, digest and receipt')
    spec_path, digest, receipt_path = args
    # Startup is already under independent observer supervision. The input is
    # authenticated before any child; its bound context then shortens this cap.
    spec = bound_json(spec_path, digest, entry_ns + 180 * NANO)
    synthetic = spec.get('synthetic_test_only') is True
    runtime = context.load(spec['context'], entry_ns + 180 * NANO,
                           live=True, synthetic=synthetic)
    bounds = admit(spec, runtime, time.monotonic_ns())
    started = spec['runner_start_ns']
    records, code, stop = [], 125, None
    try:
        gate = GroupGate(bound_json(spec['gate_contract'], spec['gate_contract_sha256'],
                                   bounds['poll_deadline_ns']))
        require(len(gate.groups) == 22, 'changed group count')
        if gate.capture_dynamic:
            require(spec.get('dynamic_capture') == str(Path(runtime['slot']) / 'tail/first-tail-dynamic.json')
                    and Path(receipt_path) == Path(runtime['slot']) / 'tail/timing.json',
                    'dynamic capture outside exact tail output')
        else:
            require('dynamic_capture' not in spec, 'capture supplied to historical-dynamic gate')
        record = child(spec['commands'][0], spec, records, gate)
        code = record['exit']
    except BaseException as error:
        stop = repr(error)
    ended = time.monotonic_ns()
    if ended >= bounds['effective_solver_deadline_ns']:
        stop, code = stop or 'whole continuation active time cap', 125
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    receipt = {'schema': 'bounded-phased-v1', 'side': 'candidate',
               'context': spec['context'], 'bounds': bounds, 'runner_start_ns': started,
               'commands': spec['commands'], 'records': records, 'exit': code,
               'stop': stop, 'seconds': (ended - started) / NANO, 'timer_end_ns': ended,
               'group_seconds': [t for record in records for t in record['group_seconds']],
               'group_count': 22, 'per_group_limit': budget.GROUP_SECONDS,
               'first_group_limit': budget.FIRST_GROUP_SECONDS,
               'whole_limit': spec['whole_seconds'], 'outer_monotonic_start': started / NANO,
               'kernel_cpu_limit': list(resource.getrlimit(resource.RLIMIT_CPU)),
               'kernel_address_space_limit': list(resource.getrlimit(resource.RLIMIT_AS)),
               'user_seconds': usage.ru_utime, 'system_seconds': usage.ru_stime,
               'max_rss_kib': usage.ru_maxrss, 'setup_included': True, 'proof_credit': False}
    write(receipt_path, receipt, runtime['deadlines']['work'])
    return code
