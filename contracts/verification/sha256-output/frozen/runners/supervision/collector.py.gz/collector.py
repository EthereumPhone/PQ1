"""Authenticate frozen commands and raw receipts before semantic composition.

The caller freezes expected descriptors independently of the returned receipts.
Rehashing a changed receipt cannot redefine the expected command or manifest.
"""
from pathlib import Path
import math

from collect_continuation import partition, parse_partial, compose_reports
from group_gate import GroupGate, continuation_screen, negative_contract
import budget
import context
import common
import timer
from budget import NANO

require = partition.require


def read(path, deadline_ns):
    return common.read(path, deadline_ns)


def authenticate(pins, deadline_ns):
    common.authenticate(pins, deadline_ns)


def raw(path, deadline_ns):
    common.check(deadline_ns)
    with Path(path).open('rb') as stream:
        data = stream.read(common.FILE_BYTES + 1)
    common.check(deadline_ns)
    require(len(data) <= common.FILE_BYTES, 'oversized raw receipt')
    return data.decode('utf-8')


def finite_seconds(value):
    return (type(value) in {int, float} and math.isfinite(value) and value >= 0)


def phase_receipt(descriptor, spec, result, effective, pins, deadline_ns):
    """Additional new-run binding; legacy census keeps its full elapsed rule."""
    binding = descriptor['context']
    require(pins.get(binding['path']) == binding['sha256']
            and spec['pins'].get(binding['path']) == binding['sha256']
            and spec['context'] == result['context'] == effective['context'] == binding,
            'unbound or changed runner context')
    synthetic = descriptor.get('synthetic_test_only') is True
    runtime = context.load(binding, deadline_ns, synthetic=synthetic)
    started, solver_end, post_end = (result['runner_start_ns'],
                                    result['solver_phase_end_ns'], result['post_solver_end_ns'])
    require(all(budget.integer(t) for t in [started, solver_end, post_end])
            and runtime['start_ns'] <= started <= solver_end <= post_end,
            'reversed or invalid phase timestamps')
    tail = descriptor['schema'] == 'bounded-phased-v1'
    bounds = context.runner_bounds(runtime, started, spec['seconds'], tail,
                                   root=descriptor['schema'] == 'bounded-root-v1')
    require(result['bounds'] == spec['bounds'] == effective['bounds'] == bounds
            and spec['runner_start_ns'] == effective['runner_start_ns'] == started
            and result['monotonic_start'] == started / NANO,
            'changed phase origins/deadlines')
    require(solver_end < bounds['effective_solver_deadline_ns']
            and post_end < bounds['post_deadline_ns']
            and post_end - solver_end < 180 * NANO,
            'late solver or post-validation phase')
    require(finite_seconds(result['solver_seconds'])
            and result['solver_seconds'] == (solver_end - started) / NANO
            and result['seconds'] == (post_end - started) / NANO
            and result['solver_seconds'] < spec['seconds']
            and result['local_cleanup_complete'] is True,
            'incomplete or inconsistent runner phase durations')
    require(effective['storage_policy'] == descriptor['expected_storage_policy']
            and effective['execution_environment'] == descriptor['expected_execution_environment'],
            'changed actual storage/environment binding')
    common.storage_policy(effective['storage_policy'], synthetic)
    require(descriptor['resources'] == effective['storage_policy']['limits'],
            'unbound descriptor storage limits')
    expected_environment = common.HELPER_ENV if tail else spec['environment']
    require(effective['execution_environment'] == expected_environment,
            'helper/solver environment mixed')
    for total, batch, free in [effective['initial_storage'], result['terminal_storage']]:
        limits = descriptor['resources']
        require(all(type(n) is int and n >= 0 for n in [total, batch, free]),
                'invalid storage measurement')
        outstanding = max(0, limits['batch'] - batch)
        require(total + outstanding < limits['aggregate'] - limits['reserve']
                and batch < limits['batch']
                and free > limits['floor'] + limits['reserve'] + outstanding,
                'outstanding campaign storage unreserved')
    return runtime


def expected_commands(profile):
    """Construct exact commands from the independently frozen original case."""
    base = profile['base_command']
    program, candidate, manifest = (
        profile['program'], profile['candidate'], profile['manifest'])
    require(isinstance(base, list) and base and
            all(isinstance(arg, str) for arg in base), 'invalid original base')
    require(base.count('--sat-solver') == 1, 'ambiguous original backend')
    require('--property' not in base and '--pq1-scoped-partitions' not in base and
            '--pq1-scoped-partial' not in base and
            '--pq1-scoped-group-ack' not in base, 'selection in original base')
    backend = base.index('--sat-solver') + 1
    require(backend < len(base), 'missing original backend')
    require(base[backend] == profile['prior_backend'], 'wrong prior backend')
    require(base[backend] in {'cadical', 'minisat2'}, 'unselected prior backend')
    negative = profile['kind'] == context.KIND
    if profile['kind'] in {'original-full', 'original-full-prefix', context.KIND}:
        require(base[backend] == ('minisat2' if negative else 'cadical') and '--flush' not in base,
                'wrong original full backend/output profile')
        require(base.count('--unwind') == 1 and
                base[base.index('--unwind') + 1] == '193' and
                base.count('--unwinding-assertions') == 1,
                'wrong original full unwinding profile')
        census_suffix = ['--show-properties', '--json-ui', program]
    else:
        require(profile['kind'] == 'finite', 'unknown case profile')
        # Preserve the actual fixture's recorded argv order, rather than
        # rewriting old finite evidence to look like the full-caller command.
        require(profile['census_layout'] in {'before-program', 'after-program'},
                'unselected finite census layout')
        census_suffix = (['--show-properties', '--json-ui', program]
                         if profile['census_layout'] == 'before-program'
                         else [program, '--show-properties', '--json-ui'])
    require(base.count('--flush') <= 1, 'repeated original flush')
    fresh = list(base)
    fresh[0], fresh[backend] = candidate, 'minisat2'
    tail = list(fresh)
    if '--flush' not in tail:
        tail.append('--flush')
    tail.extend(['--pq1-scoped-partitions', manifest, '--pq1-scoped-partial'])
    if profile['kind'] == 'original-full-prefix' or negative:
        tail.append('--pq1-scoped-group-ack')
    tail.append(program)
    root_selection = [arg for name in profile['parts'][0]
                      for arg in ['--property', name]]
    if negative:
        require(base[0] == candidate, 'negative cannot import an old backend')
        return {'fresh_census': fresh + census_suffix, 'tail': tail,
                'root': fresh + root_selection + [program]}
    return {
        'prior': base + root_selection + [program],
        'prior_census': base + census_suffix,
        'fresh_census': fresh + census_suffix,
        'tail': tail,
    }


def validate_command(profile, role, actual):
    """Exact role-specific comparison; no normalization or omitted option checks."""
    commands = expected_commands(profile)
    require(role in commands, 'unknown semantic command role')
    require(actual == commands[role], 'changed semantic command: ' + role)


def validate_selection(profile, actual):
    """Preserve the independently selected whole partition and execution order."""
    properties, parts, order = profile['properties'], profile['parts'], profile['order']
    partition.validate_partition(properties, parts, profile['required'])
    require(order and order[0] == 0 and len(order) == len(parts) and
            set(order) == set(range(len(parts))), 'invalid frozen order')
    groups = [parts[index] for index in order[1:]]
    require(actual == groups, 'changed selection membership/order')
    return groups


def read_receipt(descriptor, pins, deadline_ns):
    """Reject missing/crashed/late receipts and bind their actual launch inputs."""
    for key in ['spec', 'result', 'log']:
        require(descriptor[key] in pins, 'unbound receipt ' + key)
    spec, result = read(descriptor['spec'], deadline_ns), read(descriptor['result'], deadline_ns)
    require(spec == descriptor['expected_spec'], 'changed expected invocation')
    require(result['spec_sha256'] == pins[descriptor['spec']], 'spec receipt mismatch')
    require(result['log_sha256'] == pins[descriptor['log']], 'log receipt mismatch')
    require(result['stop'] is None, 'resource or monitor refusal')
    require(type(result['exit']) is int and result['exit'] in {0, 10},
            'non-verification result exit')
    inputs = dict(spec['pins'])
    for filename, digest in spec.get('pin_manifests', {}).items():
        require(pins.get(filename) == digest, 'unbound input pin manifest')
        for name, value in read(filename, deadline_ns).items():
            require(name not in inputs or inputs[name] == value, 'conflicting input pin')
            inputs[name] = value
    require(inputs and all(pins.get(name) == value for name, value in inputs.items()),
            'missing or changed transitive input binding')
    if descriptor['schema'] == 'original':
        limit = spec['active_seconds_limit']
        require(result['all_pins_unchanged'] is True, 'changed original inputs')
        require(result['owned_live_members_after_cleanup'] == [], 'live original child')
        require(result.get('oversize_files', []) == [], 'original oversized output')
        require(result['final_bytes'] < spec['aggregate_cap_bytes'],
                'original terminal storage limit')
        require(result['peak_bytes'] < spec['aggregate_cap_bytes'],
                'original peak storage limit')
    else:
        require(descriptor['schema'] in {'bounded', 'bounded-phased-v1', 'bounded-root-v1'},
                'unknown receipt schema')
        limit = spec['seconds']
        require(result['pins_unchanged'] is True, 'changed fresh inputs')
        require(result['live_members_after_cleanup'] == [], 'live fresh child')
        total, batch, free = result['terminal_storage']
        resources = descriptor['resources']
        require(0 <= total < resources['aggregate'] - resources['reserve'] and
                0 <= batch < resources['batch'] and
                free > resources['floor'] + resources['reserve'],
                'fresh terminal storage limit')
        effective_path = descriptor['effective']
        require(effective_path in pins, 'unbound effective invocation')
        effective = read(effective_path, deadline_ns)
        require(effective['spec_sha256'] == pins[descriptor['spec']] and
                effective['command'] == descriptor['expected_effective_command'],
                'changed kernel-limit wrapper or command')
        require(all(pins.get(name) == value for name, value in effective['pins'].items()),
                'unbound effective dependency')
        require(all(effective['pins'].get(name) == value for name, value in inputs.items()),
                'effective invocation omitted input pins')
    require(finite_seconds(limit) and limit > 0 and finite_seconds(result['seconds']),
            'invalid elapsed time or cap')
    if descriptor['schema'] == 'bounded-phased-v1':
        require('context' in descriptor, 'new tail cannot fall back to legacy receipt')
        phase_receipt(descriptor, spec, result, effective, pins, deadline_ns)
    else:
        require(result['seconds'] < limit, 'outer elapsed cap exceeded')
        if 'context' in descriptor:
            require((descriptor['schema'] == 'bounded' and limit == 180)
                    or (descriptor['schema'] == 'bounded-root-v1' and type(limit) is int
                        and 0 < limit <= 600), 'changed census/root receipt limit')
            phase_receipt(descriptor, spec, result, effective, pins, deadline_ns)
    return spec, result, raw(descriptor['log'], deadline_ns), inputs


def check_timing(contract, pins, groups, tail_spec, tail_result, tail_inputs, deadline_ns):
    spec_path, result_path = contract['timing_spec'], contract['timing_receipt']
    require(spec_path in pins and result_path in pins, 'unbound timing evidence')
    require(tail_inputs.get(spec_path) == pins[spec_path], 'child spec absent from launch pins')
    spec, result = read(spec_path, deadline_ns), read(result_path, deadline_ns)
    count, limit, whole = len(groups), contract['per_group_seconds'], tail_spec['seconds']
    phased = contract.get('continuation_schema') == 'bounded-phased-v1'
    if phased:
        require(contract['receipts']['tail']['schema'] == 'bounded-phased-v1'
                and spec['schema'] == result['schema'] == 'bounded-phased-v1'
                and count == 22 and limit == budget.GROUP_SECONDS
                and contract['first_group_seconds'] == spec['first_group_seconds']
                == result['first_group_limit'] == budget.FIRST_GROUP_SECONDS,
                'changed new tail schema/profile')
        require(spec['context'] == result['context'] == tail_spec['context']
                == tail_result['context'] == contract['context'], 'changed timer context')
        binding = contract['context']
        require(pins.get(binding['path']) == binding['sha256'], 'unbound timer context')
        runtime = context.load(binding, deadline_ns,
                               synthetic=contract.get('synthetic_test_only') is True)
        bounds = timer.admit(spec, runtime, spec['runner_start_ns'])
        require(result['bounds'] == tail_result['bounds'] == tail_spec['bounds'] == bounds
                and spec['runner_start_ns'] == result['runner_start_ns']
                == tail_spec['runner_start_ns'] == tail_result['runner_start_ns']
                and spec['outer_monotonic_start'] == result['outer_monotonic_start']
                == tail_result['monotonic_start'], 'inconsistent timer clocks')
        require(budget.integer(result['timer_end_ns'])
                and result['timer_end_ns'] <= tail_result['solver_phase_end_ns']
                and result['seconds'] == (result['timer_end_ns'] - spec['runner_start_ns']) / NANO
                and result['seconds'] <= tail_result['solver_seconds'] <= tail_result['seconds'],
                'timer outside solver phase')
        require(result['kernel_cpu_limit'] == [whole, whole]
                and result['kernel_address_space_limit'] == [tail_spec['address_space']] * 2,
                'changed timer kernel limits')
    else:
        require('schema' not in spec and 'schema' not in result
                and contract['receipts']['tail']['schema'] != 'bounded-phased-v1',
                'new tail cannot use legacy timing policy')
    require(spec['side'] == 'candidate' and spec['group_count'] == count and
            spec['group_seconds'] == limit and spec['whole_seconds'] == whole,
            'changed timing limits or group count')
    require(result['commands'] == spec['commands'] and result['side'] == 'candidate' and
            result['group_count'] == count and result['per_group_limit'] == limit and
            result['whole_limit'] == whole and result['setup_included'] is True,
            'timing receipt configuration mismatch')
    require(result['stop'] is None and result['exit'] == tail_result['exit'],
            'timing refusal or exit mismatch')
    require(finite_seconds(result['seconds']) and result['seconds'] < whole and
            result['seconds'] <= tail_result['seconds'], 'invalid whole timing')
    records = result['records']
    require(len(records) == 1 and records[0]['complete'] is True and
            records[0].get('stop') is None and records[0]['exit'] == result['exit'] and
            records[0]['command'] == spec['commands'][0], 'incomplete child timing')
    if phased:
        require(budget.integer(records[0]['finished_ns'])
                and records[0]['finished_ns'] < bounds['poll_deadline_ns']
                and records[0]['finished_ns'] <= result['timer_end_ns']
                and records[0]['seconds'] ==
                (records[0]['finished_ns'] - spec['runner_start_ns']) / NANO,
                'inconsistent child completion timing')
    durations = result['group_seconds']
    require(len(durations) == count and durations == records[0]['group_seconds'] and
            all(finite_seconds(value) and value < (budget.group_limit(i) if phased else limit)
                for i, value in enumerate(durations)),
            'invalid or late group timing')
    # Includes outer Python/prlimit startup and owned-group cleanup. Charging all
    # of that overhead to group zero is conservative, including final overhead.
    overhead = tail_result['seconds'] - result['seconds']
    require(durations[0] + overhead < (budget.FIRST_GROUP_SECONDS if phased else limit),
            'first group plus outer overhead exceeded cap')


def check_acknowledgements(contract, pins, groups, prior, raw_tail, tail_result,
                          tail_inputs, deadline_ns):
    """Reparse every group and bind the live gate to its clocks and transcript."""
    if contract.get('continuation_schema') == 'bounded-phased-v1':
        return check_new_acknowledgements(contract, pins, groups, prior, raw_tail,
                                          tail_result, tail_inputs, deadline_ns)
    spec = read(contract['timing_spec'], deadline_ns)
    timing = read(contract['timing_receipt'], deadline_ns)
    gate_path, entry_path = contract['gate_contract'], contract['entry_reservation']
    require(gate_path in pins and entry_path in pins, 'unbound gate or entry reservation')
    require(tail_inputs.get(gate_path) == pins[gate_path] and
            tail_inputs.get(entry_path) == pins[entry_path],
            'gate or entry absent from actual launch inputs')
    require(spec['gate_contract'] == gate_path and
            spec['gate_contract_sha256'] == pins[gate_path] and
            spec['entry_reservation'] == entry_path and
            spec['entry_reservation_sha256'] == pins[entry_path],
            'changed gate or entry binding')
    profile = contract['profile']
    expected_gate = (negative_contract(profile, groups) if profile.get('kind') == context.KIND else
                     {'properties': profile['properties'], 'groups': groups,
                      'required': profile['required'], 'prior_dynamic': prior['dynamic']})
    require(read(gate_path, deadline_ns) == expected_gate, 'changed independently expected gate contract')
    entry = read(entry_path, deadline_ns)
    require(entry == contract['expected_entry'] and
            entry['case_sha256'] == contract['case_sha256'] and
            entry['inherited_seconds'] == spec['inherited_seconds'] and
            entry['total_limit'] == spec['case_limit'] == 4320 and
            entry['monotonic_start'] == spec['case_monotonic_start'],
            'changed execution-entry accounting')
    outer = spec['outer_monotonic_start']
    require(finite_seconds(outer) and finite_seconds(entry['monotonic_start']) and
            entry['monotonic_start'] <= outer and
            timing['outer_monotonic_start'] == outer == tail_result['monotonic_start'],
            'unbound gate clock')
    require(len(groups) == 22, 'wrong original gate group count')
    record = timing['records'][0]
    acks, bounds = record['acknowledgements'], record['deadline_start_lower_bounds']
    require(isinstance(acks, list) and len(acks) == len(groups) == len(bounds),
            'missing or extra acknowledgement records')
    gate = GroupGate(expected_gate)
    last_sent, consumed = outer, 0
    for line in raw_tail.splitlines(keepends=True):
        boundary = gate.line(line)
        if boundary is None:
            continue
        index = boundary['group']
        ack = acks[index]
        require(set(ack) == set(boundary) | {'ack', 'validated_at', 'sent_at', 'stdin_closed'},
                'unknown or missing acknowledgement field')
        require(all(ack[k] == value for k, value in boundary.items()) and
                ack['ack'] == f'PQ1-SCOPED-ACK {index}\n' and
                ack['stdin_closed'] is (index + 1 == len(groups)),
                'changed acknowledgement bytes or raw group binding')
        validated, sent, lower = ack['validated_at'], ack['sent_at'], bounds[index]
        require(all(finite_seconds(t) for t in [validated, sent, lower]) and
                outer <= lower <= last_sent <= validated <= sent and
                (index != 0 or lower == outer) and
                sent - lower < contract['per_group_seconds'],
                'late or inconsistent acknowledgement clock')
        duration = record['group_seconds'][index]
        if index + 1 < len(groups):
            require(abs(duration - (sent - last_sent)) < 1e-6,
                    'group duration omits validation or acknowledgement')
        else:
            require(duration >= sent - last_sent and
                    outer + record['seconds'] - lower < contract['per_group_seconds'],
                    'final group omits acknowledgement or teardown')
        if index == 0:
            expected_screen = continuation_screen(
                validated - outer, gate.symex_seconds,
                validated - entry['monotonic_start'], entry['inherited_seconds'])
            require(record['screen'] == expected_screen and expected_screen['passes'] is True and
                    expected_screen['required_later_seconds'] <=
                    4320 - entry['inherited_seconds'] - (sent - entry['monotonic_start']),
                    'missing, changed or failed first-group cost screen')
        last_sent, consumed = sent, consumed + 1
        gate.acknowledge(index)
    gate.finish(tail_result['exit'])
    require(consumed == len(groups) and
            abs(sum(record['group_seconds']) - record['seconds']) < 1e-6,
            'incomplete gate transcript or omitted timing interval')


def check_new_acknowledgements(contract, pins, groups, prior, raw_tail,
                               tail_result, tail_inputs, deadline_ns):
    spec = read(contract['timing_spec'], deadline_ns)
    timing = read(contract['timing_receipt'], deadline_ns)
    gate_path, binding = contract['gate_contract'], contract['context']
    require(len(groups) == 22 and spec['schema'] == timing['schema'] == 'bounded-phased-v1'
            and contract['receipts']['tail']['schema'] == 'bounded-phased-v1',
            'wrong new acknowledgement profile')
    require(gate_path in pins and pins.get(binding['path']) == binding['sha256']
            and tail_inputs.get(gate_path) == pins[gate_path]
            and tail_inputs.get(binding['path']) == binding['sha256'],
            'gate or context absent from launch pins')
    require(spec['gate_contract'] == gate_path
            and spec['gate_contract_sha256'] == pins[gate_path]
            and spec['context'] == timing['context'] == tail_result['context'] == binding,
            'changed gate/context binding')
    runtime = context.load(binding, deadline_ns,
                           synthetic=contract.get('synthetic_test_only') is True)
    require(runtime['case_sha256'] == contract['case_sha256'], 'context belongs to another case')
    profile = contract['profile']
    negative = profile.get('kind') == context.KIND
    expected_gate = (negative_contract(profile, groups) if negative else
                     {'properties': profile['properties'], 'groups': groups,
                      'required': profile['required'], 'prior_dynamic': prior['dynamic']})
    require(read(gate_path, deadline_ns) == expected_gate, 'changed expected gate contract')
    start_ns = spec['runner_start_ns']
    bounds = timer.admit(spec, runtime, start_ns)
    require(start_ns == timing['runner_start_ns'] == tail_result['runner_start_ns']
            and spec['outer_monotonic_start'] == timing['outer_monotonic_start']
            == tail_result['monotonic_start'] == start_ns / NANO
            and bounds == timing['bounds'] == tail_result['bounds'], 'unbound gate clock')
    effective = bounds['effective_solver_deadline_ns']
    record = timing['records'][0]
    acks = record['acknowledgements']
    lower_bounds = record['deadline_start_lower_bounds_ns']
    require(len(acks) == len(groups) == len(lower_bounds)
            and record['deadline_start_lower_bounds'] == [n / NANO for n in lower_bounds],
            'missing or changed acknowledgement bounds')
    gate = GroupGate(expected_gate)
    last_sent, consumed = start_ns, 0
    for line in raw_tail.splitlines(keepends=True):
        common.check(deadline_ns)
        boundary = gate.line(line)
        if boundary is None:
            continue
        index = boundary['group']
        ack = acks[index]
        require(set(ack) == set(boundary) | {'ack', 'validated_at', 'sent_at',
                                            'validated_ns', 'sent_ns', 'stdin_closed'},
                'unknown or missing new acknowledgement field')
        require(all(ack[k] == value for k, value in boundary.items())
                and ack['ack'] == f'PQ1-SCOPED-ACK {index}\n'
                and ack['stdin_closed'] is (index + 1 == len(groups)),
                'changed acknowledgement or transcript binding')
        validated, sent, lower = ack['validated_ns'], ack['sent_ns'], lower_bounds[index]
        require(all(budget.integer(t) for t in [validated, sent, lower])
                and start_ns <= lower <= last_sent <= validated <= sent < bounds['poll_deadline_ns']
                and (index != 0 or lower == start_ns)
                and sent < budget.group_deadline(lower, index, bounds['poll_deadline_ns'])
                and ack['validated_at'] == validated / NANO
                and ack['sent_at'] == sent / NANO, 'late or inconsistent ACK timestamps')
        duration = record['group_seconds'][index]
        if index + 1 < len(groups):
            require(abs(duration - (sent - last_sent) / NANO) < 1e-6,
                    'group duration omits ACK/validation')
        else:
            require(duration >= (sent - last_sent) / NANO
                    and sent <= record['finished_ns'] < budget.group_deadline(lower, index, bounds['poll_deadline_ns']),
                    'final group omits ACK/teardown')
        if index == 0:
            if negative:
                captured = record['dynamic_capture']
                expected_path = str(Path(runtime['slot']) / 'tail/first-tail-dynamic.json')
                require(captured == {'path': expected_path,
                                     'sha256': gate.dynamic_capture_sha256}
                        and spec.get('dynamic_capture') == expected_path
                        and pins.get(expected_path) == captured['sha256']
                        and common.bound_json(expected_path, captured['sha256'], deadline_ns)
                        == gate.dynamic_capture
                        and budget.integer(record['dynamic_capture_written_ns'])
                        and start_ns <= record['dynamic_capture_written_ns'] <= validated,
                        'dynamic set was not frozen from the successful first group before ACK')
            expected = budget.screen((validated - start_ns) / NANO,
                                     gate.symex_seconds, effective, validated)
            require(record['screen'] == expected and expected['passes'] is True
                    and expected['required_later_seconds'] <= (effective - sent) // NANO,
                    'missing, changed or failed first-group screen')
        last_sent, consumed = sent, consumed + 1
        gate.acknowledge(index)
    gate.finish(tail_result['exit'])
    require(consumed == len(groups)
            and abs(sum(record['group_seconds']) - record['seconds']) < 1e-6,
            'incomplete transcript or omitted timing interval')
    common.check(deadline_ns)
    return gate.dynamic_capture if negative else None


def collect(contract, pins, deadline_ns):
    """Accept a whole proof only through authenticated prior+census+tail evidence."""
    if contract['profile']['kind'] == context.KIND:
        from negative_collector import collect_negative
        return collect_negative(contract, pins, deadline_ns)
    authenticate(pins, deadline_ns)
    if contract.get('continuation_schema') == 'bounded-phased-v1':
        require(contract['receipts']['tail']['schema'] == 'bounded-phased-v1'
                and contract['receipts']['fresh_census']['schema'] == 'bounded'
                and contract['receipts']['tail']['context']
                == contract['receipts']['fresh_census']['context'] == contract['context'],
                'new tail/census missing external context binding')
    profile = contract['profile']
    if profile['kind'] in {'original-full', 'original-full-prefix'}:
        require('timing_spec' in contract and contract['per_group_seconds'] == 180,
                'original continuation requires its per-group timing controller')
    expected_commands(profile)
    require(set(contract['receipts']) == {'prior', 'prior_census', 'fresh_census', 'tail'},
            'missing or extra composition receipt')
    program, manifest = profile['program'], profile['manifest']
    require(pins.get(program) == profile['program_sha256'], 'unbound prepared program')
    require(manifest in pins, 'unbound selected manifest')
    require(profile['base_command'][0] in pins and profile['candidate'] in pins,
            'unbound prior or fresh executable')
    for parser in ['pq1_promoted_census.py', 'pq1_partition.py', 'pq1_partition_anonymous.json']:
        require(str(Path(partition.__file__).parent / parser) in pins, 'unbound parser input')
    properties, parts, order = profile['properties'], profile['parts'], profile['order']
    groups = validate_selection(profile, read(manifest, deadline_ns))
    evidence = {}
    for name in ['prior', 'prior_census', 'fresh_census', 'tail']:
        evidence[name] = read_receipt(contract['receipts'][name], pins, deadline_ns)
        source_binary = (profile['base_command'][0] if name.startswith('prior')
                         else profile['candidate'])
        require(evidence[name][3].get(program) == pins[program] and
                evidence[name][3].get(source_binary) == pins[source_binary],
                'program/backend missing from invocation input pins')
        actual = evidence[name][0]['command']
        if name == 'tail' and 'timing_spec' in contract:
            timing_path = contract['timing_spec']
            require(timing_path in pins, 'unbound child-command specification')
            timing_spec = read(timing_path, deadline_ns)
            require(len(timing_spec['commands']) == 1, 'wrong tail child count')
            validate_command(profile, 'tail', timing_spec['commands'][0])
            # The outer descriptor binds the timing helper's full invocation.
            require(actual == contract['tail_outer_command'], 'wrong tail controller')
        else:
            validate_command(profile, name, actual)
    require(evidence['tail'][3].get(manifest) == pins[manifest],
            'selected manifest missing from invocation input pins')
    if 'timing_spec' in contract:
        check_timing(contract, pins, groups, evidence['tail'][0],
                     evidence['tail'][1], evidence['tail'][3], deadline_ns)
    for name in ['prior_census', 'fresh_census']:
        require(evidence[name][1]['exit'] == 0, 'failed census command')
        require(partition.census(evidence[name][2]) == properties, 'changed raw census metadata')
    prior = partition.parse_report(evidence['prior'][2], properties, parts[0],
                                   evidence['prior'][1]['exit'])
    if profile['kind'] == 'original-full-prefix':
        check_acknowledgements(contract, pins, groups, prior,
                               evidence['tail'][2], evidence['tail'][1],
                               evidence['tail'][3], deadline_ns)
    tail = parse_partial(evidence['tail'][2], properties, groups, evidence['tail'][1]['exit'])
    result = compose_reports(properties, parts, order, prior, tail, profile['required'],
                             profile['expected_failure'])
    common.check(deadline_ns)
    return result
