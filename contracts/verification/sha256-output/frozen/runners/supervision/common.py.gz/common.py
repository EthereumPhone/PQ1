"""Deadline-aware input and storage operations; no execution authorization."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

from budget import NANO, integer, require

SOURCE = Path(__file__).resolve().parent
RESEARCH = SOURCE.parents[2]
CAMPAIGN = RESEARCH / 'corrected-digest/full-negative-group-budget-v1'
HELPER_ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}
LIMITS = {'aggregate': 106 * 1024**3, 'batch': 2 * 1024**3,
          'floor': 10 * 1024**3, 'reserve': 32 * 1024**2}
FILE_BYTES = 16 * 1024**2
PRODUCTION_STORAGE = {'root': str(RESEARCH),
                      'campaign_roots': [str(SOURCE.parents[1]), str(CAMPAIGN),
                                         str(RESEARCH / 'cbmc-full-negative-preparer-v2'),
                                         str(RESEARCH / 'corrected-digest/full-negative-implementation-v1')],
                      'limits': LIMITS}


def check(deadline_ns):
    require(integer(deadline_ns) and time.monotonic_ns() < deadline_ns,
            'absolute active-time deadline exceeded')


def sha(path, deadline_ns):
    check(deadline_ns)
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            check(deadline_ns)
            chunk = stream.read(1024 * 1024)
            check(deadline_ns)
            if not chunk:
                break
            digest.update(chunk)
    check(deadline_ns)
    return digest.hexdigest()


def read(path, deadline_ns):
    check(deadline_ns)
    with Path(path).open('rb') as stream:
        data = stream.read(FILE_BYTES + 1)
    check(deadline_ns)
    require(len(data) <= FILE_BYTES, 'oversized JSON input')
    result = json.loads(data)
    check(deadline_ns)
    return result


def bound_json(path, digest, deadline_ns):
    # Parse exactly the bytes authenticated, not a second independent read.
    check(deadline_ns)
    with Path(path).open('rb') as stream:
        data = stream.read(FILE_BYTES + 1)
    check(deadline_ns)
    require(len(data) <= FILE_BYTES and hashlib.sha256(data).hexdigest() == digest,
            'changed or oversized JSON input: ' + str(path))
    result = json.loads(data)
    check(deadline_ns)
    return result


def write(path, value, deadline_ns):
    check(deadline_ns)
    data = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    require(len(data) <= FILE_BYTES, 'oversized JSON output')
    with Path(path).open('xb') as stream:
        stream.write(data)
        stream.flush()
    check(deadline_ns)


def authenticate(pins, deadline_ns):
    require(isinstance(pins, dict) and pins, 'missing input pins')
    for name, digest in pins.items():
        require(isinstance(name, str) and Path(name).is_absolute()
                and isinstance(digest, str) and len(digest) == 64,
                'invalid file pin')
        require(sha(name, deadline_ns) == digest, 'changed input: ' + name)
    check(deadline_ns)


def source_closure(expected, deadline_ns):
    require(isinstance(expected, dict) and expected, 'missing helper sources')
    actual = set()
    for path in SOURCE.iterdir():
        check(deadline_ns)
        require(path.is_file() and not path.is_symlink()
                and path.suffix in {'.py', '.json'}, 'helper bytecode/directory/symlink')
        actual.add(str(path))
    require(actual == set(expected), 'changed helper source closure')
    authenticate(expected, deadline_ns)


def helper_command(role, *args):
    require(role in {'host', 'observer', 'watchdog', 'controller', 'timer'}, 'unknown helper')
    return ['/usr/bin/python3', '-E', '-S', '-B', str(SOURCE / 'entry.py'),
            role, *map(str, args)]


def storage_policy(policy, synthetic=False):
    if not synthetic:
        require(policy == PRODUCTION_STORAGE, 'changed production storage policy')
    else:
        require(set(policy) == {'root', 'campaign_roots', 'limits', 'synthetic_test_only'}
                and policy['synthetic_test_only'] is True, 'unmarked synthetic storage')
        root = Path(policy['root'])
        require(root.is_absolute() and root.is_relative_to('/tmp')
                and root.name.startswith('pq1-budget-test-'), 'unsafe fixture storage root')
        require(policy['limits'] == LIMITS and policy['campaign_roots']
                and all(Path(p).is_relative_to(root) for p in policy['campaign_roots']),
                'changed fixture limits or external campaign roots')
    return policy


def allocated(path, deadline_ns, owner):
    check(deadline_ns)
    # The caller passes an already shortened polling deadline (the solver's
    # two-second cleanup lead is not available to du). This process is owned by
    # the controller, and any timeout enters its complete subtree cleanup.
    process = subprocess.Popen(['/usr/bin/du', '-s', '-B1', '--', str(path)],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               env=HELPER_ENV)
    owner.register(process)
    try:
        remaining = min(15.0, (deadline_ns - time.monotonic_ns()) / NANO)
        require(remaining > 0, 'du has no remaining deadline')
        data, _ = process.communicate(timeout=remaining)
        check(deadline_ns)
        require(process.returncode == 0 and len(data) <= 8192,
                'allocation measurement failed')
        number = int(data.split()[0])
        require(number >= 0, 'negative allocation')
        return number
    finally:
        process.stdout.close()


def storage(policy, deadline_ns, owner, admission=False):
    total = allocated(policy['root'], deadline_ns, owner)
    batch = sum(allocated(root, deadline_ns, owner)
                for root in policy['campaign_roots'])
    check(deadline_ns)
    free = shutil.disk_usage(policy['root']).free
    check(deadline_ns)
    limits = policy['limits']
    # Reserve all outstanding campaign space throughout, not only at launch.
    outstanding = max(0, limits['batch'] - batch)
    require(total + outstanding < limits['aggregate'] - limits['reserve']
            and batch < limits['batch']
            and free > limits['floor'] + limits['reserve'] + outstanding,
            'storage reserve exhausted: ' + repr((total, batch, free)))
    return [total, batch, free]


def memory_available():
    fields = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    return int(fields['MemAvailable'].split()[0]) * 1024
