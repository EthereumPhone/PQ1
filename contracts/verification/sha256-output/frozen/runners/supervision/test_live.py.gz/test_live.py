"""One isolated live supervision control. This file never launches original CBMC."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import collector
import authority
import budget
import context
import common
from budget import NANO
from process_ownership import OwnedTree, descends_from, identity, snapshot

ROOT, CONTROL = Path(sys.argv[1]), sys.argv[2]
assert ROOT.is_relative_to('/tmp') and ROOT.name.startswith('pq1-budget-test-')
assert CONTROL in {'positive', 'timer_refusal', 'kill_controller', 'kill_watchdog', 'hung', 'local_du'}
START = time.monotonic()
HARD = 12 if CONTROL in {'timer_refusal', 'local_du'} else 18
END = START + HARD - 1


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    return str(path)


properties = {}
for i in range(2840):
    name, description = f'synthetic.assertion.{i}', f'synthetic assertion {i}'
    klass = 'unsupported_construct' if i in range(0, 19 * 140, 140) else 'assertion'
    properties[name] = {'name': name, 'class': klass, 'description': description,
                        'expression': 'TRUE', 'sourceLocation': {
                            'propertyId': name, 'propertyClass': klass, 'comment': description,
                            'file': 'synthetic.rs', 'function': 'synthetic',
                            'propertyFatal': klass == 'unsupported_construct'}}
# The two required root rows are one complete assertion/reachability pair.
for i, klass, description, expression in [
        (1, 'assertion', '[KANI_CHECK_ID_synthetic_root] wrong oracle', 'FALSE'),
        (2, 'reachability_check', 'KANI_CHECK_ID_synthetic_root', 'FALSE')]:
    prop = properties[f'synthetic.assertion.{i}']
    prop.update({'class': klass, 'description': description, 'expression': expression})
    prop['sourceLocation'].update(propertyClass=klass, comment=description)
required = {f'synthetic.assertion.{i}': 'FAILURE' for i in [1, 2]}
names = list(properties)
parts = [names[i:i + 128] for i in range(0, len(names), 128)]
mode = 'negative' if CONTROL == 'positive' else 'malformed' if CONTROL == 'timer_refusal' else 'hang'
program = write('program.json', {'synthetic_test_only': True, 'mode': mode, 'properties': properties, 'required': required})
manifest = write('groups.json', parts[1:])
profile = {'kind': context.KIND, 'prior_backend': 'minisat2',
           'base_command': ['/usr/bin/python3', '-E', '-S', '-B', str(common.SOURCE / 'synthetic_solver.py'),
                            '--sat-solver', 'minisat2', '--unwind', '193', '--unwinding-assertions'],
           'candidate': '/usr/bin/python3', 'program': program, 'program_sha256': sha(program),
           'manifest': manifest, 'properties': properties, 'parts': parts,
           'order': list(range(23)), 'composition_order': list(range(23)),
           'solver_order': list(range(1, 23)) + [0], 'required': required,
           'expected_failure': 'synthetic.assertion.1'}
sources = {str(p): sha(p) for p in sorted(common.SOURCE.iterdir())}
runtime_path = Path(authority.NATIVE['path'])
assert sha(runtime_path) == authority.NATIVE['sha256']
runtime = json.loads(runtime_path.read_text())
pins = {**runtime['file_pins'], **sources, program: sha(program), manifest: sha(manifest)}
offsets = {'solver': 700, 'work': 880, 'term': 882, 'kill': 887, 'final': 892} if CONTROL == 'positive' else {
    'solver': 8, 'work': 10, 'term': 11, 'kill': 12, 'final': 14}
case = {'synthetic_test_only': True, 'slot': str(ROOT / 'slot'), 'profile': profile,
        'pins': pins, 'helper_sources': sources, 'test_offsets': {k: v * NANO for k, v in offsets.items()},
        'storage_policy': {'root': str(ROOT), 'campaign_roots': [str(ROOT / 'slot')],
                           'limits': common.LIMITS, 'synthetic_test_only': True},
        'legacy': {'cwd': str(ROOT), 'environment': common.HELPER_ENV},
        'delay_du_until_refusal': CONTROL == 'local_du'}
case_path = write('case.json', case)
owner = OwnedTree()
# A bystander in the observer's same session/group, but outside its ownership
# subtree. Broad PID/group cleanup would kill it and fail this control.
sentinel = subprocess.Popen(['/usr/bin/python3', '-E', '-S', '-B', '-c',
    'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print("ready",flush=True);time.sleep(60)'],
    stdout=subprocess.PIPE, text=True, env=common.HELPER_ENV)
owner.register(sentinel)
assert sentinel.stdout.readline().strip() == 'ready'
sentinel.stdout.close()
observer = None
signalled = []
try:
    with (ROOT / 'observer.log').open('xb') as log:
        observer = subprocess.Popen(common.helper_command('observer', 'synthetic', case_path, sha(case_path)),
                                    cwd=common.SOURCE, env=common.HELPER_ENV,
                                    stdout=log, stderr=subprocess.STDOUT)
        owner.register(observer)
        assert os.getpgid(observer.pid) == os.getpgid(sentinel.pid)
        if CONTROL in {'kill_controller', 'kill_watchdog', 'hung'}:
            while not (ROOT / 'solver-ready.json').exists():
                assert time.monotonic() < END and observer.poll() is None, 'observer exited before solver readiness'
                time.sleep(.005)
            targets = ['controller', 'watchdog'] if CONTROL == 'hung' else [CONTROL.removeprefix('kill_')]
            for role in targets:
                target = json.loads((ROOT / 'slot' / (role + '-ready.json')).read_text())[role]
                observed = identity(target['pid'])
                assert observed['start_ticks'] == target['start_ticks']
                assert descends_from(target['pid'], observer.pid, snapshot())
                key = owner._acquire(observed)
                sig = signal.SIGSTOP if CONTROL == 'hung' else signal.SIGKILL
                signal.pidfd_send_signal(owner.handles[key], sig, None, 0)
                signalled.append({'role': role, 'identity': target, 'signal': int(sig)})
        while observer.poll() is None:
            assert time.monotonic() < END, 'synthetic observer exceeded control lifetime'
            time.sleep(.01)
    assert sentinel.poll() is None, 'outside-tree same-group sentinel was signalled'
    terminal = json.loads((ROOT / 'slot/observer-terminal.json').read_text())
    assert terminal['zero_descendants'] is True
    if CONTROL == 'positive':
        assert observer.returncode == 0 and terminal['stop'] is None
        assert terminal['accounting']['proof_credit'] is True
        controller = json.loads((ROOT / 'slot/controller-terminal.json').read_text())
        assert controller['proof']['static_count'] == 2840 and controller['proof']['complete']
        assert controller['proof']['dynamic_count'] == 1 and controller['proof']['fresh_root']
        assert controller['proof']['expected_failure'] == 'synthetic.assertion.1'
        assert [a['role'] for a in controller['attempts']] == ['fresh_census', 'tail', 'root']
        root_result = json.loads((ROOT / 'slot/root/result.json').read_text())
        assert root_result['exit'] == 10 and root_result['seconds'] < 600
        capture = json.loads((ROOT / 'slot/tail/first-tail-dynamic.json').read_text())
        assert capture['statuses'] == {'synthetic.unwind.0': 'SUCCESS'}
        tail = json.loads((ROOT / 'slot/tail/result.json').read_text())
        spec = json.loads((ROOT / 'slot/tail/spec.json').read_text())
        assert spec['seconds'] == 600 and tail['solver_seconds'] <= tail['seconds'] < 18
    else:
        assert observer.returncode != 0 and terminal['accounting']['proof_credit'] is False
        assert terminal['accounting']['debit_seconds'] >= budget.reservation()
        for filename in ['solver-ready.json', 'grandchild-ready.json']:
            known = json.loads((ROOT / filename).read_text())
            try:
                current = identity(known['pid'])
            except (FileNotFoundError, ProcessLookupError):
                pass
            else:
                assert current['start_ticks'] != known['start_ticks'], 'owned child survived finalization'
        if CONTROL in {'timer_refusal', 'local_du'}:
            tail = json.loads((ROOT / 'slot/tail/result.json').read_text())
            assert tail['local_cleanup_complete'] and tail['pins_unchanged']
            assert tail['live_members_after_cleanup'] == []
            assert tail['solver_phase_end_ns'] <= tail['post_solver_end_ns']
            if CONTROL == 'timer_refusal':
                assert tail['exit'] == 125, 'timer did not exit through its own refusal path'
                controller = json.loads((ROOT / 'slot/controller-terminal.json').read_text())
                grandchild = json.loads((ROOT / 'grandchild-ready.json').read_text())
                assert any(e['event'] == 'adopted_reaped' and e['pid'] == grandchild['pid']
                           for e in controller['ownership_events']), 'exited-timer orphan was not reaped locally'
            else:
                assert tail['stop'] is not None, 'delayed du did not produce local refusal'
    write('test-result.json', {'status': 'PASS', 'synthetic_test_only': True, 'control': CONTROL,
                              'observer_exit': observer.returncode, 'outside_sentinel_survived': True,
                              'signals': signalled, 'seconds': time.monotonic() - START,
                              'original_queries': 0})
    print((ROOT / 'test-result.json').read_text(), flush=True)
finally:
    assert owner.cleanup(time.monotonic() + 2, grace=.05), 'independent harness cleanup failed'
    assert owner.empty()
    owner.close()
