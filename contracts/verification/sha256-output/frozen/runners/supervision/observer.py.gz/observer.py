"""One-use outer observer. Owns watchdog wait status and complete accounting."""
import fcntl
import json
import math
import os
from pathlib import Path
import time

import authority
import budget
import common
import context
from budget import NANO, require
from process_ownership import OwnedTree, identity
from supervision import drain, monitor, validate_observation
from watchdog import parent_is


def reserve_slot(slot):
    """An existing directory, including an incomplete attempt, always refuses."""
    Path(slot).mkdir()


def failure_record(path, value):
    """Only failure accounting may be recorded after a deadline; no new budget."""
    require(value.get('proof_credit') is False, 'late writer cannot grant credit')
    data = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    require(len(data) <= common.FILE_BYTES, 'oversized failure receipt')
    with Path(path).open('xb') as stream:
        stream.write(data)


def bind_watchdog(slot, binding, runtime, observation, command):
    deadline = runtime['deadlines']['final']
    actual = validate_observation(observation, command, runtime['start_ns'], deadline)
    path = slot / 'watchdog-summary.json'
    summary = common.read(path, deadline)
    require(summary['context'] == binding and summary['watchdog'] == actual
            and summary['stop'] is None and summary['zero_descendants'] is True
            and runtime['start_ns'] <= summary['finished_ns'] <= observation['observed_exit_ns'],
            'changed or incomplete watchdog summary')
    controller = summary['controller']
    # Only bounded receipt files are inspected here. Bulk source/runtime/input
    # authentication and raw proof collection have already completed upstream.
    terminal = authority.bound(controller['controller_terminal'], deadline)
    completion = authority.bound(controller['controller_completion'], deadline)
    require(terminal['context'] == completion['context'] == binding
            and completion['terminal_sha256'] == controller['controller_terminal']['sha256']
            and terminal['stop'] is None and terminal['zero_descendants'] is True
            and completion['complete'] is True and terminal['proof'] == controller['proof']
            and terminal['declared_seconds'] == controller['controller_declared_seconds'],
            'changed controller receipts after watchdog validation')
    return summary, {'path': str(path), 'sha256': common.sha(path, deadline)}


def supervise(runtime, binding, launch_ref, selection_ref, owner, synthetic=False):
    slot = Path(runtime['slot'])
    args = [binding['path'], binding['sha256'], launch_ref['path'], launch_ref['sha256'],
            selection_ref['path'], selection_ref['sha256']]
    if synthetic:
        args.insert(0, 'synthetic')
    command = common.helper_command('watchdog', *args)
    observation, summary_ref, summary, stop = None, None, None, None
    try:
        with (slot / 'watchdog.log').open('xb') as output:
            observation = monitor(owner, command, str(common.SOURCE), output, runtime['deadlines'])
        summary, summary_ref = bind_watchdog(slot, binding, runtime, observation, command)
        require(owner.empty(), 'observer descendant remains')
        # Context is small and immutable; recheck its exact bytes after all
        # supervised work, without a bulk pass in the final window.
        require(common.sha(binding['path'], runtime['deadlines']['final']) == binding['sha256'],
                'runtime context changed during execution')
    except BaseException as error:
        stop = repr(error)
    return observation, summary, summary_ref, stop


def finish(runtime, binding, owner, observation, summary, summary_ref, stop,
           entry_ns, host_ref):
    slot = Path(runtime['slot'])
    require(owner.empty(), 'observer cannot finalize with owned descendants')
    now = time.monotonic_ns()
    complete = observation is not None and observation['zero_descendants'] is True
    finalized = summary is not None
    good = stop is None and finalized and now < runtime['deadlines']['final']
    declared = 0 if summary is None else summary['controller']['controller_declared_seconds']
    if max(declared, math.ceil((now - runtime['start_ns']) / NANO) + 2) > runtime['reservation_seconds']:
        good = False
        stop = stop or 'insufficient finalization reserve'
    charged = budget.account(now - runtime['start_ns'], declared,
                             runtime['reservation_seconds'], complete=complete,
                             finalized=finalized, accepted=good)
    terminal = {'context': binding, 'observer': runtime['observer'],
                'observer_entry_ns': entry_ns, 'host_start': host_ref,
                'watchdog_observation': observation, 'watchdog_summary': summary_ref,
                'stop': stop, 'accounting': charged, 'zero_descendants': True,
                'observed_ns': now, 'requires_observed_host_exit_zero': True,
                'proof_credit': False}
    path = slot / 'observer-terminal.json'
    if good:
        common.write(path, terminal, runtime['deadlines']['final'])
        completion = {'context': binding, 'terminal_sha256': common.sha(path, runtime['deadlines']['final']),
                      'finished_ns': time.monotonic_ns(), 'complete': True,
                      'requires_observed_host_exit_zero': True, 'proof_credit': False}
        common.write(slot / 'observer-completion.json', completion, runtime['deadlines']['final'])
        require(time.monotonic_ns() - runtime['start_ns'] <= charged['debit_seconds'] * NANO
                and time.monotonic_ns() < runtime['deadlines']['final'],
                'observer final writes exceeded reserved debit/deadline')
        return 0
    # Failed or missing terminal observations retain full reservation as needed.
    # Any actual overrun is carried untruncated; absent completion stays unknown.
    failure_record(path, terminal)
    failure_record(slot / 'observer-completion.json',
                   {'context': binding, 'finished_ns': time.monotonic_ns(),
                    'complete': False, 'proof_credit': False})
    return 1


def main(args, entry_ns):
    if args and args[0] == 'synthetic':
        from synthetic_support import observer_main
        return observer_main(args[1:], entry_ns)
    require(len(args) == 6, 'observer requires launch, selection and host-start bindings')
    launch_ref, selection_ref, host_ref = ({'path': args[i], 'sha256': args[i + 1]}
                                          for i in [0, 2, 4])
    # Fixed production slot is reserved before any case/selection authentication.
    # The host bootstrap's earlier start can only shorten this initial cap.
    slot = authority.SLOT
    reserve_slot(slot)
    initial_deadlines = budget.deadlines(entry_ns)
    reservation = {'kind': context.KIND, 'entry_ns': entry_ns, 'boot_id': context.boot_id(),
                   'missing_terminal_charge_seconds': budget.reservation(),
                   'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
                   'attempt_limit': budget.ATTEMPT, 'no_resume_or_retry': True,
                   'launch_spec': launch_ref, 'selection': selection_ref, 'host_start': host_ref,
                   'proof_credit': False}
    common.write(slot / 'reservation.json', reservation, initial_deadlines['work'])
    owner = OwnedTree()
    lock = (common.CAMPAIGN / 'campaign.lock').open('a')
    runtime, binding, observation, summary, summary_ref = None, None, None, None, None
    stop = None
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        host = authority.bound(host_ref, initial_deadlines['work'])
        require(host_ref['path'] == str(common.CAMPAIGN / 'host-start.json')
                and host['boot_id'] == reservation['boot_id']
                and type(host['start_ns']) is int and 0 < host['start_ns'] <= entry_ns
                and host['launch_spec'] == launch_ref and host['selection'] == selection_ref,
                'changed host startup observation')
        parent_is(host['host'])
        start_ns = host['start_ns']  # Includes interpreter/dispatch before observer entry.
        deadlines = budget.deadlines(start_ns)
        launch_spec = authority.launch(launch_ref, deadlines['solver'])
        case, legacy, profile, prior, pins = authority.load_case(launch_spec['case'], deadlines['solver'])
        authority.selected(selection_ref, launch_ref, launch_spec, case, pins, owner, deadlines['solver'])
        require(owner.empty(), 'pre-authentication child remains')
        runtime = {'kind': context.KIND, 'boot_id': reservation['boot_id'], 'start_ns': start_ns,
                   'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
                   'attempt_limit': budget.ATTEMPT, 'reservation_seconds': budget.reservation(),
                   'deadlines': deadlines, 'slot': str(slot),
                   'case_sha256': launch_spec['case']['sha256'],
                   'selection_sha256': selection_ref['sha256'], 'launch_spec_sha256': launch_ref['sha256'],
                   'observer': {k: owner.owner[k] for k in ['pid', 'start_ticks']}}
        context.validate(runtime, live=True)
        path = slot / 'runtime-context.json'
        common.write(path, runtime, deadlines['solver'])
        binding = {'path': str(path), 'sha256': common.sha(path, deadlines['solver'])}
        observation, summary, summary_ref, stop = supervise(runtime, binding, launch_ref,
                                                            selection_ref, owner)
    except BaseException as error:
        stop = repr(error)
    finally:
        final = (runtime['deadlines'] if runtime is not None else initial_deadlines)['final']
        drain(owner, final)
        lock.close()
    try:
        if runtime is not None and binding is not None:
            return finish(runtime, binding, owner, observation, summary, summary_ref,
                          stop, entry_ns, host_ref)
        # No authenticated context/complete chain: do not invent exact success
        # accounting or a smaller debit from controller-only elapsed time.
        failure_record(slot / 'observer-entry-refusal.json',
                       {'stop': stop, 'entry_ns': entry_ns, 'observed_ns': time.monotonic_ns(),
                        'minimum_debit_seconds': budget.reservation(),
                        'uncertain_final_elapsed': True, 'proof_credit': False})
        return 1
    finally:
        owner.close()
