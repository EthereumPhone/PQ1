"""Explicit test-only dispatch into the real supervision/runner/collector code.

Only /tmp fixture roots and this checked toy backend are allowed. Production
admission never calls this module and rejects its markers and scaled context.
"""
from pathlib import Path
import time

import authority
import budget
import collector
import common
import context
from budget import NANO, require
from process_ownership import OwnedTree


def load(reference, deadline_ns):
    case = authority.bound(reference, deadline_ns)
    root = Path(reference['path']).parent
    require(root.is_relative_to('/tmp') and root.name.startswith('pq1-budget-test-')
            and case['synthetic_test_only'] is True and case['slot'] == str(root / 'slot'),
            'synthetic dispatch outside fixture root')
    common.storage_policy(case['storage_policy'], synthetic=True)
    require(case['storage_policy']['root'] == str(root), 'changed synthetic storage root')
    profile = case['profile']
    require(profile['kind'] == context.KIND
            and profile['program'] == str(root / 'program.json')
            and profile['manifest'] == str(root / 'groups.json')
            and profile['candidate'] == '/usr/bin/python3'
            and profile['base_command'] == ['/usr/bin/python3', '-E', '-S', '-B',
                str(common.SOURCE / 'synthetic_solver.py'), '--sat-solver', 'minisat2',
                '--unwind', '193', '--unwinding-assertions'],
            'synthetic path may not launch original/arbitrary backend')
    program = common.read(profile['program'], deadline_ns)
    require(program['synthetic_test_only'] is True
            and program['mode'] in {'negative', 'hang', 'malformed'}
            and program['properties'] == profile['properties']
            and len(profile['properties']) == 2840
            and all(name.startswith('synthetic.assertion.') for name in profile['properties']),
            'changed toy program/census')
    pins = dict(case['pins'])
    common.source_closure(case['helper_sources'], deadline_ns)
    require(all(pins.get(path) == digest for path, digest in case['helper_sources'].items()),
            'synthetic helper pin missing')
    common.authenticate(pins, deadline_ns)
    require(pins.get(profile['program']) == profile['program_sha256'], 'toy program unbound')
    authority.merge(pins, {reference['path']: reference['sha256']})
    legacy = case['legacy']
    require(set(legacy) == {'cwd', 'environment'}
            and legacy['cwd'] == str(root) and legacy['environment'] == common.HELPER_ENV,
            'changed toy environment')
    return case, legacy, profile, None, pins


def observer_main(args, entry_ns):
    require(len(args) == 2, 'synthetic observer requires one fixture binding')
    reference = {'path': args[0], 'sha256': args[1]}
    # Inspect the small location/offset header first; never consult production
    # slot or program paths. The real original observer's reservation is separate.
    header = authority.bound(reference, entry_ns + 180 * NANO)
    root = Path(reference['path']).parent
    require(root.is_relative_to('/tmp') and root.name.startswith('pq1-budget-test-')
            and header['synthetic_test_only'] is True and header['slot'] == str(root / 'slot'),
            'invalid synthetic observer root')
    slot = root / 'slot'
    import observer
    observer.reserve_slot(slot)
    owner = OwnedTree()
    runtime = {'kind': context.KIND, 'boot_id': context.boot_id(), 'start_ns': entry_ns,
               'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
               'attempt_limit': budget.ATTEMPT, 'reservation_seconds': budget.reservation(),
               'deadlines': {k: entry_ns + v for k, v in header['test_offsets'].items()},
               'slot': str(slot), 'case_sha256': reference['sha256'],
               'selection_sha256': reference['sha256'], 'launch_spec_sha256': reference['sha256'],
               'observer': {k: owner.owner[k] for k in ['pid', 'start_ticks']},
               'synthetic_test_only': True, 'test_offsets': header['test_offsets']}
    context.validate(runtime, live=True, synthetic=True)
    common.write(slot / 'reservation.json', {'synthetic_test_only': True, 'context': runtime,
                 'minimum_missing_terminal_debit': budget.reservation()}, runtime['deadlines']['work'])
    load(reference, runtime['deadlines']['solver'])
    path = slot / 'runtime-context.json'
    common.write(path, runtime, runtime['deadlines']['solver'])
    binding = {'path': str(path), 'sha256': common.sha(path, runtime['deadlines']['solver'])}
    observation, summary, summary_ref, stop = observer.supervise(
        runtime, binding, reference, reference, owner, synthetic=True)
    result = observer.finish(runtime, binding, owner, observation, summary, summary_ref,
                             stop, entry_ns, reference)
    owner.close()
    return result


def watchdog_main(args, entry_ns):
    require(len(args) == 6, 'invalid synthetic watchdog bindings')
    binding, reference, selected = ({'path': args[i], 'sha256': args[i + 1]} for i in [0, 2, 4])
    require(reference == selected, 'mixed synthetic/production selection')
    runtime = context.load(binding, entry_ns + 180 * NANO, live=True, synthetic=True)
    require(runtime['case_sha256'] == reference['sha256'], 'changed synthetic case')
    load(reference, runtime['deadlines']['solver'])
    import watchdog
    watchdog.parent_is(runtime['observer'])
    owner = OwnedTree()
    return watchdog.execute(runtime, binding, args, owner, synthetic=True)


def controller_main(args, entry_ns):
    require(len(args) == 6, 'invalid synthetic controller bindings')
    binding, reference, selected = ({'path': args[i], 'sha256': args[i + 1]} for i in [0, 2, 4])
    require(reference == selected, 'mixed synthetic/production selection')
    runtime = context.load(binding, entry_ns + 180 * NANO, live=True, synthetic=True)
    require(runtime['case_sha256'] == reference['sha256'], 'changed synthetic case')
    deadline = runtime['deadlines']['work']
    case, legacy, profile, prior, pins = load(reference, deadline)
    from watchdog import parent_is
    ready = common.read(Path(runtime['slot']) / 'watchdog-ready.json', deadline)
    require(ready['context'] == binding, 'changed synthetic watchdog context')
    parent_is(ready['watchdog'])
    owner = OwnedTree()
    if case.get('delay_du_until_refusal') is True:
        original = common.allocated
        delayed = False

        def delay_then_actual_du(path, absolute_deadline, current_owner):
            nonlocal delayed
            if not delayed and (Path(case['slot']).parent / 'solver-ready.json').exists():
                delayed = True
                time.sleep(max(0, (absolute_deadline - time.monotonic_ns()) / NANO) + .02)
            return original(path, absolute_deadline, current_owner)

        common.allocated = delay_then_actual_du
    import controller
    try:
        return controller.execute_loaded(case, legacy, profile, prior, pins, runtime,
                                          binding, owner, synthetic=True)
    finally:
        owner.cleanup(deadline / NANO, grace=.25)
        owner.close()
