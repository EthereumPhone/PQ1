"""One context-bound census, tail or fresh root; authority belongs to the controller.

Every refusal cleans all controller-local descendants, even after the direct
timer has exited. No post-validation may start before that cleanup completes.
"""
from pathlib import Path
import subprocess
import time

import context
import budget
from budget import NANO, require
from common import (HELPER_ENV, FILE_BYTES, authenticate, check, helper_command,
                    memory_available, sha, source_closure, storage, storage_policy, write)


def execute(spec, frozen_pins, binding, owner, policy, sources, timing=None,
            synthetic=False, role=None, allocation_start_ns=None):
    entered = time.monotonic_ns()
    started = entered if allocation_start_ns is None else allocation_start_ns
    require(type(started) is int and 0 < started <= entered, 'invalid allocation origin')
    spec = dict(spec)
    require(set(spec) == {'command', 'cwd', 'environment', 'output', 'seconds',
                          'address_space', 'file_bytes'}, 'changed runner spec schema')
    runtime = context.load(binding, started + 180 * NANO, live=True, synthetic=synthetic)
    tail = timing is not None
    role = ('tail' if tail else 'fresh_census') if role is None else role
    require(role in {'fresh_census', 'tail', 'root'} and tail is (role == 'tail'),
            'runner role/timing mismatch')
    root = role == 'root'
    bounds = context.runner_bounds(runtime, started, spec['seconds'], tail, root=root)
    output = Path(spec['output'])
    require(output == Path(runtime['slot']) / role,
            'runner output outside reserved slot')
    require(spec['address_space'] == (8 if synthetic else 16) * 1024**3
            and spec['file_bytes'] == FILE_BYTES, 'changed command resource limits')
    storage_policy(policy, synthetic)
    require(owner.empty(), 'unexpected child at runner entry')
    pins = dict(frozen_pins)
    require(pins.get(binding['path']) == binding['sha256'], 'unbound runtime context')
    require(sources and all(pins.get(k) == v for k, v in sources.items()),
            'missing helper source binding')
    output.mkdir()  # No overwrite, reuse or implicit retry.
    spec.update({'context': binding, 'runner_start_ns': started, 'bounds': bounds})
    timer_spec_path, timer_receipt = output / 'timing-spec.json', output / 'timing.json'
    setup_deadline = min(bounds['poll_deadline_ns'], started + 180 * NANO)
    if tail:
        require(set(timing) in [{'gate_contract', 'gate_contract_sha256'},
                               {'gate_contract', 'gate_contract_sha256', 'dynamic_capture'}],
                'changed gate binding schema')
        require(pins.get(timing['gate_contract']) == timing['gate_contract_sha256'],
                'unbound group gate')
        timer_spec = dict(timing, schema='bounded-phased-v1', side='candidate',
                          context=binding, runner_start_ns=started, bounds=bounds,
                          outer_monotonic_start=started / NANO,
                          group_count=22, group_seconds=budget.GROUP_SECONDS,
                          first_group_seconds=budget.FIRST_GROUP_SECONDS, whole_seconds=spec['seconds'],
                          commands=[spec['command']], solver_cwd=spec['cwd'],
                          solver_environment=spec['environment'])
        if synthetic:
            timer_spec['synthetic_test_only'] = True
        write(timer_spec_path, timer_spec, setup_deadline)
        pins[str(timer_spec_path)] = sha(timer_spec_path, setup_deadline)
        spec['command'] = helper_command('timer', timer_spec_path,
                                         pins[str(timer_spec_path)], timer_receipt)
    spec['pins'] = dict(pins)
    spec_path = output / 'spec.json'
    write(spec_path, spec, setup_deadline)
    spec_hash = sha(spec_path, setup_deadline)
    pins[str(spec_path)] = spec_hash
    command = ['/usr/bin/prlimit', f'--cpu={spec["seconds"]}:{spec["seconds"]}',
               f'--as={spec["address_space"]}:{spec["address_space"]}',
               f'--fsize={FILE_BYTES}:{FILE_BYTES}', '--core=0:0', '--', *spec['command']]
    environment = HELPER_ENV if tail else spec['environment']
    process, code, stop, terminal = None, None, None, None
    unchanged, cleaned = False, False
    effective_path = output / 'effective.json'
    log_path = output / 'command.log'
    try:
        with log_path.open('xb') as log:
            try:
                source_closure(sources, setup_deadline)
                authenticate(pins, setup_deadline)
                require(synthetic or memory_available() >= 32 * 1024**3,
                        'less than32GiB MemAvailable')
                initial = storage(policy, setup_deadline, owner, admission=True)
                effective = {'spec_sha256': spec_hash, 'pins': pins, 'command': command,
                             'initial_storage': initial, 'storage_policy': policy,
                             'context': binding, 'bounds': bounds, 'runner_start_ns': started,
                             'execution_environment': environment}
                write(effective_path, effective, setup_deadline)
                check(setup_deadline)
                process = subprocess.Popen(command, cwd=spec['cwd'], env=environment,
                                           stdout=log, stderr=subprocess.STDOUT,
                                           start_new_session=True)
                owner.register(process)
                while process.poll() is None:
                    check(bounds['poll_deadline_ns'])
                    storage(policy, bounds['poll_deadline_ns'], owner)
                    time.sleep(.05)
            except BaseException as error:
                stop = repr(error)
            finally:
                # Unconditional, including the already-exited timer path.
                cleaned = owner.cleanup(bounds['effective_solver_deadline_ns'] / NANO)
                code = None if process is None else process.poll()
    except BaseException as error:
        stop = stop or repr(error)
        cleaned = owner.cleanup(bounds['effective_solver_deadline_ns'] / NANO)
        code = None if process is None else process.poll()
    solver_end = time.monotonic_ns()
    live = owner.discover()
    if not cleaned or live or solver_end >= bounds['effective_solver_deadline_ns']:
        stop = stop or 'incomplete or late local subtree cleanup'
    post_deadline = min(bounds['post_deadline_ns'], solver_end + 180 * NANO)
    log_hash = None
    if cleaned and not live and solver_end < bounds['effective_solver_deadline_ns']:
        try:
            # These operations cannot begin while any local descendant remains.
            source_closure(sources, post_deadline)
            authenticate(pins, post_deadline)
            unchanged = True
            terminal = storage(policy, post_deadline, owner)
            log_hash = sha(log_path, post_deadline)
            # du is itself owned/reaped through its registered Popen object.
            require(owner.empty(), 'post-validation child remains')
        except BaseException as error:
            stop = stop or repr(error)
            # A post-validation du may itself time out. Clean it within work
            # allowance; zero proof credit follows from the recorded refusal.
            cleaned = owner.cleanup(bounds['post_deadline_ns'] / NANO)
    post_end = time.monotonic_ns()
    live = owner.discover()
    if post_end >= post_deadline or live:
        stop = stop or 'post-validation deadline or descendant refusal'
    result = {'exit': code, 'stop': stop, 'seconds': (post_end - started) / NANO,
              'pins_unchanged': unchanged, 'live_members_after_cleanup': live,
              'terminal_storage': terminal, 'spec_sha256': spec_hash,
              'log_sha256': log_hash, 'monotonic_start': started / NANO,
              'context': binding, 'bounds': bounds, 'runner_start_ns': started,
              'solver_phase_end_ns': solver_end, 'post_solver_end_ns': post_end,
              'solver_seconds': (solver_end - started) / NANO,
              'local_cleanup_complete': cleaned, 'proof_credit': False}
    descriptor = {'schema': ('bounded-phased-v1' if tail else
                             'bounded-root-v1' if root else 'bounded'),
                  'spec': str(spec_path), 'expected_spec': spec,
                  'result': str(output / 'result.json'), 'log': str(log_path),
                  'effective': str(effective_path), 'expected_effective_command': command,
                  'resources': policy['limits'], 'context': binding,
                  'expected_storage_policy': policy,
                  'expected_execution_environment': environment}
    if synthetic:
        descriptor['synthetic_test_only'] = True
    # A deadline here may leave an incomplete refusal; the outer layers reserve
    # the full attempt and keep the missing receipt explicit. Never extend it.
    write(output / 'result.json', result, runtime['deadlines']['work'])
    for path in [output / 'result.json', log_path, effective_path, timer_receipt,
                 output / 'first-tail-dynamic.json']:
        if path.exists():
            pins[str(path)] = sha(path, runtime['deadlines']['work'])
    return descriptor, result, pins
