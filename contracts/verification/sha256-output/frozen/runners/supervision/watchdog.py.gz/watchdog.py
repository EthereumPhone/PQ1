"""Independent controller supervisor; observer alone certifies this exit."""
import os
from pathlib import Path
import time

import authority
import context
from budget import NANO, require
import common
from process_ownership import OwnedTree, identity
from supervision import monitor, validate_observation


def parent_is(expected):
    parent = identity(os.getppid())
    require({k: parent[k] for k in ['pid', 'start_ticks']} == expected
            and parent['state'] not in {'Z', 'X'}, 'changed direct supervision parent')


def bind_terminal(slot, binding, observation, command, runtime, deadline_ns):
    actual_child = validate_observation(observation, command, runtime['start_ns'],
                                        runtime['deadlines']['work'])
    terminal_path, completion_path = slot / 'controller-terminal.json', slot / 'controller-completion.json'
    terminal = common.read(terminal_path, deadline_ns)
    completion = common.read(completion_path, deadline_ns)
    terminal_hash = common.sha(terminal_path, deadline_ns)
    require(terminal['context'] == completion['context'] == binding
            and terminal['controller'] == actual_child
            and terminal['stop'] is None and terminal['zero_descendants'] is True
            and terminal['proof']['complete'] is True
            and terminal['proof']['static_count'] == 2840
            and terminal['proof']['partition_count'] == 23
            and completion['terminal_sha256'] == terminal_hash
            and completion['complete'] is True,
            'missing or failed bound controller completion')
    require(runtime['start_ns'] <= terminal['finished_ns'] <= completion['finished_ns']
            <= observation['observed_exit_ns'] < runtime['deadlines']['work'],
            'controller did not finish by work deadline')
    return {'controller_terminal': {'path': str(terminal_path), 'sha256': terminal_hash},
            'controller_completion': {'path': str(completion_path),
                                      'sha256': common.sha(completion_path, deadline_ns)},
            'controller_declared_seconds': terminal['declared_seconds'],
            'proof': terminal['proof']}


def main(args, entry_ns):
    if args and args[0] == 'synthetic':
        from synthetic_support import watchdog_main
        return watchdog_main(args[1:], entry_ns)
    require(len(args) == 6, 'watchdog requires context, launch and selection bindings')
    binding, launch_ref, selection_ref = ({'path': args[i], 'sha256': args[i + 1]}
                                         for i in [0, 2, 4])
    # Synthetic integration is dispatched explicitly through a separate test
    # driver; production never interprets synthetic markers here.
    runtime = context.load(binding, entry_ns + 180 * NANO, live=True)
    parent_is(runtime['observer'])
    launch_spec = authority.launch(launch_ref, runtime['deadlines']['work'])
    require(runtime['launch_spec_sha256'] == launch_ref['sha256']
            and runtime['selection_sha256'] == selection_ref['sha256']
            and runtime['case_sha256'] == launch_spec['case']['sha256'],
            'changed watchdog static bindings')
    owner = OwnedTree()
    return execute(runtime, binding, args, owner)


def execute(runtime, binding, args, owner, synthetic=False):
    slot = Path(runtime['slot'])
    own_identity = {k: owner.owner[k] for k in ['pid', 'start_ticks']}
    common.write(slot / 'watchdog-ready.json', {'watchdog': own_identity, 'context': binding},
                 runtime['deadlines']['work'])
    command = common.helper_command('controller', *(['synthetic'] if synthetic else []), *args)
    observation, terminal, stop = None, None, None
    try:
        with (slot / 'controller.log').open('xb') as log:
            observation = monitor(owner, command, str(common.SOURCE), log, runtime['deadlines'])
        terminal = bind_terminal(slot, binding, observation, command, runtime,
                                 runtime['deadlines']['final'])
    except BaseException as error:
        stop = repr(error)
    require(owner.empty(), 'watchdog cannot finalize with descendants')
    summary = {'context': binding, 'watchdog': own_identity,
               'controller_observation': observation, 'controller': terminal,
               'stop': stop, 'zero_descendants': True,
               'finished_ns': time.monotonic_ns(), 'proof_credit': False}
    # This summary never certifies watchdog exit. Even an on-time good summary
    # with an actual nonzero exit is rejected by the outer observer.
    common.write(slot / 'watchdog-summary.json', summary, runtime['deadlines']['final'])
    owner.close()
    return 0 if stop is None and terminal is not None else 1
