"""Exact full negative census shape, not an execution or proof-acceptance gate.

The caller must separately authenticate preparation, compare every literal
census record and bind actual exits. This module grants no command authority.
"""
import copy

import pq1_partition as p

KIND = 'original-negative-oracle-byte-v1'
ORDER = [0, 2, 1, 5, 12, 13, 3, 9, 8, 10, 11, 4, 16, 6, 7, 14, 15, 17, 18, 21, 19, 22, 20]
EXPECTED_FAILURE = 'diagnostic::actual_empty_digest.assertion.3'
ROOTS = [
    ('diagnostic::actual_empty_digest.assertion.3',
     'diagnostic::actual_empty_digest.reachability_check.3',
     'assertion', '14', '"empty one-shot digest byte"'),
    ('diagnostic::actual_empty_digest.assertion.6',
     'diagnostic::actual_empty_digest.reachability_check.6',
     'assertion', '15', '"empty segmented digest byte"'),
    ('diagnostic::actual_empty_digest.cover.1',
     'diagnostic::actual_empty_digest.reachability_check.7',
     'cover', '16', 'both actual empty callers reached'),
]


def census_contract(properties, positive):
    p.require(len(properties) == 2840 and set(properties) == set(positive['properties'])
              and positive['execution_order'] == ORDER and positive['expected_failure'] is None,
              'changed complete census identity or composition order')
    groups = p.groups(properties)
    pairs = [group for group in groups if len(group) == 2]
    p.require(len(pairs) == 315, 'changed reachability pair count')
    p.require({tuple(group) for group in groups}
              == {tuple(group) for group in p.groups(positive['properties'])},
              'changed whole-pair membership')
    guards = sorted(name for name, row in properties.items()
                    if row['class'] == 'unsupported_construct')
    fatal = sorted(name for name, row in properties.items()
                   if row['sourceLocation'].get('propertyFatal'))
    p.require(len(guards) == 19 and guards == sorted(
        name for name, row in positive['properties'].items()
        if row['class'] == 'unsupported_construct'), 'changed unsupported guard census')
    p.require(len(fatal) == 1125 and fatal == sorted(
        name for name, row in positive['properties'].items()
        if row['sourceLocation'].get('propertyFatal')), 'changed fatal obligation census')
    roots = {}
    all_roots = []
    for name, reach, kind, line, description in ROOTS:
        row, probe = properties[name], properties[reach]
        markers = p.MARKER.findall(row['description'])
        p.require(len(markers) == 1 and row['class'] == kind
                  and row['description'] == '[' + markers[0] + '] ' + description
                  and probe['class'] == 'reachability_check'
                  and probe['description'] == markers[0] and probe['expression'] == 'FALSE'
                  and sorted([name, reach]) in pairs, 'changed exact root or reachable pair')
        for member in [row, probe]:
            loc = member['sourceLocation']
            p.require(loc.get('file') == 'src/lib.rs'
                      and loc.get('function') == 'diagnostic::actual_empty_digest'
                      and str(loc.get('line')) == line, 'changed root source provenance')
        roots[description] = {'property': name, 'reachability': reach}
        all_roots.extend([name, reach])
    parts = copy.deepcopy(positive['parts'])
    p.require(len(parts) == 23, 'changed partition count')
    p.validate_partition(properties, parts, all_roots, 128)
    # Partition membership/composition remains the accepted exact index. Only
    # solver scheduling moves the complete fresh root behind the22 tail groups.
    required = {EXPECTED_FAILURE: 'FAILURE', ROOTS[0][1]: 'FAILURE'}
    return {'kind': KIND, 'parts': parts, 'composition_order': ORDER[:],
            'solver_order': ORDER[1:] + [0], 'roots': roots, 'all_roots': all_roots,
            'required': required, 'expected_failure': EXPECTED_FAILURE,
            'unsupported_guards': guards, 'fatal_obligations': fatal,
            'static_count': 2840, 'pair_count': 315, 'partition_count': 23,
            'full_census_audit_complete': False, 'proof_credit': False}
