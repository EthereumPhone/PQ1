"""Independent, nonblocking child supervision shared by observer and watchdog.

While the supervised child is live this code performs no bulk hashing, du or
blocking wait. Only identity-bound descendants may receive signals. Cleanup
after a deadline cannot authorize work or earn proof credit.
"""
import signal
import subprocess
import time

from budget import NANO, require
from common import HELPER_ENV
from process_ownership import identity


def drain(owner, deadline_ns):
    """Remain a reaper after a deadline; late cleanup is never execution credit."""
    on_time = owner.cleanup(deadline_ns / NANO, grace=.25)
    signalled = set()
    while not owner.empty():
        descendants = owner.discover()
        current = {(p['pid'], p['start_ticks']) for p in descendants}
        if current - signalled:
            owner.send(signal.SIGKILL)
            signalled |= current
        time.sleep(.01)
    return on_time and time.monotonic_ns() < deadline_ns


def monitor(owner, command, cwd, output, deadlines):
    launched = time.monotonic_ns()
    require(launched < deadlines['term'], 'no supervision lifetime remains')
    process = subprocess.Popen(command, cwd=cwd, env=HELPER_ENV,
                               stdout=output, stderr=subprocess.STDOUT)
    owner.register(process)
    child_identity = identity(process.pid)
    stop, term_sent, kill_sent = None, False, False
    observed_exit = None
    try:
        while True:
            code = process.poll()  # Sole Popen wait owner; never waitpid(-1).
            now = time.monotonic_ns()
            if code is not None:
                observed_exit = now
                break
            descendants = owner.discover()
            adopted = [p for p in descendants
                       if p['parent'] == owner.owner['pid'] and p['pid'] != process.pid]
            if adopted:
                stop = 'unexpected orphan outside live child topology'
                break
            if now >= deadlines['term'] and not term_sent:
                stop = 'independent TERM deadline'
                owner.send(signal.SIGTERM)
                term_sent = True
            if now >= deadlines['kill'] and not kill_sent:
                stop = stop or 'independent KILL deadline'
                owner.send(signal.SIGKILL)
                kill_sent = True
            if now >= deadlines['final']:
                stop = stop or 'final deadline exceeded'
                break
            time.sleep(.01)
    except BaseException as error:
        stop = repr(error)
    # Normal direct-child exit is not enough. It may have left adopted
    # children, including children in completely separate sessions.
    if not owner.empty():
        had_residual = process.poll() is not None
        stop = stop or ('residual descendants after child exit' if had_residual else 'monitor refusal')
        cleanup_end = min(deadlines['final'], time.monotonic_ns() + 2 * NANO)
        cleaned = drain(owner, cleanup_end)
        if not cleaned:
            stop = stop or 'cleanup exceeded final deadline'
    code = process.poll()
    if observed_exit is None:
        observed_exit = time.monotonic_ns()
    require(code is not None and owner.empty(), 'missing child exit or surviving descendants')
    finished = time.monotonic_ns()
    if finished >= deadlines['final']:
        stop = stop or 'late supervised completion'
    return {'command': command, 'child': {k: child_identity[k] for k in ['pid', 'start_ticks']},
            'launched_ns': launched, 'observed_exit_ns': observed_exit,
            'zero_descendants_ns': finished, 'exit': code, 'stop': stop,
            'zero_descendants': True, 'events': owner.events,
            'proof_credit': False}


def validate_observation(observation, expected_command, start_ns, final_ns):
    require(observation['command'] == expected_command
            and observation['exit'] == 0 and type(observation['exit']) is int
            and observation['stop'] is None and observation['zero_descendants'] is True,
            'missing or failed independently observed child exit')
    times = [observation['launched_ns'], observation['observed_exit_ns'],
             observation['zero_descendants_ns']]
    require(all(type(n) is int for n in times)
            and start_ns <= times[0] <= times[1] <= times[2] < final_ns,
            'late or inconsistent independent exit observation')
    child = observation['child']
    require(set(child) == {'pid', 'start_ticks'} and all(type(n) is int and n > 0
                                                       for n in child.values()),
            'missing actual child identity')
    return child
