"""Synthetic-only foundation controls; not the full supervision gate."""
import json
import os
import subprocess
import sys
import time

import budget
from process_ownership import OwnedTree, identity


def refuses(fn):
    try:
        fn()
    except (ValueError, RuntimeError):
        return
    raise AssertionError('negative control unexpectedly accepted')


start = time.monotonic()
ns = budget.NANO
limits = budget.deadlines(1000 * ns)
assert limits == {'solver': 5109 * ns, 'work': 5289 * ns,
                  'term': 5291 * ns, 'kill': 5296 * ns, 'final': 5301 * ns}
assert budget.tail_cap(limits['solver'], 1010 * ns) == 3960
assert budget.tail_cap(limits['solver'], 1013 * ns) == 3960
assert budget.tail_cap(limits['solver'], 2000 * ns) == 3109
assert budget.tail_cap(limits['solver'], 2003 * ns) == 3106
assert budget.reservation() == 4301
assert budget.INHERITED == 4320 and budget.TOTAL == 8621
assert budget.ATTEMPT == 4301
failed = budget.account(671 * ns, 0, budget.reservation(), complete=True)
assert failed['debit_seconds'] == 4301 and failed['total_case_seconds'] == 8621
assert not failed['proof_credit']

assert budget.root_cap(limits['solver'], 2000 * ns) == 600
assert budget.root_cap(limits['solver'], 5000 * ns) == 109
effective = budget.effective_tail_deadline(limits['solver'], 1010 * ns, 3960)
assert effective == 4970 * ns
screen = budget.screen(130, 65, effective, 1140 * ns)
assert screen['required_later_seconds'] == 3150
assert screen['remaining_seconds'] == 3830 and screen['passes']
assert not budget.screen(0, 0, 6 * ns, 0)['passes']
assert budget.screen(1, .25, 600 * ns, ns)['passes']
refuses(lambda: budget.effective_tail_deadline(limits['solver'], 1010 * ns, 4128))
refuses(lambda: budget.screen(1, 2, 600 * ns, ns))

normal = budget.account(100 * ns, 100, 4320, complete=True, finalized=True,
                        accepted=True)
assert normal['debit_seconds'] == 102 and normal['proof_credit']
late = budget.account(4323 * ns, 0, 4320, complete=True)
assert late['debit_seconds'] == 4325 and not late['proof_credit']
killed = budget.account(30 * ns, 0, 4320, complete=True, finalized=False)
assert killed['debit_seconds'] == 4320 and not killed['proof_credit']
unknown = budget.account(30 * ns, 0, 4320)
assert unknown['uncertain_final_elapsed'] and unknown['debit_is_lower_bound']
assert unknown['debit_seconds'] == 4320
breach = budget.account(6000 * ns, 0, 4320, complete=True)
assert breach['cumulative_ceiling_exceeded'] and breach['debit_seconds'] == 6002
refuses(lambda: budget.account(4323 * ns, 0, 4320, complete=True,
                               finalized=True, accepted=True))

# This isolated process is the subreaper. The direct child exits7 after its
# new-session child has installed TERM-ignore. Only our own descendants exist.
owner = OwnedTree()
grandchild = "import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);print(os.getpid(),flush=True);time.sleep(60)"
child_code = ("import subprocess,sys; p=subprocess.Popen([sys.executable,'-E','-S','-B','-c',"
              + repr(grandchild) + "],stdout=subprocess.PIPE,text=True); "
              "print(p.stdout.readline().strip(),flush=True); raise SystemExit(7)")
child = subprocess.Popen([sys.executable, '-E', '-S', '-B', '-c', child_code],
                         stdout=subprocess.PIPE, text=True, start_new_session=True)
owner.register(child)
grandchild_pid = int(child.stdout.readline().strip())
assert child.wait(timeout=2) == 7
child.stdout.close()
observed = identity(grandchild_pid)
refuses(lambda: owner._acquire(dict(observed, start_ticks=observed['start_ticks'] + 1)))
assert owner.cleanup(time.monotonic() + 2, grace=.1)
assert owner.empty() and child.wait() == 7
assert not os.path.exists(f'/proc/{grandchild_pid}')
assert any(event['event'] == 'adopted_reaped' and event['pid'] == grandchild_pid
           for event in owner.events)
owner.close()
print(json.dumps({'synthetic_test_only': True, 'status': 'PASS',
                  'controls': ['clamped/unclamped deadlines and ACK screen',
                               'success/failure/uncertain/overrun accounting',
                               'single Popen wait owner retains exit7',
                               'adopted new-session TERM-ignoring child killed/reaped',
                               'changed start_ticks rejected before signalling'],
                  'seconds': time.monotonic() - start,
                  'original_queries': 0, 'full_R2_gate_complete': False}), flush=True)
