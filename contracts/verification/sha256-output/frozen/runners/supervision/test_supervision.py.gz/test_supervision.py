"""Focused independent-exit, admission and identity-dispatch controls."""
import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from unittest.mock import patch

import authority
import budget
import common
import context
import host
import observer
import process_ownership
from process_ownership import OwnedTree, identity
from supervision import monitor, validate_observation

ROOT = Path(sys.argv[1])
assert ROOT.is_relative_to('/tmp') and ROOT.name.startswith('pq1-budget-test-')
DEADLINE = time.monotonic_ns() + 10 * budget.NANO
checks = []


def refuses(fn):
    try:
        fn()
    except (ValueError, RuntimeError, FileNotFoundError):
        return
    raise AssertionError('negative control accepted')


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')
    return {'path': str(path), 'sha256': common.sha(path, DEADLINE)}


# Exact Popen exit7 plus a new-session orphan goes through the real outer
# monitor and observer's final receipt writer, not merely the process utility.
slot = ROOT / 'slot'
slot.mkdir()
owner = OwnedTree()
started = time.monotonic_ns()
grandchild = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);print("ready",flush=True);time.sleep(60)'
code = ('import subprocess,sys;p=subprocess.Popen([sys.executable,"-E","-S","-B","-c",'
        + repr(grandchild) + '],stdout=subprocess.PIPE,text=True);'
        'assert p.stdout.readline().strip()=="ready";raise SystemExit(7)')
command = ['/usr/bin/python3', '-E', '-S', '-B', '-c', code]
offsets = {'solver': 4, 'work': 6, 'term': 7, 'kill': 8, 'final': 9}
runtime = {'kind': context.KIND, 'boot_id': context.boot_id(), 'start_ns': started,
           'inherited_seconds': budget.INHERITED, 'cumulative_total': budget.TOTAL,
           'attempt_limit': 4320, 'reservation_seconds': 4320,
           'deadlines': {k: started + n * budget.NANO for k, n in offsets.items()},
           'slot': str(slot), 'case_sha256': 'a' * 64, 'selection_sha256': 'b' * 64,
           'launch_spec_sha256': 'c' * 64, 'observer': {k: owner.owner[k] for k in ['pid', 'start_ticks']},
           'synthetic_test_only': True, 'test_offsets': {k: n * budget.NANO for k, n in offsets.items()}}
context.validate(runtime, live=True, synthetic=True)
binding = write(slot / 'runtime-context.json', runtime)
for fields in [{'boot_id': '00000000-0000-0000-0000-000000000000'},
               {'observer': dict(runtime['observer'], start_ticks=runtime['observer']['start_ticks'] + 1)}]:
    invalid = dict(runtime, **fields)
    refuses(lambda invalid=invalid: context.validate(invalid, live=True, synthetic=True))
refuses(lambda: context.load(dict(binding, sha256='0' * 64), DEADLINE, synthetic=True))
checks.append('actual live boot/owner and changed context digest refuse')
with (ROOT / 'exit7.log').open('xb') as log:
    actual = monitor(owner, command, str(ROOT), log, runtime['deadlines'])
assert actual['exit'] == 7 and actual['zero_descendants']
assert any(e['event'] == 'adopted_reaped' for e in actual['events'])
refuses(lambda: validate_observation(actual, command, started, runtime['deadlines']['final']))
assert observer.finish(runtime, binding, owner, actual, None, None, 'expected exit7',
                       started, {'path': 'synthetic-host', 'sha256': '0' * 64}) == 1
record = json.loads((slot / 'observer-terminal.json').read_text())
assert record['watchdog_observation']['exit'] == 7
assert not record['accounting']['proof_credit'] and record['accounting']['debit_seconds'] >= 4320
assert owner.empty()
owner.close()
checks.append('actual observer receipt preserves exit7 through orphan cleanup and refuses credit')

# A separately launched normal process has an actual observed exit and times.
owner = OwnedTree()
normal_command = ['/usr/bin/python3', '-E', '-S', '-B', '-c', 'raise SystemExit(0)']
with (ROOT / 'normal.log').open('xb') as log:
    normal = monitor(owner, normal_command, str(ROOT), log, runtime['deadlines'])
validate_observation(normal, normal_command, started, runtime['deadlines']['final'])
for fields in [{'exit': None}, {'exit': 7}, {'exit': -9}, {'zero_descendants': False},
               {'observed_exit_ns': runtime['deadlines']['final'] + 1},
               {'command': ['changed']}, {'stop': 'failed'}]:
    invalid = dict(normal, **fields)
    refuses(lambda invalid=invalid: validate_observation(invalid, normal_command, started,
                                                        runtime['deadlines']['final']))
owner.close()
checks.append('normal exit observation binds command/time/status; missing, nonzero, forged and late records refuse')

# Cause identity/ancestry drift precisely after pidfd_open and before its
# validation, with no real PID reuse and no signal sent to any bystander.
owner = OwnedTree()
child = subprocess.Popen(['/usr/bin/python3', '-E', '-S', '-B', '-c', 'import time;time.sleep(30)'])
observed = identity(child.pid)
real_identity = process_ownership.identity
def changed_after_open(pid):
    value = real_identity(pid)
    return dict(value, start_ticks=value['start_ticks'] + 1) if pid == child.pid else value
with patch.object(process_ownership, 'identity', side_effect=changed_after_open), \
        patch.object(signal, 'pidfd_send_signal', side_effect=AssertionError('unexpected dispatch')):
    refuses(lambda: owner._acquire(observed))
changed_ancestry = process_ownership.snapshot()
changed_ancestry[child.pid] = dict(changed_ancestry[child.pid], parent=1)
with patch.object(process_ownership, 'snapshot', return_value=changed_ancestry), \
        patch.object(signal, 'pidfd_send_signal', side_effect=AssertionError('unexpected dispatch')):
    refuses(lambda: owner._acquire(observed))
assert child.poll() is None
owner.register(child)
assert owner.cleanup(time.monotonic() + 1, grace=.01) and owner.empty()
owner.close()
checks.append('identity/ancestry drift after pidfd open causes no signal dispatch')

# Retaining a stopped attempt carries every authenticated input and its full
# conservative debit; it cannot turn a provisional result into proof credit.
previous = ROOT / 'previous'
previous_slot = previous / 'original-positive-budget-continuation-v1'
previous_slot.mkdir(parents=True)
previous_execution = previous / 'original-execution-v1'
previous_execution.mkdir()
write(previous_slot / 'reservation.json', {'missing_terminal_charge_seconds': 4320})
write(previous_slot / 'observer-completion.json', {'complete': False, 'proof_credit': False})
write(previous_execution / 'tool-exit.json', {'observed_exit': 1})
for name in ['host-start.json', 'host-completion.json', 'implementation-freeze-v1.json']:
    write(previous / name, {'fixture': name})
saved_input = previous / 'input.txt'
saved_input.write_text('preserved previous input\n')
saved_pins = {str(saved_input): common.sha(saved_input, DEADLINE)}
pins_ref = write(previous / 'validated-pins.json', saved_pins)
old_terminal = {'proof': None, 'proof_credit': False, 'zero_descendants': True,
                'validated_pins': pins_ref}
terminal_path = previous_slot / 'controller-terminal.json'
terminal_ref = write(terminal_path, old_terminal)
stopped = {'attempt_complete': True, 'host_exit': 1, 'timer_exit': 125,
           'new_proof_credit': False, 'all_local_children_reaped': True,
           'accounting': {'attempt_conservative_debit_seconds': 4320,
                          'inherited_seconds': 1853.8956619648961,
                          'total_case_seconds': budget.INHERITED, 'proof_credit': False,
                          'prior_part0_only_accepted': True},
           'artifacts': {terminal_ref['path']: terminal_ref['sha256']}}

def test_supplement(name):
    paths = [p for root in [previous_slot, previous_execution]
             for p in root.rglob('*') if p.is_file()]
    paths += [previous / p for p in ['host-start.json', 'host-completion.json',
                                    'implementation-freeze-v1.json']]
    return write(ROOT / (name + '.json'), {str(p): common.sha(p, DEADLINE) for p in paths})

supplement_ref = test_supplement('stopped-supplement')
supplement_pins = common.read(supplement_ref['path'], DEADLINE)
with patch.object(authority, 'LEDGER', previous / 'stopping-decision.json'), \
        patch.object(authority, 'STOPPED_SUPPLEMENT', supplement_ref):
    retained = authority.stopped_attempt_pins(stopped, DEADLINE)
    assert retained == {**saved_pins, **supplement_pins,
                        pins_ref['path']: pins_ref['sha256'],
                        supplement_ref['path']: supplement_ref['sha256']}
    common.authenticate(retained, DEADLINE)
    for path in [previous_slot / 'reservation.json', previous_slot / 'observer-completion.json',
                 previous / 'host-start.json', previous / 'implementation-freeze-v1.json']:
        saved = path.read_bytes()
        path.write_bytes(saved + b'\n')
        refuses(lambda: authority.stopped_attempt_pins(stopped, DEADLINE))
        path.write_bytes(saved)
        path.unlink()
        refuses(lambda: authority.stopped_attempt_pins(stopped, DEADLINE))
        path.write_bytes(saved)
    extra = previous_execution / 'unbound.json'
    extra.write_text('{}')
    refuses(lambda: authority.stopped_attempt_pins(stopped, DEADLINE))
    extra.unlink()
    omitted = dict(supplement_pins)
    del omitted[str(previous_slot / 'reservation.json')]
    missing_ref = write(ROOT / 'omitted-supplement.json', omitted)
    with patch.object(authority, 'STOPPED_SUPPLEMENT', missing_ref):
        refuses(lambda: authority.stopped_attempt_pins(stopped, DEADLINE))
    for fields in [{'attempt_complete': False}, {'host_exit': 0},
                   {'new_proof_credit': True}, {'all_local_children_reaped': False}]:
        refuses(lambda fields=fields: authority.stopped_attempt_pins(dict(stopped, **fields), DEADLINE))
    for fields in [{'attempt_conservative_debit_seconds': 0},
                   {'total_case_seconds': 1853.8956619648961}, {'proof_credit': True}]:
        invalid = dict(stopped, accounting=dict(stopped['accounting'], **fields))
        refuses(lambda invalid=invalid: authority.stopped_attempt_pins(invalid, DEADLINE))
    for index, fields in enumerate([{'proof': {'provisional': True}}, {'proof_credit': True},
                   {'zero_descendants': False},
                   {'validated_pins': dict(pins_ref, sha256='0' * 64)}]):
        bad = write(terminal_path, dict(old_terminal, **fields))
        invalid = dict(stopped, artifacts={bad['path']: bad['sha256']})
        variant = test_supplement('stopped-variant-' + str(index))
        with patch.object(authority, 'STOPPED_SUPPLEMENT', variant):
            refuses(lambda invalid=invalid: authority.stopped_attempt_pins(invalid, DEADLINE))
checks.append('stopped attempt retains full input/primary receipt closure and debit; missing, altered, credited or incomplete evidence refuses')

# Read-only production admission must reject obsolete policy and synthetic
# roots/markers before any process or original slot can be launched.
base_case = {'kind': context.KIND, 'inherited_seconds': budget.INHERITED,
             'cumulative_total': budget.TOTAL, 'attempt_limit': 4320,
             'pins_manifest': {'path': str(ROOT / 'missing'), 'sha256': '0' * 64},
             'helper_sources': {}, 'helper_runtime': {}, 'storage_policy': common.PRODUCTION_STORAGE}
for fields in [{'inherited_seconds': 0}, {'inherited_seconds': 1702.8956619648961},
               {'inherited_seconds': 1853.8956619648961}, {'cumulative_total': 7200},
               {'kind': 'original-positive-budget-continuation-v1'},
               {'cumulative_total': 4320}, {'attempt_limit': 7200},
               {'synthetic_test_only': True}]:
    ref = write(ROOT / 'bad-case.json', dict(base_case, **fields))
    refuses(lambda ref=ref: authority.load_case(ref, DEADLINE))
launch_ref = {'path': str(ROOT / 'launch.json'), 'sha256': 'd' * 64}
case_ref = {'path': str(ROOT / 'case.json'), 'sha256': 'e' * 64}
selection_path = ROOT / 'selection.json'
launch_spec = {'selection_path': str(selection_path), 'case': case_ref}
case = {'helper_sources': {'some-source': 'f' * 64}}
closure = {'stage': 'result-file-continuation-implementation', 'decision': 'GO', 'mandatory_gaps': [],
           'reviewers': ['astra-ultra', 'opus-5.5-xhigh'], 'case': case_ref,
           'launch_spec': launch_ref, 'implementation_pins': case['helper_sources'],
           'mandatory_controls_complete': True}
for fields in [{'stage': 'result-file-continuation-architecture'},
               {'stage': 'budget-continuation-implementation'}, {'mandatory_gaps': ['opus']},
               {'reviewers': ['astra-ultra']}, {'implementation_pins': {}},
               {'mandatory_controls_complete': False}]:
    closure_ref = write(ROOT / 'closure.json', dict(closure, **fields))
    selection = {'kind': context.KIND, 'selected': True, 'case': case_ref,
                 'launch_spec': launch_ref, 'slot': str(authority.SLOT), 'no_resume_or_retry': True,
                 'review_closure': closure_ref}
    ref = write(selection_path, selection)
    # No owner is supplied: rejection must happen before a git subprocess.
    refuses(lambda ref=ref: authority.selected(ref, launch_ref, launch_spec, case, {}, None, DEADLINE))
checks.append('production rejects old/reset policy, synthetic marker and missing/wrong-stage/model/source/control review')
launch_spec = {'kind': context.KIND, 'slot': str(authority.SLOT), 'case': case_ref,
               'selection_path': str(selection_path), 'helper_environment': common.HELPER_ENV,
               'host_active_limit_seconds': 4380, 'host_address_space': 16 * 1024**3,
               'host_file_bytes': common.FILE_BYTES}
valid_ref = write(ROOT / 'launch.json', launch_spec)
assert authority.launch(valid_ref, DEADLINE) == launch_spec
for fields in [{'host_active_limit_seconds': 2617}, {'slot': str(ROOT)},
               {'kind': 'original-positive-budget-continuation-v1'},
               {'slot': str(authority.LEDGER.parent / 'original-positive-budget-continuation-v1')},
               {'helper_environment': dict(common.HELPER_ENV, LD_LIBRARY_PATH='/tmp')},
               {'synthetic_test_only': True}]:
    invalid_ref = write(ROOT / 'launch.json', dict(launch_spec, **fields))
    refuses(lambda invalid_ref=invalid_ref: authority.launch(invalid_ref, DEADLINE))
sources = {str(p): common.sha(p, DEADLINE) for p in common.SOURCE.iterdir()}
for filename in ['observer.py', 'watchdog.py', 'entry.py']:
    bad_sources = dict(sources, **{str(common.SOURCE / filename): '0' * 64})
    refuses(lambda bad_sources=bad_sources: common.source_closure(bad_sources, DEADLINE))
checks.append('old launcher limit/environment/slot and changed observer/watchdog/entry source hashes refuse')

# Clearly fabricated receipt inputs exercise the host's final validator. The
# real exit observations above are separate executed evidence; these files do
# not represent an original program or an accepted execution selection.
host_root = ROOT / 'fabricated-host'
host_root.mkdir()
host_runtime = {k: v for k, v in runtime.items() if k not in {'synthetic_test_only', 'test_offsets'}}
host_runtime.update(slot=str(host_root), deadlines=budget.deadlines(started))
host_binding = write(host_root / 'runtime-context.json', host_runtime)
observed = time.monotonic_ns()
host_terminal = {'context': host_binding, 'stop': None, 'zero_descendants': True,
                 'observed_ns': observed,
                 'accounting': budget.account(observed - started, 0, 4320,
                                               complete=True, finalized=True, accepted=True)}
host_terminal_ref = write(host_root / 'observer-terminal.json', host_terminal)
host_completion = {'context': host_binding, 'terminal_sha256': host_terminal_ref['sha256'],
                   'complete': True, 'finished_ns': time.monotonic_ns()}
completion_path = host_root / 'observer-completion.json'
write(completion_path, host_completion)
finished = time.monotonic_ns()
host.validate_completion(host_root, started, 0, finished, DEADLINE)
for code in [None, 7, -9]:
    refuses(lambda code=code: host.validate_completion(host_root, started, code, finished, DEADLINE))
for fields in [{'terminal_sha256': '0' * 64}, {'finished_ns': finished + 1}, {'complete': False}]:
    write(completion_path, dict(host_completion, **fields))
    refuses(lambda: host.validate_completion(host_root, started, 0, finished, DEADLINE))
completion_path.unlink()
refuses(lambda: host.validate_completion(host_root, started, 0, finished, DEADLINE))
checks.append('fabricated host validator controls reject missing/changed/late receipts and self-success with actual nonzero exit')
used_slot = ROOT / 'one-use-slot'
observer.reserve_slot(used_slot)
marker = used_slot / 'progress'
marker.write_text('preserve incomplete attempt')
try:
    observer.reserve_slot(used_slot)
except FileExistsError:
    pass
else:
    raise AssertionError('used original reservation primitive allowed retry')
assert marker.read_text() == 'preserve incomplete attempt'
checks.append('shared production reservation refuses used/incomplete slot without overwrite')
print(json.dumps({'status': 'PASS', 'synthetic_test_only': True, 'checks': checks,
                  'original_queries': 0, 'full_R2_gate_complete': False}), flush=True)
