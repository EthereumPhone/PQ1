"""Literal full-census comparison with explicit, source-backed label bijections.

Fresh records are never normalized for solver use. This comparison permits only
input-root rebasing and the compiler-generated marker/type labels observed in
this case. In particular, pragma order, debug numbers, classes, fatal flags,
source lines and every other predicate/metadata byte remain exact.
"""
import copy
import hashlib
from pathlib import Path
import re
import time

import negative_profile
import pq1_partition as p

TAG = re.compile(r'\b(struct|union) (_[0-9]+)\b')
DEBUG_TAG = re.compile(r'\btag-_[0-9]+\b')
SANITY = 'std::result::unwrap_failed::<sha2::digest::InvalidOutputSize>.sanity_check.2'


def compare(positive, fresh, old_types, new_types, old_inputs, new_inputs, kani, deadline):
    p.require(type(deadline) is int and time.monotonic_ns() < deadline, 'audit deadline exceeded')
    profile = negative_profile.census_contract(fresh, positive)
    old = positive['properties']
    markers, tags = {}, {}

    def bind(table, before, after):
        p.require(before not in table or table[before] == after, 'ambiguous label mapping')
        table[before] = after

    for name, before in old.items():
        after = fresh[name]
        a, b = p.MARKER.findall(before['description']), p.MARKER.findall(after['description'])
        p.require(len(a) == len(b), 'changed marker count')
        if a:
            bind(markers, a[0], b[0])
        a, b = TAG.findall(before['expression']), TAG.findall(after['expression'])
        p.require(len(a) == len(b), 'changed expression type-label count')
        for left, right in zip(a, b):
            p.require(left[0] == right[0], 'changed aggregate kind')
            bind(tags, left, right)
    p.require(len(markers) == 315 and len(set(markers.values())) == len(markers)
              and len(set(tags.values())) == len(tags), 'label mapping is not bijective')
    tag_evidence = []
    debug_tags = {}
    for left, right in sorted(tags.items()):
        old_tag, new_tag = 'tag-' + left[1], 'tag-' + right[1]
        if left == right:
            # No replacement/equivalence credit is needed for an identical
            # literal tag. The diagnostic type map stores the first Rust type
            # for a GOTO tag (or_insert); shared fat-pointer tags may report
            # either &T or &mut T. Their unchanged formula bytes stay exact.
            bind(debug_tags, old_tag, new_tag)
            continue
        p.require(old_tag in old_types and new_tag in new_types
                  and old_types[old_tag] == new_types[new_tag], 'changed underlying Rust type')
        bind(debug_tags, old_tag, new_tag)
        tag_evidence.append({'old': list(left), 'fresh': list(right),
                             'rust_type': old_types[old_tag]})
    p.require(len(set(debug_tags.values())) == len(debug_tags), 'ambiguous debug type mapping')
    cache, files, changed_sources = {}, {}, {}

    def source_bytes(path):
        p.require(time.monotonic_ns() < deadline, 'audit deadline exceeded')
        path = path.resolve(strict=True)
        if path not in cache:
            with path.open('rb') as stream:
                data = stream.read(16 * 1024**2 + 1)
            p.require(len(data) <= 16 * 1024**2, 'oversized source evidence')
            cache[path] = data
        return cache[path]

    def resolve(location, inputs):
        path = Path(location['file'])
        if path.is_absolute():
            return path
        if path.parts[:1] == ('library',):
            return kani / path
        return inputs / 'project' / path

    def source_evidence(name, before, after):
        a, b = before['sourceLocation'], after['sourceLocation']
        p.require(a.get('file') and b.get('file') and a.get('line') == b.get('line')
                  and a.get('column') == b.get('column') and a.get('function') == b.get('function'),
                  'changed source identity for renamed label')
        left, right = resolve(a, old_inputs), resolve(b, new_inputs)
        data, other = source_bytes(left), source_bytes(right)
        # The only changed source file is the intentionally wrong oracle. Its
        # marker-bearing assertion lines must nevertheless remain byte-identical.
        if data != other:
            p.require(left == old_inputs / 'project/src/lib.rs'
                      and right == new_inputs / 'project/src/lib.rs'
                      and data.count(b'[0xe3, 0xb0,') == 2
                      and data.replace(b'[0xe3, 0xb0,', b'[0xe2, 0xb0,', 1) == other,
                      'source bytes changed outside exact oracle mutation')
        line = int(a['line'])
        old_lines, new_lines = data.splitlines(keepends=True), other.splitlines(keepends=True)
        p.require(0 < line <= len(old_lines) and line <= len(new_lines)
                  and old_lines[line - 1] == new_lines[line - 1], 'changed source line behind label')
        changed_sources[name] = {'old': str(left), 'fresh': str(right), 'line': line,
                                'line_sha256': hashlib.sha256(old_lines[line - 1]).hexdigest()}

    changed_fields = {}
    for name, before in old.items():
        p.require(time.monotonic_ns() < deadline, 'audit deadline exceeded')
        after = fresh[name]
        compared = copy.deepcopy(before)
        compared['description'] = p.MARKER.sub(lambda m: markers[m[0]], before['description'])
        compared['expression'] = TAG.sub(lambda m: ' '.join(tags[(m[1], m[2])]), before['expression'])
        location, actual = compared['sourceLocation'], after['sourceLocation']
        location['comment'] = p.MARKER.sub(lambda m: markers[m[0]], location['comment'])
        if compared['description'] != after['description']:
            p.require(name == SANITY and before['class'] == after['class'] == 'sanity_check'
                      and before['description'].startswith(
                          'Kani-internal sanity check: Correct CBMC vtable size'),
                      'unselected diagnostic text change')
            # No DefId/Ty number replacement or general text stripping is allowed.
            compared['description'] = DEBUG_TAG.sub(lambda m: debug_tags[m[0]],
                                                     compared['description'])
            location['comment'] = compared['description']
        if before['description'] != after['description'] or before['expression'] != after['expression']:
            source_evidence(name, before, after)
        if location.get('file') != actual.get('file'):
            left, right = Path(location['file']), Path(actual['file'])
            p.require(left.is_relative_to(old_inputs)
                      and right == new_inputs / left.relative_to(old_inputs), 'unselected file relocation')
            data, other = source_bytes(left), source_bytes(right)
            p.require(data == other, 'relocated source bytes differ')
            files[str(left)] = {'fresh': str(right), 'sha256': hashlib.sha256(data).hexdigest()}
            location['file'] = actual['file']
        if location.get('workingDirectory') != actual.get('workingDirectory'):
            p.require(location['workingDirectory'] == str(old_inputs / 'project')
                      and actual['workingDirectory'] == str(new_inputs / 'project'),
                      'unselected working directory relocation')
            location['workingDirectory'] = actual['workingDirectory']
        p.require(compared == after, 'unaccounted literal census difference: ' + name)
        for field in before:
            if before[field] != after[field]:
                changed_fields[field] = changed_fields.get(field, 0) + 1
    p.require(time.monotonic_ns() < deadline, 'audit deadline exceeded')
    return {'static_count': 2840, 'removed': [], 'added': [], 'marker_bijection': markers,
            'type_bijection': tag_evidence, 'source_files': files,
            'label_source_lines': changed_sources, 'changed_fields': changed_fields,
            'source_pins': {str(path): hashlib.sha256(data).hexdigest() for path, data in cache.items()},
            'literal_metadata_preserved': True, 'profile': profile,
            'full_census_audit_complete': True, 'proof_credit': False}
