"""Toy backend used only by the isolated supervision controls; no CBMC calls."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def me():
    fields = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': os.getpid(), 'start_ticks': int(fields[19])}


def emit(text):
    print(text, end='', flush=True)


args = sys.argv[1:]
program_path = Path(args[-1])
assert program_path.is_relative_to('/tmp') and program_path.parent.name.startswith('pq1-budget-test-')
program = json.loads(program_path.read_text())
assert program['synthetic_test_only'] is True
properties = program['properties']
assert len(properties) == 2840 and all(n.startswith('synthetic.assertion.') for n in properties)
if '--show-properties' in args:
    print(json.dumps([{'properties': list(properties.values())}]))
    raise SystemExit(0)
if '--property' in args:
    assert program['mode'] == 'negative'
    assert (program_path.parent / 'slot/tail-validation.json').is_file()
    selected = [args[i + 1] for i, arg in enumerate(args) if arg == '--property']
    assert set(program['required']) <= set(selected)
    emit('** Results:\n')
    for name in selected:
        status = program['required'].get(name, 'SUCCESS')
        emit(f'[{name}] {properties[name]["description"]}: {status}\n')
    emit('[synthetic.unwind.0] line 9 unwinding assertion loop 0: SUCCESS\n')
    emit(f'\n** 2 of {len(selected) + 1} failed\nVERIFICATION FAILED\n')
    raise SystemExit(10)
groups = json.loads(Path(args[args.index('--pq1-scoped-partitions') + 1]).read_text())
assert len(groups) == 22
if program['mode'] in {'hang', 'malformed'}:
    os.setsid()
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    grandchild_path = program_path.parent / 'grandchild-ready.json'
    code = ('import os,signal,time,json;from pathlib import Path;os.setsid();'
            'signal.signal(signal.SIGTERM,signal.SIG_IGN);'
            'fields=Path("/proc/self/stat").read_text().rsplit(")",1)[1].split();'
            'p=' + repr(str(grandchild_path)) + ';'
            'open(p,"x").write(json.dumps({"pid":os.getpid(),"start_ticks":int(fields[19])}));'
            'time.sleep(600)')
    subprocess.Popen(['/usr/bin/python3', '-E', '-S', '-B', '-c', code])
    ready_limit = time.monotonic() + 2
    while not grandchild_path.exists():
        assert time.monotonic() < ready_limit
        time.sleep(.005)
    (program_path.parent / 'solver-ready.json').write_text(json.dumps(me()))
    emit('Runtime Symex: 0s\n')
    if program['mode'] == 'malformed':
        emit('warning: deliberate synthetic timer refusal\n')
    time.sleep(600)
    raise SystemExit(125)
assert program['mode'] == 'negative'
emit('Runtime Symex: 0s\n')
emit(f'PQ1-SCOPED-PARTIAL-SELECTED {sum(map(len, groups))} 2840\n')
for index, group in enumerate(groups):
    emit(f'PQ1-SCOPED-GROUP-BEGIN {index}\n** Results:\n')
    for name in group:
        emit(f'[{name}] {properties[name]["description"]}: SUCCESS\n')
    emit('[synthetic.unwind.0] line 9 unwinding assertion loop 0: SUCCESS\n')
    emit(f'\n** 0 of {len(group) + 1} failed\nVERIFICATION SUCCESSFUL\nPQ1-SCOPED-GROUP-END {index} 0\n')
    assert sys.stdin.readline() == f'PQ1-SCOPED-ACK {index}\n'
assert sys.stdin.read() == ''
emit('PQ1-SCOPED-PARTIAL-COMPLETE 22 0\n')
