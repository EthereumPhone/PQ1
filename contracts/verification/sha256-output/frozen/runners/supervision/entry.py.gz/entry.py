"""Explicit source entry point. Run only as python3 -E -S -B entry.py ROLE ... .

The direct script is not imported through Python's bytecode cache. Reject any
local bytecode before importing a single project module. Standard-library
bytecode is a separate, explicitly authenticated runtime dependency.
"""
import time

ENTRY_NS = time.monotonic_ns()

import os
import sys


def source_path():
    if not (sys.flags.ignore_environment and sys.flags.no_site
            and sys.flags.dont_write_bytecode):
        raise RuntimeError('helper requires -E -S -B')
    root = os.path.dirname(os.path.realpath(__file__))
    for item in os.scandir(root):
        if (item.is_symlink() or not item.is_file(follow_symlinks=False)
                or not item.name.endswith(('.py', '.json'))):
            raise RuntimeError('non-source helper closure member: ' + item.name)
    # Only this flat source closure and the pinned system standard library.
    # Do not retain CWD, PYTHONPATH, site packages or another checkout.
    sys.path[:] = [root, '/usr/lib/python3.12',
                   '/usr/lib/python3.12/lib-dynload']
    return root


def main():
    source_path()
    from common import HELPER_ENV, require
    require(dict(os.environ) == HELPER_ENV, 'changed helper environment')
    require(len(sys.argv) >= 2, 'missing helper role')
    role = sys.argv[1]
    require(role in {'host', 'observer', 'watchdog', 'controller', 'timer'},
            'unknown helper role')
    module = __import__(role)
    return module.main(sys.argv[2:], ENTRY_NS)


if __name__ == '__main__':
    raise SystemExit(main())
