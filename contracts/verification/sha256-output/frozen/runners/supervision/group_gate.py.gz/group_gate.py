"""Validate each provisional raw group before the caller sends its next ACK.

This does not authorize an original query or accept a whole proof. The caller
binds this contract to the original case; final composition remains mandatory.
"""
import hashlib
import json
import math
import re

import context

from collect_continuation import BAD_MESSAGE, partition

require = partition.require


def negative_contract(profile, groups):
    require(profile['kind'] == context.KIND, 'not the selected negative kind')
    return {'kind': profile['kind'], 'properties': profile['properties'], 'groups': groups,
            'required': profile['required'], 'dynamic_origin': 'first-fresh-tail-group'}


def finite_nonnegative(value):
    return type(value) in {int, float} and math.isfinite(value) and value >= 0


def continuation_screen(first_elapsed, symex_seconds, case_elapsed,
                        inherited_seconds, remaining_groups=21):
    """A conservative screening proxy, subordinate to unchanged hard limits."""
    require(all(finite_nonnegative(x) for x in
                [first_elapsed, symex_seconds, case_elapsed, inherited_seconds]),
            'invalid cost-screen time')
    require(first_elapsed < 180 and symex_seconds <= first_elapsed and
            case_elapsed >= first_elapsed and inherited_seconds < 4320,
            'inconsistent cost-screen times')
    require(type(remaining_groups) is int and remaining_groups == 21,
            'changed original remaining group count')
    remainder = first_elapsed - symex_seconds
    rounded = math.ceil(remainder)
    required = remaining_groups * (2 * rounded + 20)
    remaining = 4320 - inherited_seconds - case_elapsed
    return {'first_group_elapsed': first_elapsed,
            'symex_seconds': symex_seconds, 'remainder_seconds': remainder,
            'rounded_remainder_seconds': rounded,
            'required_later_seconds': required,
            'case_elapsed_seconds': case_elapsed,
            'inherited_seconds': inherited_seconds,
            'remaining_seconds': remaining, 'remaining_groups': remaining_groups,
            'passes': required <= remaining}


class GroupGate:
    """Strict partial framing plus original semantic checks at each boundary."""

    def __init__(self, contract):
        self.capture_dynamic = contract.get('kind') == context.KIND
        expected = ({'kind', 'properties', 'groups', 'required', 'dynamic_origin'}
                    if self.capture_dynamic else {'properties', 'groups', 'required', 'prior_dynamic'})
        require(set(contract) == expected, 'unknown or missing group-gate contract field')
        self.properties = contract['properties']
        self.groups = contract['groups']
        self.required = contract['required']
        self.prior_dynamic = None if self.capture_dynamic else contract['prior_dynamic']
        self.dynamic_capture = self.dynamic_capture_sha256 = None
        require(isinstance(self.properties, dict) and self.properties and
                isinstance(self.groups, list) and 1 <= len(self.groups) <= 32 and
                all(isinstance(g, list) and g for g in self.groups),
                'invalid gate properties or groups')
        selected = [name for group in self.groups for name in group]
        require(all(isinstance(name, str) for name in selected) and
                len(selected) == len(set(selected)) and
                set(selected) < set(self.properties), 'invalid gate selection')
        require(isinstance(self.required, dict) and
                set(self.required) <= set(self.properties) and
                all(v in {'SUCCESS', 'FAILURE'} for v in self.required.values()) and
                (self.capture_dynamic or isinstance(self.prior_dynamic, dict)), 'invalid gate metadata')
        if self.capture_dynamic:
            require(contract['dynamic_origin'] == 'first-fresh-tail-group'
                    and len(self.groups) == 22 and len(self.required) == 2
                    and set(self.required.values()) == {'FAILURE'}
                    and not (set(self.required) & set(selected))
                    and {self.properties[name]['class'] for name in self.required}
                    == {'assertion', 'reachability_check'},
                    'negative tail cannot import historical dynamics or contain the expected root')
        self.selected_count = len(selected)
        self.phase = 'prefix'
        self.index = 0
        self.prefix = []
        self.body = []
        self.reports = []
        self.boundaries = []
        self.symex_seconds = None
        self.output_bytes = 0
        self.overall_exit = None

    def line(self, line):
        require(isinstance(line, str) and line.endswith('\n') and
                '\n' not in line[:-1], 'incomplete gate line')
        self.output_bytes += len(line.encode('utf-8'))
        require(self.output_bytes <= 16 * 1024**2, 'gate output bound')
        require(not BAD_MESSAGE.search(line), 'group-gate diagnostic')
        require(self.phase != 'finished', 'output after partial completion')
        if line.startswith('Runtime Symex:'):
            require(self.phase == 'prefix' and self.symex_seconds is None,
                    'repeated or misplaced Symex timing')
            match = re.fullmatch(r'Runtime Symex: ([^\s]+)s\n', line)
            require(match is not None, 'malformed Symex timing')
            value = float(match[1])
            require(finite_nonnegative(value), 'invalid Symex timing')
            self.symex_seconds = value
        if self.phase == 'prefix':
            if not line.startswith('PQ1-SCOPED-'):
                self.prefix.append(line)
                return None
            require(line == (f'PQ1-SCOPED-PARTIAL-SELECTED {self.selected_count} '
                             f'{len(self.properties)}\n'),
                    'wrong partial selection boundary')
            self.phase = 'begin'
            return None
        if self.phase == 'begin':
            require(line == f'PQ1-SCOPED-GROUP-BEGIN {self.index}\n',
                    'missing or out-of-order group begin')
            self.body = list(self.prefix) if self.index == 0 else []
            self.phase = 'body'
            return None
        if self.phase == 'body':
            if not line.startswith('PQ1-SCOPED-'):
                self.body.append(line)
                return None
            match = re.fullmatch(r'PQ1-SCOPED-GROUP-END (\d+) (0|10)\n', line)
            require(match is not None and int(match[1]) == self.index,
                    'malformed or out-of-order group end')
            code = int(match[2])
            body = ''.join(self.body)
            group = self.groups[self.index]
            report = partition.parse_report(body, self.properties, group, code)
            partition.semantic_check(self.properties, report, self.required)
            require(all(report['rows'][name] == 'SUCCESS' for name in group
                        if self.properties[name]['sourceLocation'].get('propertyFatal')),
                    'group gate contains failed fatal property')
            body_sha = hashlib.sha256(body.encode('utf-8')).hexdigest()
            if self.capture_dynamic and self.index == 0:
                require(self.prior_dynamic is None and self.dynamic_capture is None,
                        'first-tail dynamic capture already consumed')
                # semantic_check above already requires every dynamic status
                # and every selected semantic obligation to succeed. Fatal
                # status is checked separately before this snapshot exists.
                self.prior_dynamic = dict(report['dynamic'])
                self.dynamic_capture = {
                    'schema': 'pq1-first-tail-dynamic-v1', 'origin_group': 0,
                    'body_sha256': body_sha, 'dynamic': dict(sorted(report['dynamic'].items())),
                    'statuses': {name: report['rows'][name] for name in sorted(report['dynamic'])}}
                data = (json.dumps(self.dynamic_capture, indent=2, allow_nan=False) + '\n').encode()
                self.dynamic_capture_sha256 = hashlib.sha256(data).hexdigest()
            require(report['dynamic'] == self.prior_dynamic,
                    'changed dynamic obligation set or metadata')
            boundary = {'group': self.index, 'exit': code,
                        'body_sha256': body_sha,
                        'static_count': len(group),
                        'dynamic_count': len(report['dynamic'])}
            if self.capture_dynamic:
                boundary['dynamic_capture_sha256'] = self.dynamic_capture_sha256
            self.reports.append(report)
            self.boundaries.append(boundary)
            self.phase = 'ack'
            return dict(boundary)
        if self.phase == 'ack':
            require(False, 'backend advanced before acknowledgement')
        require(self.phase == 'complete', 'unknown group-gate state')
        self.overall_exit = (10 if any('FAILURE' in r['rows'].values()
                                      for r in self.reports) else 0)
        require(line == (f'PQ1-SCOPED-PARTIAL-COMPLETE {len(self.groups)} '
                         f'{self.overall_exit}\n'),
                'wrong or missing partial completion')
        self.phase = 'finished'
        return None

    def acknowledge(self, index):
        require(self.phase == 'ack' and type(index) is int and index == self.index,
                'out-of-order gate acknowledgement')
        self.index += 1
        self.phase = 'complete' if self.index == len(self.groups) else 'begin'

    def finish(self, actual_exit):
        require(self.phase == 'finished' and type(actual_exit) is int and
                actual_exit == self.overall_exit and
                self.index == len(self.groups), 'incomplete gated process')
        return self.reports
