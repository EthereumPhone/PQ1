"""Offline formatter compatibility controls; never original proof evidence."""
import copy
import importlib.util
import json
from pathlib import Path
import sys

import pq1_partition as parser


def refused(action):
    try:
        action()
    except (ValueError, TypeError):
        return
    raise AssertionError('invalid metadata/result was accepted')


def compact_forms():
    props = {'fixture.assertion.1': {
        'class': 'assertion', 'description': 'exact condition\ncontinued text',
        'sourceLocation': {'file': '/fixture/path with spaces/file.rs', 'line': '7'}}}
    selected = list(props)

    def text(prefix):
        return ('** Results:\n[fixture.assertion.1] ' + prefix
                + props[selected[0]]['description']
                + ': SUCCESS\n\n** 0 of 1 failed\nVERIFICATION SUCCESSFUL\n')

    for prefix in ['line 7 ', 'file /fixture/path with spaces/file.rs line 7 ']:
        result = parser.parse_report(text(prefix), props, selected, 0)
        assert result == {'rows': {selected[0]: 'SUCCESS'}, 'dynamic': {}}
    for prefix in ['file /fixture/other.rs line 7 ', 'file /fixture/path with spaces/./file.rs line 7 ',
                   'file /fixture/path with spaces/file.rs line 8 ', 'line 8 ',
                   'file /fixture/path with spaces/file.rs ', 'file  line 7 ']:
        refused(lambda prefix=prefix: parser.parse_report(text(prefix), props, selected, 0))
    for location in [{}, {'file': ''}, {'file': '', 'line': '7'}, {'line': '7'}]:
        props[selected[0]]['sourceLocation'] = location
        suffix = 'line 7 ' if location.get('line') else ''
        for prefix in [suffix, 'file  ' + suffix]:
            parser.parse_report(text(prefix), props, selected, 0)
    # Dynamic unwind syntax is unchanged; metadata differences remain visible.
    props[selected[0]]['sourceLocation'] = {}
    dynamic = text('').replace('\n** 0 of 1 failed',
        '\n[fixture.unwind.3] line 9 unwinding assertion loop 3: SUCCESS\n\n** 0 of 2 failed')
    result = parser.parse_report(dynamic, props, selected, 0)
    assert set(result['dynamic']) == {'fixture.unwind.3'}
    refused(lambda: parser.parse_report(dynamic.replace('loop 3:', 'loop 4:'), props, selected, 0))
    refused(lambda: parser.parse_report(dynamic.replace('[fixture.unwind.3] line',
        '[fixture.unwind.3] file /unbound.rs line'), props, selected, 0))
    return 19


def recorded_case(folder, legacy_source):
    spec = importlib.util.spec_from_file_location('legacy_partition_for_control', legacy_source)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    contract = json.loads((folder / 'gate-contract.json').read_text())
    text = (folder / 'tail/command.log').read_text()
    props, groups = contract['properties'], contract['groups']
    results, bodies = [], []
    for i in range(18):
        begin = f'PQ1-SCOPED-GROUP-BEGIN {i}\n'
        end = f'PQ1-SCOPED-GROUP-END {i} 10\n'
        assert text.count(begin) == text.count(end) == 1
        body = text.split(begin, 1)[1].split(end, 1)[0]
        report = parser.parse_report(body, props, groups[i], 10)
        parser.semantic_check(props, report, contract['required'])
        assert report['dynamic'] == contract['prior_dynamic']
        assert all(report['rows'][name] == 'SUCCESS' for name in groups[i]
                   if props[name]['sourceLocation'].get('propertyFatal'))
        if i < 17:
            assert report == old.parse_report(body, props, groups[i], 10)
        else:
            refused(lambda: old.parse_report(body, props, groups[i], 10))
        results.append(report)
        bodies.append(body)
    name = 'core::num::<impl usize>::abs_diff.assertion.1'
    assert len(results[17]['rows']) == len(groups[17]) == 128
    assert results[17]['rows'][name] == 'SUCCESS'
    prop = props[name]
    row = ('[' + name + '] file ' + prop['sourceLocation']['file'] + ' line '
           + prop['sourceLocation']['line'] + ' ' + prop['description'] + ': SUCCESS')
    assert bodies[17].count(row) == 1

    def check(body, selected=groups[17], properties=props):
        report = parser.parse_report(body, properties, selected, 10)
        parser.semantic_check(properties, report, contract['required'])

    mutations = [row.replace('file ' + prop['sourceLocation']['file'], 'file /wrong.rs'),
                 row.replace('/num/uint_macros.rs', '/num/./uint_macros.rs'),
                 row.replace('line 3206', 'line 3207'),
                 row.replace(prop['description'], prop['description'] + ' changed'),
                 row.replace(name, 'unselected.assertion.1'),
                 row.replace(': SUCCESS', ': UNKNOWN'),
                 row.replace(': SUCCESS', ': FAILURE')]
    for mutated in mutations:
        assert mutated != row
        refused(lambda mutated=mutated: check(bodies[17].replace(row, mutated)))
    refused(lambda: check(bodies[17].replace(row + '\n', '')))
    refused(lambda: check(bodies[17].replace('** 12 of 128 failed', '** 11 of 128 failed')))
    refused(lambda: check(bodies[17], groups[17][1:]))
    changed = copy.deepcopy(props)
    changed[name]['sourceLocation']['file'] = '/wrong-census.rs'
    refused(lambda: check(bodies[17], properties=changed))
    # A semantically failed row also refuses with a coherent updated summary.
    failed = bodies[17].replace(row, row.replace(': SUCCESS', ': FAILURE'))
    failed = failed.replace('** 12 of 128 failed', '** 13 of 128 failed')
    refused(lambda: check(failed))
    return {'old_group_maps_identical': 17, 'new_form_group_rows': 128,
            'negative_mutations_refused': 12, 'saved_groups_checked': len(results)}


if __name__ == '__main__':
    assert len(sys.argv) == 3
    forms = compact_forms()
    result = recorded_case(Path(sys.argv[1]), Path(sys.argv[2]))
    print(json.dumps(dict(result, compact_form_checks=forms, original_queries=0,
                          new_proof_credit=False, status='PASS')))
